#ifndef AMPLITUDE_H
#define AMPLITUDE_H

#include <string>
#include <complex>
#include <vector>
#include "WaveFunctions.h"

std::complex<double> FFSAmp(FermionWaveFunction fIn, FermionWaveFunction fOut,
			    ScalarWaveFunction s, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> FFVAmp(FermionWaveFunction fIn, FermionWaveFunction fOut,
			    VectorWaveFunction v, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> VVSAmp(VectorWaveFunction v1, VectorWaveFunction v2,
			    ScalarWaveFunction s, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> VSSAmp(VectorWaveFunction v, ScalarWaveFunction s1,
			    ScalarWaveFunction s2, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> SSSAmp(ScalarWaveFunction s1, ScalarWaveFunction s2,
			    ScalarWaveFunction s3, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> VVVAmp(VectorWaveFunction v1, VectorWaveFunction v2,
			    VectorWaveFunction v3, 
			    std::vector< std::complex<double> > couplings,
			    char usrFlag = ' ');

std::complex<double> SSSSAmp(ScalarWaveFunction s1, ScalarWaveFunction s2,
                             ScalarWaveFunction s3, ScalarWaveFunction s4,
                             std::vector< std::complex<double> > couplings,
                             char usrFlag = ' ');

std::complex<double> VVSSAmp(VectorWaveFunction v1, VectorWaveFunction v2,
                             ScalarWaveFunction s1, ScalarWaveFunction s2,
                             std::vector< std::complex<double> > couplings,
                             char usrFlag = ' ');

#endif
