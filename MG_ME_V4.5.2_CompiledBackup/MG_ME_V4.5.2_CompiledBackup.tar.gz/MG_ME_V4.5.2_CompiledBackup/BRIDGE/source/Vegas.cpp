#include "Vegas.h"
#include <math.h>
#include <iostream>
#include <fstream>
using namespace std;

// For now, I'm just rewriting "vegas.f" from MadGraph in C++...
// Hopefully this will reveal the right structure for the Vegas class
// The "SAVE" Fortran command makes variables static, suggesting
// some of them should be member variables.

Vegas::Vegas(Region r, VegasCallable* f, VegasRandom* vr,
	     std::ostream* out, double aleph)
  : region(r), theFunction(f), getRandom(vr), output(out), alpha(aleph)
{
  // mimic the "enter here on a cold start" section of vegas.f
  //for(int j = 1; j <= 2*nDim; j++) {
  //  region1[j] = region[j]; // why this?
  //}
  sampling = STRAT_MAG;
  nDiv = 1;
  nDim = region.size();
  // Initialize the arrays: it's important that there be a "1"
  // in the 1 position, and "0"s above it. We ignore the "0"
  // position (unfortunate remnant of my laziness in Fortran tranlation)
  for(int j = 0; j < nDim; j++) {
    region[j].grid.push_back(1.);
    region[j].grid.push_back(1.);
    for(int i = 0; i < 100; i++) {
      region[j].grid.push_back(0.);
    }
  }
  si = 0.;
  sWeight = 0.;
  sChi = 0.;
  maxweight = 0.;
}

void Vegas::resetAnswers() {
  si = 0.;
  sWeight = 0.;
  sChi = 0.;
  maxweight = 0.;
}

// Dictionary:
// maxIter --> itmx. Should be parameter for integrate, it can change
//                   from one call to the next.
// nCall --> ncall.  Similar. Passed by reference, the return value
//                   tells actual number of calls.
VegasOutput Vegas::integrate(int & nCall, int maxIter, bool runInit, 
			     Verbosity v /* = NOPRINT */)
{
  VegasOutput vout;
  int nd, ng, npg, k;
  double xjac, xn, xo, dxg, dv2g;
  double f, fb, f2, f2b, weight, rc;
  double calls;
  std::vector<int> ia(nDim), kg(nDim);
  std::vector<double> r(maxNDiv+1), dt(nDim), x(nDim);
  std::vector< std::vector<double> > d, di;
  // Set up sizes of these 2D arrays.
  for(int i = 0; i < nDim; i++) {
    std::vector<double> dtemp(maxNDiv+1);
    d.push_back(dtemp);
    di.push_back(dtemp);
  } 

  if(runInit) {
    nd = maxNDiv;
    ng = 1;
    if(sampling != IMPORT) { //setup for stratification
      ng = int(pow((nCall/2. + 0.25),(1./nDim)));
      sampling = STRAT_MAG;
      if((2*ng-maxNDiv)>=0) {
	sampling = STRAT_ERR;
	npg = ng/maxNDiv + 1;
	nd=ng/npg;
	ng=npg*nd;
      }
    }
    // the lack of an integer power function disturbs me
    k = int(pow(ng,double(nDim))); 
    npg=max(nCall/k,2);
    calls=npg*k;
    //cfax: returns the actual number of calls
    nCall=int(calls);
    dxg=1./ng;
    dv2g=(calls*calls*pow(dxg,2*nDim))/npg/npg/(npg-1.);
    xnd=nd;
    dxg=dxg*xnd;
    xjac=1./calls;
    for(int j = 0; j < nDim; j++) {
      xjac=xjac*region[j].Length(); // divide interval up into "calls" pieces.
    }
    //-- do the binning if necessary
    if(nd != nDiv) {
      for(int i = 1; i <= nd; i++) {
	r[i] = 1.;
      }
      for(int j = 0; j < nDim; j++) {
	// Rebin axis #j.
	region[j].Rebin(nDiv/xnd, nd, r);
      }
      nDiv=nd;
    }
    if(v == PRINT_ALL) {
      // clean this up....
      *output << nDim << "  " << calls /*<< it*/ << "  " << maxIter 
	      << " " << alpha << "  " << sampling << "  " << nd << endl;
      //write(*,200) ndim,calls,it,itmx,nprn,ALPH,mds,nd
    } 
  }

  // MAIN ITERATION LOOP
  for(int it = 1; it <= maxIter; it++) {
    double ti = 0.;
    double tsi = 0.;
    for(int j = 0; j < nDim; j++) {
      kg[j] = 1;
      for(int i = 1; i <= nd; i++) {
	d[j][i] = 0.;
	di[j][i] = 0.;
      }
    }
    // Here in the Fortran is a "continue", which a goto points back to...
    for(;;) {
      double fb = 0;
      double f2b = 0;
      for(int k = 1; k <= npg; k++) {
	weight = xjac;
	for(int j = 0; j < nDim; j++) {
	  double random = (*getRandom)();
	  // check random is not exactly 0. or 1. ????
	  xn = (kg[j] - random) * dxg + 1;
	  ia[j] = max(min(int(xn),maxNDiv),1);
	  if(ia[j] > 1) {
	    xo = region[j].grid[ia[j]] - region[j].grid[ia[j]-1];
	    rc = region[j].grid[ia[j]-1] + (xn - ia[j])*xo;
	  } else {
	    xo = region[j].grid[ia[j]];
	    rc = (xn - ia[j])*xo;
	  }
	  x[j] = region[j].xLow + rc * region[j].Length();
	  weight *= xo*xnd;
	}
	f = weight*theFunction->VegasInput(x, weight);
	if(f > maxweight) maxweight = f;
	f2 = f*f;
        //tp line added to catch STRAT_MAG for 3-body decays
        if((sampling == STRAT_MAG)&&(f2 <= tinyNumber)) f2 = tinyNumber;
	fb += f;
	f2b += f2;
	for(int j = 0; j < nDim; j++) {
	  di[j][ia[j]] = di[j][ia[j]] + f;
	  if(sampling == STRAT_MAG) {
	    d[j][ia[j]] += f2;
	  }
	}
      }
      f2b = sqrt(f2b * npg);
      f2b = (f2b - fb) * (f2b + fb);
      //tp line changed to catch tinyNumber instead of zero
      if(f2b <= tinyNumber) f2b = tinyNumber;
      ti += fb;
      tsi += f2b;
      if(sampling == STRAT_ERR) {
	for(int j = 0; j < nDim; j++) {
	  d[j][ia[j]] += f2b;
	}
      }

      // There are times when a goto looks comparatively elegant....
      bool breakFlag = true;
      for(int k = nDim-1; k >= 0; k--) {
	kg[k] = (kg[k] % ng) + 1;
	if(kg[k] != 1) {
	  breakFlag = false;
	  break;
	}
      }
      if(breakFlag) break;
    }

    // All points for this iteration have been thrown.
    // Now calculate the results and the cumulative result....
    tsi *= dv2g;
    weight = 1./tsi;
    si += weight * ti;
    sChi += weight * ti * ti;
    sWeight += weight;
    vout.integral = si / sWeight;
    vout.chi2dof = (sChi - si * vout.integral)/(it - 0.99);
    if(vout.chi2dof < 0.) vout.chi2dof = 0.;
    vout.sigma = sqrt(1./sWeight);
    tsi = sqrt(tsi);
    if(v == PRINT || v == PRINT_ALL) {
      *output << it << " " << ti << " " << tsi;
    }
    if(v == PRINT_ALL) {
      for(int j = 1; j <= nDim; j++) {
	for(int i = 1/*+nPrint/2*/; i <= nd; i++ /*+= nPrint*/) { 
	  // ignore the nPrint craziness?
	  *output << j << "  " << region[j].grid[i] 
		  << "  " << di[j][i] << endl;
	}
      }
    }

    // Refine the grid after the iteration
    // The probability density is refined by subdividing each increment
    // Delta x_i into m_i + 1 subintervals, where
    // m_i = K (fbar_i Delta x_i)/(Sum_k fbar_k Deltax_k).
    // In practice to avoid too-fast evolution, replace this with:
    // m'_i = K((m_i / K - 1) 1/log(m_i))^alpha

    for(int j = 0; j < nDim; j++) {
      xo = d[j][1];
      xn = d[j][2];
      d[j][1] = (xo + xn)/2.;
      dt[j] = d[j][1];
      for(int i = 2; i < nd; i++) {
	rc = xo + xn;
	xo = xn;
	xn = d[j][i+1];
	d[j][i] = (rc + xn)/3.;
	dt[j] += d[j][i];
      }
      d[j][nd] = (xo+xn)/2.;
      dt[j] += d[j][nd];
    }

    // Slow down the evolution
    for(int j = 0; j < nDim; j++) {
      rc = 0.;
      for(int i = 1; i <= nd; i++) {
	if(d[j][i] < tinyNumber) d[j][i] = tinyNumber;
//	cout << "(j,i) = (" << j << ", " << i << "), d[j][i] = " << d[j][i] 
//	     << ", dt[j] = " << dt[j] << ", ";
	r[i] = pow((1.-d[j][i]/dt[j])/(log(dt[j])-log(d[j][i])),alpha);
//	cout << "r[i] = " << r[i] << "\n";
	rc += r[i];
      }
      region[j].Rebin(rc/xnd, nd, r);
    }
//    cout << "alpha = " << alpha << "\n";
  }
  maxweight *= nCall;

  return vout;
}

// Rebin the interval.
// r[i]: how to rebin subinterval #i.
// The idea is to divide up subinterval #i into r[i] subsubintervals,
// but then regroup the new subintervals, the number of subsubintervals
// in each new group being equal to preserve the increment density.
// The optimal grid is obtained when the r[i]'s are equal for all i.
void Interval::Rebin(double rc, int ndiv, std::vector<double> r)
{
//    cout << "Rebin called with (rc,ndiv) = (" << rc << ", " << ndiv << ")\n";
//    cout << "r = ";
//    for(int ii=1; ii<ndiv; ii++) cout << r[ii] << "  ";
//    cout << "\n";
  double xo, xn;
  double dr;
  int k = 0;
  xn = 0.;
  dr = 0.;
  vector<double> gridtemp;
  for(int i = 1; i < ndiv; i++) {
    while(rc > dr) {
      k++;
      dr += r[k];
      xo = xn;
      xn = grid[k];
    }
    dr -= rc;
//    cout << "Modifying grid[" << i << "] using r[" << k << "]\n";
    gridtemp.push_back(xn - (xn-xo)*dr/r[k]);
  }
  for(int i = 1; i < ndiv; i++) {
      grid[i] = gridtemp[i-1];
  }
  grid[ndiv] = 1.;
  return;
}

// Get a set of random numbers
double Vegas::getRandomFromGrid(std::vector<double>& x)
{
  std::vector<int> ia(nDim);
  double xo, rc;

  if(x.size() < nDim) {
    for(int i = 0; i < nDim; i++) {
      x.push_back(0.);
    }
  }

  double wgt = 1.;
  for(int j = 0; j < nDim; j++) {
    // Get a random number, not precisely 0 or 1.
    double rand = 0.;
    while(rand == 0. || rand == 1.) {
      rand = (*getRandom)();
    }

    double xn = rand * xnd + 1;
    ia[j] = max(min(int(xn),maxNDiv),1);
    if(ia[j] > 1) {
      xo = region[j].grid[ia[j]] - region[j].grid[ia[j]-1];
      rc = region[j].grid[ia[j]-1] + (xn - ia[j])*xo;
    } else {
      xo = region[j].grid[ia[j]];
      rc = (xn - ia[j])*xo;
    }
    x[j] = region[j].xLow + rc * region[j].Length();
    wgt = wgt * xo * xnd;  
  }

  return wgt;
}

// Read/write from file
void Vegas::writeToFile(string outputFile) {
  ofstream out(outputFile.c_str());
  out << nDim << endl;
  out << alpha << endl;
  out << nDiv << endl;
  out << si << endl;
  out << sWeight << endl;
  out << sChi << endl;
  out << xnd << endl;
  out << maxweight << endl;
  if(sampling == IMPORT) {
    out << "1" << endl;
  } else if(sampling == STRAT_MAG) {
    out << "2" << endl;
  } else if(sampling == STRAT_ERR) {
    out << "3" << endl;
  }
  out << region.size() << endl;
  for(int j = 0; j < region.size(); j++) {
    out << region[j].xLow << endl;
    out << region[j].xHigh << endl;
    out << region[j].grid.size() << endl;
    for(int k = 0; k < region[j].grid.size(); k++) {
      out << region[j].grid[k] << endl;
    }
  }
  out.close();
}

void Vegas::readFromFile(string inputFile) {
  ifstream in(inputFile.c_str());
  in >> nDim;
  in >> alpha;
  in >> nDiv;
  in >> si;
  in >> sWeight;
  in >> sChi;
  in >> xnd;
  in >> maxweight;
  int sampleType;
  in >> sampleType;
  if(sampleType == 2) sampling = STRAT_MAG;
  else if(sampleType == 3) sampling = STRAT_ERR;
  else sampling = IMPORT;
  int regionSize;
  in >> regionSize;
  region.resize(regionSize);
  for(int j = 0; j < regionSize; j++) {
    in >> region[j].xLow;
    in >> region[j].xHigh;
    int gridSize;
    in >> gridSize;
    region[j].grid.resize(gridSize);
    for(int k = 0; k < gridSize; k++) {
      in >> region[j].grid[k];
    }
  }
  in.close();
}

// static const variables
const int Vegas::maxNDiv = 50;
const double Vegas::tinyNumber = 1.e-30;
