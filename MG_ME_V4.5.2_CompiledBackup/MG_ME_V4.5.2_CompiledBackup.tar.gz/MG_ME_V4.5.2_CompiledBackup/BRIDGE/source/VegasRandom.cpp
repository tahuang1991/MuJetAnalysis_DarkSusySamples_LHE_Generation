#include "VegasRandom.h"
#include <cstdlib>
#include <ctime>
using namespace std;

void VegasRandom::Seed(unsigned int seed) {
  srand(seed);
  theSeed = seed;
}

void VegasRandom::SeedWithTime() {
  theSeed = (unsigned int) time(0);
  srand(theSeed);
}

double VegasRandom::operator()() {
  return double(rand())/RAND_MAX;
}

unsigned int VegasRandom::GetUsedSeed() {
  return theSeed;
}

