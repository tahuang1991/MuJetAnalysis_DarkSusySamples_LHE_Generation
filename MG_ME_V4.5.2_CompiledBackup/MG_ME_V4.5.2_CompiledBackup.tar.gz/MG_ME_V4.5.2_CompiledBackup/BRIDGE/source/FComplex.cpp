#include "FComplex.h"

// make a C++ complex number from a Fortran complex:
std::complex<double> FCxToCCx(Complex c) {
  return std::complex<double>(c.re,c.im);
}

// make a Fortran complex from a C++ complex:
Complex CCxToFCx(std::complex<double> c) {
  Complex z;
  z.re = c.real();
  z.im = c.imag();
  return z;
}
