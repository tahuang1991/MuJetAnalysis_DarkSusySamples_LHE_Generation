#include "Amplitude.h"
using namespace std;

// Declare HELAS routines
extern "C" void iosxxx_(Complex*,Complex*,Complex*,Complex*,Complex&);
extern "C" void iovxxx_(Complex*,Complex*,Complex*,Complex*,Complex&);
extern "C" void vvsxxx_(Complex*,Complex*,Complex*,Complex&,Complex&);
extern "C" void vssxxx_(Complex*,Complex*,Complex*,Complex&,Complex&);
extern "C" void sssxxx_(Complex*,Complex*,Complex*,Complex&,Complex&);
extern "C" void vvvxxx_(Complex*,Complex*,Complex*,double&,Complex&);
extern "C" void ssssxx_(Complex*,Complex*,Complex*,Complex*,Complex&,Complex&);
extern "C" void vvssxx_(Complex*,Complex*,Complex*,Complex*,Complex&,Complex&);

// example of a user-defined routine: glue-glue-Higgs
#ifdef USE_VVSJXX
extern "C" void vvsjxx_(Complex*,Complex*,Complex*,Complex&,Complex&);
#endif

// compute a fermion-fermion-scalar amplitude
complex<double> FFSAmp(FermionWaveFunction fIn, FermionWaveFunction fOut,
		       ScalarWaveFunction s, 
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  Complex theCouplings[2];
  theCouplings[0] = CCxToFCx(couplings[0]);
  theCouplings[1] = CCxToFCx(couplings[1]);
  iosxxx_(fIn.FWF, fOut.FWF, s.SWF, theCouplings, theAmp);
  return FCxToCCx(theAmp);
}

// compute a fermion-fermion-vector amplitude
complex<double> FFVAmp(FermionWaveFunction fIn, FermionWaveFunction fOut,
		       VectorWaveFunction v,
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  Complex theCouplings[2];
  theCouplings[0] = CCxToFCx(couplings[0]);
  theCouplings[1] = CCxToFCx(couplings[1]);
  iovxxx_(fIn.FWF, fOut.FWF, v.VWF, theCouplings, theAmp);
  return FCxToCCx(theAmp);
}

// compute a vector-vector-scalar amplitude
complex<double> VVSAmp(VectorWaveFunction v1, VectorWaveFunction v2,
		       ScalarWaveFunction s,
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  Complex theCoupling = CCxToFCx(couplings[0]);
  if(usrFlag == 'J') { // use the user-defined routine
#ifdef  USE_VVSJXX
    vvsjxx_(v1.VWF,v2.VWF,s.SWF,theCoupling,theAmp);
#else
    vvsxxx_(v1.VWF,v2.VWF,s.SWF,theCoupling,theAmp);
#endif
  } else {
    vvsxxx_(v1.VWF,v2.VWF,s.SWF,theCoupling,theAmp);
  }
  return FCxToCCx(theAmp);
}

// compute a vector-scalar-scalar amplitude
complex<double> VSSAmp(VectorWaveFunction v, ScalarWaveFunction s1,
		       ScalarWaveFunction s2, 
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  Complex theCoupling = CCxToFCx(couplings[0]);
  vssxxx_(v.VWF,s1.SWF,s2.SWF,theCoupling,theAmp);
  return FCxToCCx(theAmp);
}

// compute a scalar-scalar-scalar amplitude
complex<double> SSSAmp(ScalarWaveFunction s1, ScalarWaveFunction s2,
		       ScalarWaveFunction s3, 
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  Complex theCoupling = CCxToFCx(couplings[0]);
  sssxxx_(s1.SWF,s2.SWF,s3.SWF,theCoupling,theAmp);
  return FCxToCCx(theAmp);
}

// compute a vector-vector-vector amplitude
// assumption?: w-, w+, j3 or a
complex<double> VVVAmp(VectorWaveFunction v1, VectorWaveFunction v2,
		       VectorWaveFunction v3, 
		       vector< complex<double> > couplings,
		       char usrFlag)
{
  Complex theAmp;
  double theCoupling = couplings[0].real();
  vvvxxx_(v1.VWF,v2.VWF,v3.VWF,theCoupling,theAmp);
  return FCxToCCx(theAmp);
}

// Four-particle amplitudes
// four scalars
complex<double> SSSSAmp(ScalarWaveFunction s1, ScalarWaveFunction s2,
                        ScalarWaveFunction s3, ScalarWaveFunction s4,
                        vector< complex<double> > couplings,
                        char usrFlag)
{
  Complex theAmp;
  Complex theCoupling = CCxToFCx(couplings[0]);
  ssssxx_(s1.SWF, s2.SWF, s3.SWF, s4.SWF, theCoupling, theAmp);
  return FCxToCCx(theAmp);
}

// two vectors, two scalars
complex<double> VVSSAmp(VectorWaveFunction v1, VectorWaveFunction v2,
                        ScalarWaveFunction s1, ScalarWaveFunction s2,
                        vector< complex<double> > couplings,
                        char usrFlag)
{
  Complex theAmp;
  Complex theCoupling = CCxToFCx(couplings[0]);
  vvssxx_(v1.VWF, v2.VWF, s1.SWF, s2.SWF, theCoupling, theAmp);
  return FCxToCCx(theAmp);
}
