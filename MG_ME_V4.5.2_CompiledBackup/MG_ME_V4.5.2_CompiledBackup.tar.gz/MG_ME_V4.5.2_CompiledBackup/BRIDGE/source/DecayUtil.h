#ifndef DECAY_UTIL_H
#define DECAY_UTIL_H

#include <string>

double LambdaMG(double s, double ma2, double mb2);

#endif
