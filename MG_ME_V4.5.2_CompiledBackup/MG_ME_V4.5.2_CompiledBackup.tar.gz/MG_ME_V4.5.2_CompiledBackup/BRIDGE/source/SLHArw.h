#ifndef SLHArw_h
#define SLHArw_h

#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<algorithm>
#include<fstream>
#include<cctype>
#include "rw_events.h"
#include "Particle.h"
#include "BRI.h"


struct SLHA
{

  double alpha,mu,tanb,vev;
  std::map<int, double> mass;
  double nmix[4][4],umix[2][2],vmix[2][2];
  double stopmix[2][2],sbotmix[2][2],staumix[2][2];
  double au[3],ad[3],ae[3];
  double yu[3],yd[3],ye[3];
  double g1,g2,g3;
  double alphaem,gf,alphas,mz,mb,mt,mtau;
  double mw,s2w;

};

void read_SLHA(SLHA& header,std::ifstream& in);
void read_SLHA_mass(std::ifstream& in);

void readmass(SLHA& header,std::ifstream& in);
void readmassmg(std::ifstream& in);
void readnmix(SLHA& header,std::ifstream& in);
void readumix(SLHA& header,std::ifstream& in);
void readvmix(SLHA& header,std::ifstream& in);
void readstopmix(SLHA& header,std::ifstream& in);
void readsbotmix(SLHA& header,std::ifstream& in);
void readstaumix(SLHA& header,std::ifstream& in);
void readalpha(SLHA& header,std::ifstream& in);
void readhmix(SLHA& header,std::ifstream& in);
void readau(SLHA& header,std::ifstream& in);
void readad(SLHA& header,std::ifstream& in);
void readae(SLHA& header,std::ifstream& in);
void readyu(SLHA& header,std::ifstream& in);
void readyd(SLHA& header,std::ifstream& in);
void readye(SLHA& header,std::ifstream& in);
void readsminputs(SLHA& header,std::ifstream& in);
void readmgsmparam(SLHA& header,std::ifstream& in);
void readgauge(SLHA& header,std::ifstream& in);
std::string stringtoupper(std::string in);


#endif
