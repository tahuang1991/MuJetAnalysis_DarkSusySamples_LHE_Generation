#ifndef DECAY_DRIVER_H
#define DECAY_DRIVER_H

#include "DecayMode.h"
#include "VegasCallable.h"
#include "VegasRandom.h"
#include <vector>

class VCWithRandom : public VegasCallable {
 public:
 VCWithRandom() : getRandom(NULL) {}
 VCWithRandom(VegasRandom* vr) : getRandom(vr) {}
 virtual ~VCWithRandom() {}

  void SetRandom(VegasRandom* vr) { getRandom = vr; }
  int GetRandomHelicity(std::string particle);

 protected:
  VegasRandom* getRandom;
};

// Given a two-body decay, mediate between it and the Vegas
// integrator to allow width calculation and event decays.
class TwoBodyDecayDriver : public VCWithRandom {
 public:
 TwoBodyDecayDriver() : VCWithRandom() {}
 TwoBodyDecayDriver(VegasRandom* vr) : VCWithRandom(vr) {}
 virtual ~TwoBodyDecayDriver() {}

  void SetDecayMode(TwoBodyDecayMode* dmIn) {
    dm = dmIn;
  }

  TwoBodyDecayMode* GetDecayMode() {
    return dm;
  }

  // This is what Vegas calls to get the function.
  // We are integrating over two-dimensions, each valued in [0.,1.]:
  // x[0] = (cos(theta)+1)/2.
  // x[1] = phi/(2 pi)
  // This function uses these Vegas inputs to set up daughter decay
  // momenta and then evaluate the differential cross section.
  // Helicities of daughters are chosen randomly.
  double VegasInput(std::vector<double> x, double weight);

  // vegasCalling: now don't look at us,
  // all that phony Elvis mania has bitten the dust.
  // Ahem.
  // If vegasCalling == true, the mother momentum is set to just
  // be a rest frame momentum.
  // If vegasCalling == false, the mother momentum is taken
  // from its current value (which can be set by the user with
  // SetMotherMomentum).
  double RunEvent(std::vector<double> x, double weight,
		  bool vegasCalling = false);

  // Functions used in calculating differential cross section:
  // Set up daughter momenta and evaluate phase space factor.
  double PhaseSpace();
  // Call PhaseSpace() to set up daughter momenta, also get
  // the amplitude from the decay mode and use to compute
  // the full differential cross section.
  double DecayEvent();
  
  void SetMotherMomentum(FourVector PIn);
  FourVector MotherMomentum();
  FourVector Daughter1Momentum();
  FourVector Daughter2Momentum();

 private:
  TwoBodyDecayMode* dm;
  FourVector P[3];
  double randIn[2];
};

class ThreeBodyDecayDriver : public VCWithRandom {
 public:
 ThreeBodyDecayDriver(VegasRandom* vr) : VCWithRandom(vr), maxweight(-1.) {}
 ~ThreeBodyDecayDriver() {}

  void SetDecayMode(ThreeBodyDecayMode* dmIn) {
    dm = dmIn;
  }

  ThreeBodyDecayMode* GetDecayMode() {
    return dm;
  }

  // What Vegas calls.
  double VegasInput(std::vector<double> x, double weight);
  double RunEvent(std::vector<double> x, double weight,
		  bool vegasCalling = false);

  // Functions used in calculating differential cross section:
  // Set up daughter momenta and evaluate phase space factor.
  double PhaseSpace(bool debug=false);
  // Call PhaseSpace() to set up daughter momenta, also get
  // the amplitude from the decay mode and use to compute
  // the full differential cross section.
  double DecayEvent(bool debug=false);

  void SetMotherMomentum(FourVector PIn);
  FourVector MotherMomentum();
  FourVector Daughter1Momentum();
  FourVector Daughter2Momentum();
  FourVector Daughter3Momentum();

 private:
  ThreeBodyDecayMode* dm;
  FourVector P[4];
  double randIn[5];
  double maxweight;
};

#endif
