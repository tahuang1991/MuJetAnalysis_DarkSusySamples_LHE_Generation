#include "DecayMode.h"
#include "WaveFunctions.h"
#include "Amplitude.h"
#include "OffShell.h"
#include <math.h>
#include <cassert>
#include <iostream>
using namespace std;

string DecayMode::Parent() {
  return parent;
}

vector<string> DecayMode::ListDaughters() {
  return products;
}

int DecayMode::NumberDaughters() {
  return products.size();
}

double DecayMode::SumDaughtersMass() {
  double sm = 0;
  for(int i = 0; i < products.size(); i++)
    sm += fabs(Particle::pl[products[i]].Mass());
  return sm;
} 

bool DecayMode::SanityCheck() {
  return (Particle::pl[parent].Mass() > SumDaughtersMass());
}

TwoBodyDecayMode::TwoBodyDecayMode(std::string mo, std::string d1, 
                   std::string d2, Vertex vtx)
  : vertex(vtx)
{
  parent = mo;
  products.push_back(d1);
  products.push_back(d2);
}

// two-body kinematics result
// c.o.m. frame: (M,0) -> (E1,P)+(E2,-P)
// what is P, given M, m1, m2?
double TwoBodyDecayMode::PSq(double MSq, double m1Sq, double m2Sq) {
  assert(MSq != 0.0);
  double num = MSq*(MSq - 2*(m1Sq + m2Sq)) + (m1Sq-m2Sq)*(m1Sq-m2Sq);
  double denom = 4*MSq;
  return (num/denom);
}

// two-body width up to factor of |M|^2
double TwoBodyDecayMode::PhaseSpace(double M, double m1, double m2) {
  double PS = PSq(M*M,m1*m1,m2*m2);
  double E1 = sqrt(m1*m1+PS);
  double E2 = sqrt(m2*m2+PS);
  double P = sqrt(PS);
  return P/(16.0*E1*E2*M_PI);
}

bool TwoBodyDecayMode::SanityCheck(std::string type, int spinI, 
                   int spin1, int spin2) {
  bool result = true;
  result = result && (vertex.Type() == type);
  result = result && (products.size() == 2);
  result = result && (Particle::pl[parent].TwiceSpin() == spinI);
  result = result && (Particle::pl[products[0]].TwiceSpin() == spin1);
  result = result && (Particle::pl[products[1]].TwiceSpin() == spin2);

  result = result && DecayMode::SanityCheck();

  return result;
}

double TwoBodyDecayMode::ColorFactor()
{
  if(Particle::pl[parent].NColors() == 1) {
    if(Particle::pl[products[0]].NColors() == 3) {
      return 3;
    } else if(Particle::pl[products[0]].NColors() == 8) {
      return 8;
    }
    return 1;
  } else if(Particle::pl[parent].NColors() == 3) {
    if(Particle::pl[products[0]].NColors() == 1) {
      return 1;
    } else if(Particle::pl[products[0]].NColors() == 3) {
      if(Particle::pl[products[1]].NColors() == 1) {
    return 1;
      } else if(Particle::pl[products[1]].NColors() == 8) {
    return 4/3.; // C_F
      }
    } else if(Particle::pl[products[0]].NColors() == 8) {
      if(Particle::pl[products[1]].NColors() == 3) {
    return 4/3.; // C_F
      }
    }
  } else if(Particle::pl[parent].NColors() == 8) {
    if(Particle::pl[products[0]].NColors() == 3
       && Particle::pl[products[1]].NColors() == 3) {
      return 0.5; // trace over indices
    } else if(Particle::pl[products[0]].NColors() == 8
          && Particle::pl[products[1]].NColors() == 8) {
      return 3; // C_A
    }
  }
  return 1;
  // TODO: fill in all the possibilities
}

bool S_FF::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("FFS",0,1,1);
}

complex<double> S_FF::Amplitude(FourVector P[3])
{
  ScalarWaveFunction sIn;
  FermionWaveFunction f1,f2;
  bool negMass1 = (Particle::pl[products[0]].Mass() < 0);
  bool negMass2 = (Particle::pl[products[1]].Mass() < 0);
  sIn = GetScalarWave(P[0],S_IN);
  f1 = GetFermionWave(P[1],F_OUTPART,negMass1);
  f2 = GetFermionWave(P[2],F_INANTI,negMass2);
  return FFSAmp(f2,f1,sIn,vertex.Couplings(),vertex.UserFlag());
}

bool S_SS::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("SSS",0,0,0);
}

complex<double> S_SS::Amplitude(FourVector P[3])
{
  ScalarWaveFunction sIn, s1, s2;
  sIn = GetScalarWave(P[0],S_IN);
  s1 = GetScalarWave(P[1],S_OUT);
  s2 = GetScalarWave(P[2],S_OUT);
  return SSSAmp(sIn,s1,s2,vertex.Couplings(),vertex.UserFlag());
}

bool S_VS::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("VSS",0,2,0);
}

complex<double> S_VS::Amplitude(FourVector P[3])
{
  ScalarWaveFunction sIn,sOut;
  VectorWaveFunction v1;
  sIn = GetScalarWave(P[0],S_IN);
  v1 = GetVectorWave(P[1],V_OUT);
  sOut = GetScalarWave(P[2],S_OUT);
  return VSSAmp(v1,sIn,sOut,vertex.Couplings(),vertex.UserFlag());
}

bool S_VV::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("VVS",0,2,2);
}

complex<double> S_VV::Amplitude(FourVector P[3])
{
  ScalarWaveFunction sIn;
  VectorWaveFunction v1, v2;
  sIn = GetScalarWave(P[0],S_IN);
  v1 = GetVectorWave(P[1],V_OUT);
  v2 = GetVectorWave(P[2],V_OUT);
  return VVSAmp(v2,v1,sIn,vertex.Couplings(),vertex.UserFlag());
}

bool V_FF::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("FFV",2,1,1);
}

complex<double> V_FF::Amplitude(FourVector P[3])
{
  VectorWaveFunction vIn;
  FermionWaveFunction f1,f2;
  bool negMass1 = (Particle::pl[products[0]].Mass() < 0);
  bool negMass2 = (Particle::pl[products[1]].Mass() < 0);
  vIn = GetVectorWave(P[0],V_IN);
  f1 = GetFermionWave(P[1],F_OUTPART,negMass1);
  f2 = GetFermionWave(P[2],F_INANTI,negMass2);
  return FFVAmp(f2,f1,vIn,vertex.Couplings(),vertex.UserFlag());
}

bool V_SS::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("VSS",2,0,0);
}

complex<double> V_SS::Amplitude(FourVector P[3])
{
  VectorWaveFunction vIn;
  ScalarWaveFunction s1, s2;
  vIn = GetVectorWave(P[0],V_IN);
  s1 = GetScalarWave(P[1],S_OUT);
  s2 = GetScalarWave(P[2],S_OUT);
  return VSSAmp(vIn,s1,s2,vertex.Couplings(),vertex.UserFlag());
}

bool V_VS::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("VVS",2,2,0);
}

complex<double> V_VS::Amplitude(FourVector P[3])
{
  VectorWaveFunction vIn, vOut;
  ScalarWaveFunction sOut;
  vIn = GetVectorWave(P[0],V_IN);
  vOut = GetVectorWave(P[1],V_OUT);
  sOut = GetScalarWave(P[2],S_OUT);
  return VVSAmp(vIn,vOut,sOut,vertex.Couplings(),vertex.UserFlag());
}

bool V_VV::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("VVV",2,2,2);
}

complex<double> V_VV::Amplitude(FourVector P[3])
{
  VectorWaveFunction vIn, v1, v2;
  vIn = GetVectorWave(P[0],V_IN);
  v1 = GetVectorWave(P[1],V_OUT);
  v2 = GetVectorWave(P[2],V_OUT);
  return VVVAmp(v1,v2,vIn,vertex.Couplings(),vertex.UserFlag());
}

bool F_FS::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("FFS",1,1,0);
}

complex<double> F_FS::Amplitude(FourVector P[3])
{
  FermionWaveFunction fIn, fOut;
  ScalarWaveFunction sOut;
  bool negMassIn = (Particle::pl[parent].Mass() < 0);
  bool negMassOut = (Particle::pl[products[0]].Mass() < 0);
  // careful w/ fermion vs antifermion, for angular dists in multi-step decays
  if(Particle::pl[parent].FermionNumber() == 1 || 
     (Particle::pl[parent].FermionNumber() == 2 && Particle::pl[products[0]].FermionNumber() != -1)) {
    fIn = GetFermionWave(P[0],F_INPART,negMassIn);
    fOut = GetFermionWave(P[1],F_OUTPART,negMassOut);
  } else {
    // antifermion
    fIn = GetFermionWave(P[1], F_INANTI, negMassOut);
    fOut = GetFermionWave(P[0], F_OUTANTI, negMassIn);
  }
  sOut = GetScalarWave(P[2],S_OUT);
  return FFSAmp(fIn,fOut,sOut,vertex.Couplings(),vertex.UserFlag());
}

bool F_FV::SanityCheck() {
  return TwoBodyDecayMode::SanityCheck("FFV",1,1,0);
}

complex<double> F_FV::Amplitude(FourVector P[3])
{
  FermionWaveFunction fIn, fOut;
  VectorWaveFunction vOut;
  bool negMassIn = (Particle::pl[parent].Mass() < 0);
  bool negMassOut = (Particle::pl[products[0]].Mass() < 0);
  // careful w/ fermion vs antifermion, for angular dists in multi-step decays
  if(Particle::pl[parent].FermionNumber() == 1 || 
     (Particle::pl[parent].FermionNumber() == 2 && Particle::pl[products[0]].FermionNumber() != -1)) {
    fIn = GetFermionWave(P[0],F_INPART,negMassIn);
    fOut = GetFermionWave(P[1],F_OUTPART,negMassOut);
  } else {
    // antifermion
    fIn = GetFermionWave(P[1], F_INANTI, negMassOut);
    fOut = GetFermionWave(P[0], F_OUTANTI, negMassIn);
  }
  vOut = GetVectorWave(P[2],V_OUT);
  return FFVAmp(fIn,fOut,vOut,vertex.Couplings(),vertex.UserFlag());
}


