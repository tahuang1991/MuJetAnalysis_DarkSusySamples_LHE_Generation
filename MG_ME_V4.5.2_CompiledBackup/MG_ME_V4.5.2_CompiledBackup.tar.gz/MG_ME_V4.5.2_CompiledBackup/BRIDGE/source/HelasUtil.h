#ifndef HELAS_UTIL_H
#define HELAS_UTIL_H

// Declare external Fortran routines:
// HELAS routine to set up two four-momenta in the two-particle
// rest frame
extern "C" void mom2cx_(double&,double&,double&,double&,double&,
			double*,double*);
// HELAS routine to boost a four-vector, p, given in the rest frame
// of q, to the frame in which q is given
extern "C" void boostx_(double*,double*,double*);
// HELAS routine to rotate a four-vector, p, given in the frame where
// the spatial component of q points along the positive z-axis, to
// the frame where q is given
extern "C" void rotxxx_(double*,double*,double*);

#endif
