#ifndef FOURVECTOR_H
#define FOURVECTOR_H

#include <math.h>

// Four-vector, with associated helicity
class FourVector {
 public:
  double & E() {
    return P[0];
  }
  double & Px() { 
    return P[1];
  }
  double & Py() {
    return P[2];
  }
  double & Pz() {
    return P[3];
  }
  double PSpace() {
    return sqrt(P[1]*P[1]+P[2]*P[2]+P[3]*P[3]);
  }
  double M() {
    double pp = PSpace();
    double msq = P[0]*P[0]-pp*pp;
    if(msq < 0. && msq > -1.e-6)
      msq = 0.;
    // if it's otherwise tachyonic, throw an exception?
    return sqrt(msq);
  }

  // this is accessible directly, for ease
  // of calling Fortran code
  double P[4];

  // for convenience, keep helicity in the four-vector
  int Helicity;
};

#endif
