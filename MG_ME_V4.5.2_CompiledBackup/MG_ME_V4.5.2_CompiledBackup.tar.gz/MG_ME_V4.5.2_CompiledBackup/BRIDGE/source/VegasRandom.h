#ifndef VEGAS_RANDOM_H
#define VEGAS_RANDOM_H

// Something for Vegas to get a random number from (between 0 and 1),
// inherit if you want something fancier than double(rand())/RAND_MAX...
class VegasRandom {
 public:
  VegasRandom() { SeedWithTime(); }
  VegasRandom(unsigned int seed) { Seed(seed); }
  virtual ~VegasRandom() {}
  void Seed(unsigned int seed);
  void SeedWithTime();
  virtual double operator()();
  unsigned int GetUsedSeed();
 private:
  unsigned int theSeed;
};

#endif
