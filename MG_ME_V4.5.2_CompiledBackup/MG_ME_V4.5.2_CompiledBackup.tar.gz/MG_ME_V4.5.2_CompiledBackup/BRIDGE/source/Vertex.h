#ifndef VERTEX_H
#define VERTEX_H

#include <string>
#include <vector>
#include <complex>

#include "Particle.h"

class Vertex {
 public:
  // Access information
  int Count();
  std::complex<double> Coupling1();
  std::complex<double> Coupling2();
  std::vector< std::complex<double> > Couplings();
  std::string Leg(int i);
  int Multiplicity(std::string p);
  bool Decays(std::string p);
  std::string Type();
  std::string getCouplingName();
  char UserFlag();

  // Alter the vertex
  void SetCoupling(std::string theCouplingName);
  void AddParticle(std::string p);
  void SetType(std::string theType);
  void SetUserFlag(char usrf);

  // This is the global vertex list
  static std::list<Vertex> vl;

  // Read in the vertices from a file
  static void ParseMGFile(std::string filename);

 protected:
  std::vector<std::string> particles;
  std::string thetype;
  std::string couplingName;
  char usrFlag;
};

#endif
