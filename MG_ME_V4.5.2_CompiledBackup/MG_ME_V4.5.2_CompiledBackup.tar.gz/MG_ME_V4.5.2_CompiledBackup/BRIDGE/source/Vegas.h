// C++ Vegas Integrator.
// This is based on the MadGraph Vegas code, 
// which is very close to the Numerical Recipes code,
// which is based on the original code by Peter Lepage.
// (J. Comput. Phys. 27: 192, 1978; preprint CLNS-80/447)
// I've cleaned up the interface a bit to make it more
// C++-friendly.

#ifndef VEGAS_H
#define VEGAS_H

#include "VegasCallable.h"
#include "VegasRandom.h"
#include <vector>
#include <iostream>

// Return values of Vegas: integral, with standard deviation
// and chi^2 per degree of freedom.
struct VegasOutput {
  double integral;
  double sigma;
  double chi2dof;
};

struct Interval {
  double xLow;
  double xHigh;
  double Length() {
    return xHigh - xLow;
  }

  // grid[i] = location of subdivision #i of the interval,
  // NORMALIZED TO LIE BETWEEN 0 AND 1.
  std::vector<double> grid;

  void Rebin(double rc, int ndiv, std::vector<double> r);
};

typedef std::vector<Interval> Region;

// Vegas integrator
class Vegas {
 public:
  Vegas(Region r, VegasCallable *f, VegasRandom *vr,
	std::ostream *out, double aleph = 1.5);

  // Options for output:
  // PRINT_ALL : print integral, standard deviation, chi^2, and grid
  //             information for each iteration.
  // PRINT : print integral, standard deviation, and chi^2 each iteration
  // NOPRINT : print nothing.
  enum Verbosity {PRINT_ALL, PRINT, NOPRINT};

  // Options for sampling method:
  // IMPORT: Vegas uses importance sampling only.
  // STRAT_MAG: Importance sampling + stratified sampling,
  //            increments concentrated where integrand is largest
  // STRAT_ERR: Increments concentrated where contribution to error
  //            is the largest.
  enum SampleMethod {IMPORT, STRAT_MAG, STRAT_ERR};

  void resetAnswers();

  // The main integration routine
  // nCall = Approx. number of integrand evaluations per
  //         iteration. Actual number is returned.
  // maxIter = Maximum number of iterations.
  // 
  VegasOutput integrate(int & nCall, int maxIter, bool runInit,
			Verbosity v = NOPRINT);

  // Get a set of random numbers based on the current grid.
  // This is based on the "GET_X" function in Madgraph's decay_event.f
  // It fills the input "x" with random numbers, one for each dimension,
  // and returns a weight.
  double getRandomFromGrid(std::vector<double>& x);

  double MaxWeight() { return maxweight; }

  // Input/output of grids to avoid excessive computation....
  void writeToFile(std::string outputFile);
  void readFromFile(std::string inputFile);

  VegasRandom* RandomGenerator() { return getRandom; }

 protected:
  Region region;
  SampleMethod sampling;

  int nDim; // number of dimensions of the phase space.
  double alpha;

  // Stored results of integration:
  static const int maxNDiv; // maximum number of subdivisions on an axis.
  static const double tinyNumber; // a tiny number
  int nIter;       // number of completed iterations.
  int nDiv;        // number of subdivisions on an axis.
  double si;       // Sum_{1,nIter} S_{alpha}/sigma_{alpha}^2
  double sWeight;  // Sum_{1,nIter} 1/sigma_{alpha}^2
  double sChi;     // Sum_{1,nIter} S_{alpha}^2 / sigma_{alpha}^2
  double xnd;      // saved for getRandomFromGrid... precise definition?
  double maxweight;

  VegasCallable *theFunction;
  VegasRandom* getRandom;
  std::ostream* output;
};

#endif
