#include "BRI.h"
#include <iostream>
#include <fstream>
#include <vector>
#include "SLHArw.h"
#include "SUSYpara.h"
#include "batchhelper.h"
using namespace std;

int main(int argc, char *argv[]) {
  vector<string> pargs;
  if(argc>1)
  {
	 if(runbribatchsusy(argc,argv,pargs)==0)
		return 0;
  }
  bool batch;
  if(pargs.size()!=0)
	  batch=true;
  else
	  batch=false;
  // read parameters
  SLHA temp;
  
  string particlefile;
  if(batch)
  {
	  particlefile=pargs[0];
  }
  else
  {
  cout << "Name of particle file (input/mssmparticles.dat): ";
  getline(cin,particlefile);
  }
  checkfile(particlefile);
  if(particlefile == "") particlefile = "input/mssmparticles.dat";
  Particle::ParseMGFile(particlefile);
  
  string parameterfile;
  if(batch)
  {
	  parameterfile=pargs[1];
  }
  else
  {
  cout << "Name of the SLHA formatted spectrum file (input/param_card.dat): ";
  getline(cin,parameterfile);
  }
  checkfile(parameterfile);
  if(parameterfile == "") parameterfile = "input/param_card.dat";
  
  ifstream susyparam(parameterfile.c_str());
  read_SLHA(temp,susyparam);
  SUSYpara(temp);
  
  string interactionsfile;
  if(batch)
  {
	  interactionsfile=pargs[2];
  }
  else
  {
  cout << "Name of interactions file (input/mssminteractions.dat): ";
  getline(cin,interactionsfile);
  }
  checkfile(interactionsfile);
  if(interactionsfile == "") interactionsfile = "input/mssminteractions.dat";
  Vertex::ParseMGFile(interactionsfile);

  string directory;
  if(batch)
  {
	  directory=pargs[3];
  }
  else
  {
  cout << "Please enter the (relative) directory to which you want to save the grids.\n(Include the / at the end; the directory must already exist): ";
  getline(cin,directory);
  }
  if(directory == "") directory = "results/";

  string slhadecfile;
  if(batch)
  {
	  slhadecfile=pargs[4];
  }
  else
  {
  cout << "What file do you wish to place the SLHA decays in(include relative path)?" << endl;
  cin >> slhadecfile;
  }
  ofstream slhaout(slhadecfile.c_str(), ofstream::ate);
 
  //choose which type of running modes and which particles
  vector<string> particlelist;
  int nparticles;
  if(batch)
  {
          nparticles=atoi(pargs[pargs.size()-1].c_str());
	  for(int i=5;i<5+nparticles;i++)
	  {
		  particlelist.push_back(pargs[i]);
	  }
  }
  else
  {
	particlechoice(particlelist);
  }
  
  //set up seed for decays
  string randseed;
  if(batch)
  {
	  randseed=pargs[5+nparticles];
  }
  else
  {
	cout << "Please enter a random number seed or write 'time' to use the time\n";
	cin >> randseed;
  }
  unsigned int theseedtouse;
  int c1=-1;
  istringstream iss(randseed);
  if(!(iss >> theseedtouse).fail()) {
    cout << "We understood that as " << theseedtouse << ", using that seed\n";
    c1=1;  
  } else {
    cout << "Using the time.\n";
  }
  
  int ncall = 50000;
  string yesno;
  if(batch)
  {
	  ncall=atoi(pargs[6+nparticles].c_str());
  }
  else
  {
	cout << "The default number of Vegas calls is 50000. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y") {
		cout << "How many Vegas calls do you want to use? ";
		cin >> ncall;
	}
  }
  
  int maxiter = 5;
  if(batch)
  {
	  maxiter=atoi(pargs[7+nparticles].c_str());
  }
  else
  {
	cout << "The default max. number of Vegas iterations is 5. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y") {
		cout << "What max. no. of Vegas iterations do you want to use? ";
		cin >> maxiter;
	}
  }

  if(batch)
  {
    yesno = pargs[8+nparticles];
  }
  else
  {
    cout << "Would you like to calculate three-body widths even for particles with open 2-body channels? (Y/N) ";
    cin >> yesno;
  }
  bool calc3if2;
  if(yesno == "Y" || yesno == "y" || yesno == "yes" || yesno == "YES")
  {
    calc3if2 = true;
  }
  else
  {
    calc3if2 = false;
  }
  
  VegasRandom vr;
  if(c1==1)
    vr.Seed(theseedtouse);

  //loop in decay tables;
  // do all two-body decays before any 3-body decays
  vector<double> twobodywidths(particlelist.size());
  vector<BRI> decayManager;
  for(int i=0;i<particlelist.size();i++)
  {
  
    cout << "NOW CALCULATING TWO-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable =directory + testparticle + "_decays.table";
    ifstream input(decayTable.c_str());
    string line;
    if(getline(input,line)) {
      cout << "Decay table appears to already exist. Should we recreate it? ";
      cout << "Type 'yes' if so, otherwise we will exit.\n";
      string response;
      cin >> response;
      if(response != "yes") {
        cout << "Exiting now.\n";
        return 0;
      }
    }

    BRI bri(testparticle, &vr, directory);
    bri.setNumberVegasCalls(ncall);
    bri.setMaxVegasIter(maxiter);
    bri.buildModeList();
    decayManager.push_back(bri);
    cout << "We found the decay modes: \n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << "\n";
    }

    cout << "Now computing the two-body widths: \n";
    twobodywidths[i] = decayManager[i].computeTwoBodyWidths();
    cout << "Listing two-body branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }

    // Set width parameter for use in further calculations, if it's currently set to zero
    if(Particle::pl[testparticle].Width() == 0.) {
      string plwidth = testparticle + "__brcalcwidth";
      Values::v[plwidth] = twobodywidths[i];
      Values::v2[plwidth] = 0.0;
      Particle::pl[testparticle].SetWidth(plwidth);
    }
  }
  // loop again for three-body widths
  for(int i=0;i<particlelist.size();i++)
  {  
    cout << "NOW CALCULATING THREE-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable =directory + testparticle + "_decays.table";

    if((twobodywidths[i] == 0.) || (twobodywidths[i] != 0. && calc3if2)) {
      cout << "Now computing the three-body widths: \n";
      decayManager[i].computeThreeBodyWidths(twobodywidths[i]);
    } else {
      cout << "No three-body modes to calculate for this particle, moving on to output.\n";
    }
    cout << "Writing decay table.\n";
    decayManager[i].writeBRTable();
    decayManager[i].writeSLHAtable(slhaout);
    cout << "Listing final branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k = 0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }
    cout << "Finished particle.\n";
    //end of overall for loop
  }
  
  return 0;
}
