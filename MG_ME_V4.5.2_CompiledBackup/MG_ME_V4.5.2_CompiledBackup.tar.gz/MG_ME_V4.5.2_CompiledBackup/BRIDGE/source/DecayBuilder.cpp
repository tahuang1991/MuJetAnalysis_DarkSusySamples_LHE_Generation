#include "Vertex.h"
#include "DecayMode.h"
#include "DecayBuilder.h"
#include "Error.h"
#include <iostream>
#include <sstream>
using namespace std;

// helper function: make a 2-body decay mode using a vertex
TwoBodyDecayMode * TwoBodyDecayFromVertex(Vertex & v, string p) {
  // Add a decay mode using this vertex
  if(v.Count() == 3) {
    try {
      int p_2Spin = Particle::pl[p].TwiceSpin();
      int d1_2Spin, d2_2Spin;
      string d1, d2;
      if(v.Leg(0) == p) {
	d1_2Spin = Particle::pl[v.Leg(1)].TwiceSpin();
	d1 = v.Leg(1);
	d2_2Spin = Particle::pl[v.Leg(2)].TwiceSpin();
	d2 = v.Leg(2);
      }
      else if(v.Leg(1) == p) {
	d1_2Spin = Particle::pl[v.Leg(0)].TwiceSpin();
	d1 = v.Leg(0);
	d2_2Spin = Particle::pl[v.Leg(2)].TwiceSpin();
	d2 = v.Leg(2);
      }
      else if(v.Leg(2) == p) {
	d1_2Spin = Particle::pl[v.Leg(0)].TwiceSpin();
	d1 = v.Leg(0);
	d2_2Spin = Particle::pl[v.Leg(1)].TwiceSpin();
	d2 = v.Leg(1);
      }
      // Build up string to use to report error if necessary
      ostringstream ost;
      ost << "Building decay mode of particle ";
      ost << p << " to particles " << d1 << " and " << d2 << "\n";
      ost << "The spins are not in a configuration that is recognized\n";
      ost << "by this code. It may not be implemented in HELAS, the \n";
      ost << "interface may not exist, or you might have something that\n";
      ost << "is not Lorentz invariant.\n";
      if((d1_2Spin + d2_2Spin + p_2Spin) % 2 != 0) {
	ost << "In particular, you seem to have an odd number of fermions.\n";
      }
      string err = ost.str();
      if(p_2Spin == 0) {
	if(d1_2Spin == 0 && d2_2Spin == 0) {
	  // Add new "S_SS" decay
	  // Fixed to use conventions compatible both with FeynRules
	  // output and the MG mssm model
	  // The right convention is that a coupling "a b c" allows
	  // the decays a~ -> b c, b~ -> a c, and c~ -> a b
	  // When reading particles in Vertex.cpp, we changed "a b c"
	  // to "a~ b~ c~", so invert the two daughters
	  d1 = Particle::pl[d1].Antiparticle();
	  d2 = Particle::pl[d2].Antiparticle();
	  S_SS* dm = new S_SS(p,d1,d2,v);
	  return dm;
	}
	else if(d1_2Spin == 2 && d2_2Spin == 2) {
	  // Add new "S_VV" decay
	  S_VV* dm = new S_VV(p,d1,d2,v); 
	  return dm;
	}
	else if(d1_2Spin == 1 && d2_2Spin == 1) {
	  // Add new "S_FF" decay
	  // Convention: MG "f1 f2 s" translated internally to "f1 f2~ s*" 
	  // allows s* > f2 f1~, so need to take antiparticle of both daughters
	  d1 = Particle::pl[d1].Antiparticle();
	  d2 = Particle::pl[d2].Antiparticle();
	  S_FF* dm = new S_FF(p,d1,d2,v);
//	  cout << "Adding S_FF with p = " << p << ", d1 = " << d1 << ", d2 = " << d2 
//               << ", coupling name = " << v.getCouplingName() << "\n";
	  return dm;
	}
	else if(d1_2Spin == 2 && d2_2Spin == 0) {
	  // Add new "S_VS" decay
          // template is: w- t2  b1~ should allow t2 -> b1 w+
          //                         or b1~ -> t2~ w+
          // swap a sign
          if(v.Leg(1) == p) {
            d1 = Particle::pl[d1].Antiparticle();
            d2 = Particle::pl[d2].Antiparticle();          
          }
          if(v.Leg(2) == p) {
            d1 = Particle::pl[d1].Antiparticle();
            d2 = Particle::pl[d2].Antiparticle();
          }
	  S_VS* dm = new S_VS(p,d1,d2,v);
	  return dm;
	}
	else if(d1_2Spin == 0 && d2_2Spin == 2) {
	  // Add new "S_VS" decay
          // swap signs
          d1 = Particle::pl[d1].Antiparticle();
          d2 = Particle::pl[d2].Antiparticle();
	  S_VS* dm = new S_VS(p,d2,d1,v);
	  return dm;
	}
	else {
	  throw UnimplementedError(err);
	}
      } else if(p_2Spin == 1) {
	if(d1_2Spin == 1 && d2_2Spin == 0) {
	  // Add new "F_FS" decay
	  // Need to swap the other fermion *and* the scalar
	  d1 = Particle::pl[d1].Antiparticle();
	  d2 = Particle::pl[d2].Antiparticle();
	  F_FS* dm = new F_FS(p,d1,d2,v);
//	  cout << "Adding F_FS with p = " << p << ", d1 = " << d1 << ", d2 = " << d2 
//               << ", coupling name = " << v.getCouplingName() << "\n";
	  return dm;
	} else if(d1_2Spin == 0 && d2_2Spin == 1) {
	  // Add new "F_FS" decay
	  // Need to swap the other fermion *and* the scalar
	  d1 = Particle::pl[d1].Antiparticle();
	  d2 = Particle::pl[d2].Antiparticle();
//	  cout << "Adding F_FS with p = " << p << ", d1 = " << d1 << ", d2 = " << d2 
//               << ", coupling name = " << v.getCouplingName() << "\n";
	  F_FS* dm = new F_FS(p,d2,d1,v);
	  return dm;
	} else if(d1_2Spin == 1 && d2_2Spin == 2) {
	  // Add new "F_FV" decay
	  // Need to swap the other fermion
	  d1 = Particle::pl[d1].Antiparticle();
	  F_FV* dm = new F_FV(p,d1,d2,v);
	  return dm;
	} else if(d1_2Spin == 2 && d2_2Spin == 1) {
	  // Add new "F_FV" decay
	  // Need to swap the other fermion
	  d2 = Particle::pl[d2].Antiparticle();
	  F_FV* dm = new F_FV(p,d2,d1,v);
	  return dm;
	} else {
	  throw UnimplementedError(err);
	}
      } else if(p_2Spin == 2) {
	if(d1_2Spin == 1 && d2_2Spin == 1) {
	  // Add new "V_FF" decay
	  V_FF* dm = new V_FF(p,d1,d2,v);
	  return dm;
	} else if(d1_2Spin == 0 && d2_2Spin == 0) {
	  // Add new "V_SS" decay
          // Need to account for pi+ pi- structure
          // thought is that since we have 2 option neutral or non neutral scalar
          // always swapping a sign will work but no it wont so this is a temporary kludge
          d1 = Particle::pl[d1].Antiparticle();
	  V_SS* dm = new V_SS(p,d1,d2,v);
	  return dm;
	} else if(d1_2Spin == 2 && d2_2Spin == 0) {
	  // Add new "V_VS" decay
          // Need to swap a sign
          d1 = Particle::pl[d1].Antiparticle();
	  V_VS* dm = new V_VS(p,d1,d2,v);
          return dm;
	} else if(d1_2Spin == 0 && d2_2Spin == 2) {
	  // Add new "V_VS" decay
          // Need to swap a sign
          d2 = Particle::pl[d2].Antiparticle();
	  V_VS* dm = new V_VS(p,d2,d1,v);
          return dm;
	} else if(d1_2Spin == 2 && d2_2Spin == 2) {
	  // Add new "V_VV" decay
	  if(v.Leg(2) == p) {
            // Don't swap a sign: this is, e.g., zp -> w+ w-
	    V_VV* dm = new V_VV(p,d1,d2,v);
	    return dm;
	  } else {
	    // Need to swap a sign (e.g. to get wh+ -> w+ ah in LHT)
	    d1 = Particle::pl[d1].Antiparticle();
	    V_VV* dm = new V_VV(p,d1,d2,v);
	    return dm;
	  }	
        } else {
	  throw UnimplementedError(err);
	}
      } else {
        throw UnimplementedError(err);
      }
    }
    catch (UnimplementedError theErr) {
      theErr.report(cerr);
    }
  }
  return NULL;
}

vector<DecayMode *> DecayBuilder::GetTwoBodyDecayModes(string p)
{
  vector<DecayMode *> decayList;
  list<Vertex>::iterator i;
  for(i = Vertex::vl.begin(); i != Vertex::vl.end(); i++) {
    Vertex & v = *i;
    if(v.Multiplicity(p) == 1) {
      if(v.Decays(p)) {
	DecayMode * dm = TwoBodyDecayFromVertex(v,p);
	if(dm != NULL) {
	  decayList.push_back(dm);
	}
      }
    }
  }
  return decayList;
}

vector<DecayMode *> DecayBuilder::GetDecayModes(string p)
{
  // First get the two body modes
  vector<DecayMode *> decayList = GetTwoBodyDecayModes(p);

  // Create a list of 3-body decays to fill
  vector<ThreeBodyDecayMode *> threeDecays;

  // Now look for 3-body decays
  list<Vertex>::iterator i;
  for(i = Vertex::vl.begin(); i != Vertex::vl.end(); i++) {
    Vertex & v = *i;
    if(v.Multiplicity(p) >= 1) {
/*    if(v.Multiplicity(p) == 1 && 
       (Particle::pl[p].Antiparticle() == p || 
        v.Multiplicity(Particle::pl[p].Antiparticle()) == 0)) { */
      // Recursively hunt for decays via off-shell stuff
      if(v.Count() == 3 && !v.Decays(p)) {
	double pmass = Particle::pl[p].Mass();
        // make a 2-body decay object; this will conjugate fields in the proper way.
	TwoBodyDecayMode* dm = TwoBodyDecayFromVertex(v,p);
	if(dm != NULL) {
          // d1 = lighter daughter, d2 = heavier daughter
	  int d1, d2;
	  double lmass, hmass;
          bool identical = false;
          if(dm->ListDaughters()[0] == dm->ListDaughters()[1]) identical = true;
	  if(fabs(Particle::pl[dm->ListDaughters()[0]].Mass()) > 
	       fabs(Particle::pl[dm->ListDaughters()[1]].Mass())) {
	    d1 = 1;
	    d2 = 0;
	    lmass = fabs(Particle::pl[dm->ListDaughters()[1]].Mass());
	    hmass = fabs(Particle::pl[dm->ListDaughters()[0]].Mass());
	  } else {
	    d1 = 0;
	    d2 = 1;
	    lmass = fabs(Particle::pl[dm->ListDaughters()[0]].Mass());
	    hmass = fabs(Particle::pl[dm->ListDaughters()[1]].Mass());
	  }
          if(dm->ListDaughters()[d2] == p && lmass == 0.0) {
            continue;
          }
	  if(lmass < pmass) {
	    // It is, so try to decay the heavier one.
	    vector<DecayMode *> chainDecays = 
	      DecayBuilder::GetTwoBodyDecayModes(dm->ListDaughters()[d2]);
  	    vector<DecayMode *>::iterator d;
	    for(d = chainDecays.begin(); d != chainDecays.end(); d++) {
	      if((*d)->SumDaughtersMass() + lmass < pmass) {
	        // Add a new 3-body decay mode or append to
	        // an existing one.
	        vector<string> theDaughters(3);
	        theDaughters[0] = dm->ListDaughters()[d1];
	        theDaughters[1] = (*d)->ListDaughters()[0];
	        theDaughters[2] = (*d)->ListDaughters()[1];
	        vector<ThreeBodyDecayMode *>::iterator d3;
	        bool decayExists = false;
		TwoBodyDecayMode* dm2 = dynamic_cast<TwoBodyDecayMode*>(*d);
		TwoBodyDecayPair pair;
		pair.pr.first = dm;
		pair.pr.second = dm2;
//                cout << "found pair2, dm1: " << dm->Parent() << " -> " << dm->ListDaughters()[0] << ", "
//		     << dm->ListDaughters()[1] << "\n" << "       dm2: " <<  dm2->Parent() << " -> " 
//                     << dm2->ListDaughters()[0] << ", "
//         	     << dm2->ListDaughters()[1] << "\n";
		for(d3 = threeDecays.begin(); d3 != threeDecays.end(); d3++) {
		  if((*d3)->DecayMatch(pair)) {
		    decayExists = true;
		    (*d3)->AddVertexPair(pair);
		    break;
		  }
		}
		if(!decayExists) {
		  ThreeBodyDecayMode *dm3 = new ThreeBodyDecayMode(pair);
		  threeDecays.push_back(dm3);
		}
	      }
	    }
	  }
	  // check if the heavier one is lighter than p.
	  if(hmass < pmass && !identical) {
	    // It is, so also try to decay the lighter one.
	    vector<DecayMode *> chainDecays = 
	      DecayBuilder::GetTwoBodyDecayModes(dm->ListDaughters()[d1]);
	    vector<DecayMode *>::iterator d;
	    for(d = chainDecays.begin(); d != chainDecays.end(); d++) {
	      if((*d)->SumDaughtersMass() + hmass < pmass) {
	        // Add a new 3-body decay mode or append to
	        // an existing one.
	        vector<ThreeBodyDecayMode *>::iterator d3;
	        bool decayExists = false;
		TwoBodyDecayMode* dm2 = dynamic_cast<TwoBodyDecayMode*>(*d);
		TwoBodyDecayPair pair;
		pair.pr.first = dm;
		pair.pr.second = dm2;
//                cout << "found pair2, dm1: " << dm->Parent() << " -> " << dm->ListDaughters()[0] << ", "
//		     << dm->ListDaughters()[1] << "\n" << "       dm2: " <<  dm2->Parent() << " -> " 
//                     << dm2->ListDaughters()[0] << ", "
//		     << dm2->ListDaughters()[1] << "\n";
		for(d3 = threeDecays.begin(); d3 != threeDecays.end(); d3++) {
		  if((*d3)->DecayMatch(pair)) {
		    decayExists = true;
		    (*d3)->AddVertexPair(pair);
		    break;
		  }
		}
		if(!decayExists) {
		  ThreeBodyDecayMode *dm3 = new ThreeBodyDecayMode(pair);
		  threeDecays.push_back(dm3);
		}
	      }
	    }
	  }
	}
      }
    }
  }

  // Add in three-body decays that go through 4-particle vertices
  // Now look for 3-body decays
  for(i = Vertex::vl.begin(); i != Vertex::vl.end(); i++) {
    Vertex & v = *i;
    if(v.Multiplicity(p) >= 1) {
      if(v.Count() == 4 && v.Decays(p)) {
	// Add a new 3-body decay mode or append to
	// an existing one.
	vector<string> theDaughters(3);
	if(v.Leg(0) == p) {
	  theDaughters[0] = v.Leg(1);
	  theDaughters[1] = v.Leg(2);
	  theDaughters[2] = v.Leg(3);
	} else if(v.Leg(1) == p) {
	  theDaughters[0] = v.Leg(0);
	  theDaughters[1] = v.Leg(2);
	  theDaughters[2] = v.Leg(3);
	} else if(v.Leg(2) == p) {
	  theDaughters[0] = v.Leg(0);
	  theDaughters[1] = v.Leg(1);
	  theDaughters[2] = v.Leg(3);
	} else if(v.Leg(3) == p) {
	  theDaughters[0] = v.Leg(0);
	  theDaughters[1] = v.Leg(1);
	  theDaughters[2] = v.Leg(2);
	}
	if(v.Type() == "SSSS" || v.Type() == "VVSS") {
	  // swap signs of daughters
          theDaughters[0] = Particle::pl[theDaughters[0]].Antiparticle();
	  theDaughters[1] = Particle::pl[theDaughters[1]].Antiparticle();
	  theDaughters[2] = Particle::pl[theDaughters[2]].Antiparticle();
	  vector<ThreeBodyDecayMode *>::iterator d3;
	  bool decayExists = false;
	  for(d3 = threeDecays.begin(); d3 != threeDecays.end(); d3++) {
	    vector<string> d3Daughters = (*d3)->ListDaughters();
	    if(theDaughters[0] == d3Daughters[0]) {
	      if((theDaughters[1] == d3Daughters[1] && theDaughters[2] == d3Daughters[2]) ||
		 (theDaughters[1] == d3Daughters[2] && theDaughters[2] == d3Daughters[1])) {
		(*d3)->AddVertex4(v);
		decayExists = true;
		break;
	      }
	    } else if(theDaughters[0] == d3Daughters[1]) {
	      if((theDaughters[1] == d3Daughters[0] && theDaughters[2] == d3Daughters[2]) ||
		 (theDaughters[1] == d3Daughters[2] && theDaughters[2] == d3Daughters[0])) {
		(*d3)->AddVertex4(v);
		decayExists = true;
		break;
	      }
	    } else if(theDaughters[0] == d3Daughters[2]) {
	      if((theDaughters[1] == d3Daughters[1] && theDaughters[2] == d3Daughters[0]) ||
		 (theDaughters[1] == d3Daughters[0] && theDaughters[2] == d3Daughters[1])) {
		(*d3)->AddVertex4(v);
		decayExists = true;
		break;
	      }
	    }
	  }
	  if(!decayExists) {
	    // make a new 3-body decay
	    ThreeBodyDecayMode *dm3 = new ThreeBodyDecayMode(p, theDaughters[0], theDaughters[1],
							     theDaughters[2], v);
	    threeDecays.push_back(dm3);
	  }
	}
      }
    }
  }

  // Add the three-body decays to the overall list
  vector<ThreeBodyDecayMode *>::iterator d3;
  for(d3 = threeDecays.begin(); d3 != threeDecays.end(); d3++) {
    DecayMode* dm = (DecayMode*)(*d3);
    decayList.push_back(dm);
  }
  
  return decayList;
}
