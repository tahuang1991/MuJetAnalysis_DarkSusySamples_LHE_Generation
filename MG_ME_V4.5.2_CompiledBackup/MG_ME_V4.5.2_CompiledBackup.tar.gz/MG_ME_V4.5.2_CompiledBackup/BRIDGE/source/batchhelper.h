#ifndef BATCH_HELPER_H
#define BATCH_HELPER_H
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <vector>

int usagehelprb();

int usagehelprbsusy();

int usagehelprd();

int usagehelprdsusy();

int runbribatch(int argc, char *argv[],std::vector<std::string>&  pargs);

int runbribatchsusy(int argc, char *argv[],std::vector<std::string>&  pargs);

int rundgebatch(int argc, char *argv[],std::vector<std::string>&  pargs);

int rundgebatchsusy(int argc, char *argv[],std::vector<std::string>&  pargs);

#endif
