#ifndef DECAY_MODE_H
#define DECAY_MODE_H

#include<list>
#include<string>
#include<complex>
#include "Vertex.h"
#include "FourVector.h"

class DecayMode {
 public:
  virtual ~DecayMode() {}
  virtual bool SanityCheck();
  int NumberDaughters();
  double SumDaughtersMass();
  std::string Parent();
  std::vector<std::string> ListDaughters();

 protected:
  std::string parent;
  std::vector<std::string> products;
};

class TwoBodyDecayMode : public DecayMode {
 public:
  TwoBodyDecayMode();
  TwoBodyDecayMode(std::string mo, std::string d1, std::string d2, 
           Vertex vtx);
  virtual ~TwoBodyDecayMode() {}
  virtual bool SanityCheck(std::string type, int spinI, int spin1, int spin2);

  // Compute the amplitude
  virtual std::complex<double> Amplitude(FourVector P[3]) 
    { return 0.0; }

  // Get the vertex
  Vertex getVertex() { return vertex; }

  // Get the color factor
  double ColorFactor();

 protected:
  double PSq(double MSq, double m1Sq, double m2Sq);
  double PhaseSpace(double M, double m1, double m2);
  Vertex vertex;
};

// A pair of two-body decays,
// P -> 0 + 1, I -> 2 + 3, where "I" is one of 0,1.
// i0, i1, i2, I are the positions of the daughters 0,
// 1, 2 of the three-body decay and of the intermediate 
// particle "I" in the list {0,1,2,3}.
// Conversely, d2, d3 specify which of daughters 0,1,2
// occupy positions "2" and "3" in the decay chain.
struct TwoBodyDecayPair {
  std::pair<TwoBodyDecayMode*, TwoBodyDecayMode*> pr;
  int i0, i1, i2, I;
  int d2, d3;
};

// A three-body decay mode, which can be made up of various
// sequential two-body decays. We only compute the interference
// when they all share a color structure (at least for now).
// So a three body decay is a sum over various terms each
// of which has a well-defined color structure.
// Revision, January 2011: now also allow this to go directly
// through four-particle vertices
class ThreeBodyDecayMode : public DecayMode {
 public:
  // create from a pair of 3-particle vertices
  ThreeBodyDecayMode(TwoBodyDecayPair thePair);
  // create from one 4-particle vertex
  ThreeBodyDecayMode(std::string mo, std::string d1, std::string d2,
                     std::string d3, Vertex vtx);

  // Compute the amplitude
  // Actually, in this case return sum over color structures of
  // |A|^2 * color factor.
  virtual double AmpSquareColor(FourVector P[4]);

  // Check if the parent and the three daughters match
  // in the given decays; if so, fills (i0,i1,i2,I) in
  // thePair.
  bool DecayMatch(TwoBodyDecayPair & thePair);

  // Get the list of vertices
  std::vector< std::list< TwoBodyDecayPair > > VList() {
    return vertices;
  }

  // Get the four-particle vertices
  std::vector< Vertex > V4List() {
    return fourVertices;
  }

  // Add to the decay mode a new pair
  void AddVertexPair(TwoBodyDecayPair thePair);

  // Add a new four-particle vertex
  void AddVertex4(Vertex theVertex) {
    fourVertices.push_back(theVertex);
  }

  // Get the color factor of the n^th color structure in our
  // list.
  double ColorFactor(int n);

 protected:
  // Use a pair of TwoBodyDecayModes rather than just vertices:
  // that way we have the structure telling which leg is the
  // parent particle, even though strictly these aren't
  // "decays".
  // We need a list in case there are interfering amplitudes
  // with the same final state.
  // Also, we need a *vector* of lists, one list for each
  // color structure
  std::vector< std::list< TwoBodyDecayPair > > vertices;

  // These are the four-particle vertices
  std::vector< Vertex > fourVertices;

  // This is set to true if we don't have to worry about
  // multiple color structures
  bool uniqueColorStructure;
};

class S_FF : public TwoBodyDecayMode {
 public:
  S_FF();
  virtual ~S_FF() {}
  S_FF(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class S_SS : public TwoBodyDecayMode {
 public:
  S_SS();
  virtual ~S_SS() {}
  S_SS(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class S_VS : public TwoBodyDecayMode {
 public:
  S_VS();
  virtual ~S_VS() {}
  S_VS(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class S_VV : public TwoBodyDecayMode {
 public:
  S_VV();
  virtual ~S_VV() {}
  S_VV(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class V_FF : public TwoBodyDecayMode {
 public:
  V_FF();
  virtual ~V_FF() {}
  V_FF(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class V_SS : public TwoBodyDecayMode {
 public:
  V_SS();
  virtual ~V_SS() {}
  V_SS(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class V_VS : public TwoBodyDecayMode {
 public:
  V_VS();
  virtual ~V_VS() {}
  V_VS(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class V_VV : public TwoBodyDecayMode {
 public:
  V_VV();
  virtual ~V_VV() {}
  V_VV(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class F_FS : public TwoBodyDecayMode {
 public:
  F_FS();
  virtual ~F_FS() {}
  F_FS(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

class F_FV : public TwoBodyDecayMode {
 public:
  F_FV();
  virtual ~F_FV() {}
  F_FV(std::string mo, std::string d1, std::string d2, Vertex vtx)
    : TwoBodyDecayMode(mo,d1,d2,vtx) {}
  bool SanityCheck();
  std::complex<double> Amplitude(FourVector P[3]);
};

#endif
