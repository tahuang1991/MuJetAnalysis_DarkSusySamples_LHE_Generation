// Build up amplitudes for three-body decays.
// In a separate file to avoid cluttering up DecayMode.cpp.

#include "DecayMode.h"
#include "WaveFunctions.h"
#include "Amplitude.h"
#include "OffShell.h"
#include <math.h>
#include <cassert>
#include <iostream> // DEBUG
#include <fstream>
using namespace std;

ThreeBodyDecayMode::ThreeBodyDecayMode(TwoBodyDecayPair thePair)
  : vertices(1), uniqueColorStructure(false)
{
  string firstDaughter;
  TwoBodyDecayMode *d1 = thePair.pr.first;
  TwoBodyDecayMode *d2 = thePair.pr.second;
  parent = d1->Parent();
  if(d1->ListDaughters()[0] == d2->Parent()) {
    firstDaughter = d1->ListDaughters()[1];
    thePair.i0 = 1;
    thePair.I = 0;
  } else if(d1->ListDaughters()[1] == d2->Parent()) {
    firstDaughter = d1->ListDaughters()[0];
    thePair.i0 = 0;
    thePair.I = 1;
  } else {
    // throw an exception
  }
  thePair.i1 = 2;
  thePair.i2 = 3;
  products.push_back(firstDaughter);
  products.push_back(d2->ListDaughters()[0]);
  products.push_back(d2->ListDaughters()[1]);
  vertices[0].push_back(thePair);

  int color1 = Particle::pl[parent].NColors();
  int color2 = Particle::pl[products[0]].NColors();
  int color3 = Particle::pl[products[1]].NColors();
  int color4 = Particle::pl[products[2]].NColors();
  int n1s = 0;
  if(color1 == 1) n1s++;
  if(color2 == 1) n1s++;
  if(color3 == 1) n1s++;
  if(color4 == 1) n1s++;
  if(n1s >= 2) uniqueColorStructure = true;
  if(color1 == 8) {
    if((color2 == 3 && color3 == 8 && color4 == 8) 
       || (color2 == 8 && color3 == 3 && color4 == 8)
       || (color2 == 8 && color3 == 8 && color4 == 3)) {
      uniqueColorStructure = true;
    }
  }
}

ThreeBodyDecayMode::ThreeBodyDecayMode(std::string mo, std::string d1, 
                                       std::string d2, std::string d3, 
                                       Vertex vtx)
  : uniqueColorStructure(false)
{
  parent = mo;
  products.push_back(d1);
  products.push_back(d2);
  products.push_back(d3);
  fourVertices.push_back(vtx);

  int color1 = Particle::pl[parent].NColors();
  int color2 = Particle::pl[products[0]].NColors();
  int color3 = Particle::pl[products[1]].NColors();
  int color4 = Particle::pl[products[2]].NColors();
  int n1s = 0;
  if(color1 == 1) n1s++;
  if(color2 == 1) n1s++;
  if(color3 == 1) n1s++;
  if(color4 == 1) n1s++;
  if(n1s >= 2) uniqueColorStructure = true;
  if(color1 == 8) {
    if((color2 == 3 && color3 == 8 && color4 == 8) 
       || (color2 == 8 && color3 == 3 && color4 == 8)
       || (color2 == 8 && color3 == 8 && color4 == 3)) {
      uniqueColorStructure = true;
    }
  }
}

bool ThreeBodyDecayMode::DecayMatch(TwoBodyDecayPair & thePair) {
  TwoBodyDecayMode *d1 = thePair.pr.first;
  TwoBodyDecayMode *d2 = thePair.pr.second;
  int id2, id3;
  int i0,i1,i2,I;
  if(d1->Parent() != parent) return false;
  string firstDaughter;
  int fdind;
  if(d1->ListDaughters()[0] == d2->Parent()) {
    I = 0;
    fdind = 1;
    firstDaughter = d1->ListDaughters()[1];
  } else if(d1->ListDaughters()[1] == d2->Parent()) {
    I = 1;
    fdind = 0;
    firstDaughter = d1->ListDaughters()[0];
  } else {
    // throw an exception
  }
  int other1, other2;
  if(firstDaughter == products[0]) {
    other1 = 1; other2 = 2;
    i0 = fdind;
  } else if(firstDaughter == products[1]) {
    other1 = 0; other2 = 2;
    i1 = fdind;
  } else if(firstDaughter == products[2]) {
    other1 = 0; other2 = 1;
    i2 = fdind;
  } else return false;
  string secondDaughter = d2->ListDaughters()[0];
  string thirdDaughter = d2->ListDaughters()[1];
  if(secondDaughter == products[other1] &&
     thirdDaughter == products[other2]) {
    if(other1 == 0) {
      i0 = 2;
      id2 = 0;
    } else { // other1 == 1
      i1 = 2;
      id2 = 1;
    }
    if(other2 == 1) {
      i1 = 3;
      id3 = 1;
    } else { // other2 == 2
      i2 = 3;
      id3 = 2;
    }
    thePair.i0 = i0;
    thePair.i1 = i1;
    thePair.i2 = i2;
    thePair.I = I;
    return true;
  } 
  if(secondDaughter == products[other2] &&
     thirdDaughter == products[other1]) {
    if(other1 == 0) {
      i0 = 3;
      id3 = 0;
    } else { // other1 == 1
      i1 = 3;
      id3 = 1;
    }
    if(other2 == 1) {
      i1 = 2;
      id2 = 1;
    } else { // other2 == 2
      i2 = 2;
      id2 = 2;
    }
    thePair.i0 = i0;
    thePair.i1 = i1;
    thePair.i2 = i2;
    thePair.I = I;
    thePair.d2 = id2;
    thePair.d3 = id3;
    return true;
  }
  return false;
}

void ThreeBodyDecayMode::AddVertexPair(TwoBodyDecayPair thePair) {
  if(uniqueColorStructure) {
    vertices[0].push_back(thePair);
    return;
  } else {
    bool colorStructureFound = false;
    // get the color of the intermediate particle:
    int interC = Particle::pl[thePair.pr.second->Parent()].NColors();
    for(int n = 0; n < vertices.size(); n++) {
      // decide if we're the same color structure as the pairs
      // in this list...?
      list< TwoBodyDecayPair >::iterator i = vertices[n].begin();
      TwoBodyDecayMode * dec2 = i->pr.second;
      // first, the color of the intermediate particle should match:
      int interCn = Particle::pl[dec2->Parent()].NColors();
      if(interCn == interC) {
	if((i->d2 == thePair.d2 && i->d3 == thePair.d3) ||
	   (i->d3 == thePair.d2 && i->d2 == thePair.d3)) {
	  vertices[n].push_back(thePair);
	  colorStructureFound = true;
	  break;
	}
      }
    }
    if(!colorStructureFound) {
      // add a new color structure
      list< TwoBodyDecayPair > newColorStructure;
      newColorStructure.push_back(thePair);
      vertices.push_back(newColorStructure);
    }
  }
}

// The input is P[4], where P[0] = parent momentum,
// P[1] = momentum of daughter 0,
// P[2] = momentum of daughter 1, 
// P[3] = momentum of daughter 2.
double ThreeBodyDecayMode::AmpSquareColor(FourVector P[4])
{
  // Store the original four-vector; we will be re-ordering it
  // for each of the decay modes, in the form
  // 0 -> 1 + I, I -> 2 + 3.
  FourVector POrig[4];
  POrig[0] = P[0];
  POrig[1] = P[1];
  POrig[2] = P[2];
  POrig[3] = P[3];
  double finalValue = 0.0;
  static int blah=0;
  static double out1 = 0.0, out2 = 0.0;
  blah++;
  bool haveFourVertices = (fourVertices.size() > 0);
  bool includedFourVertices = false;
  //ofstream debug("debug.txt",ios::app);
  list< TwoBodyDecayPair >::iterator i;
  for(int j = 0; j < vertices.size(); j++) {
    complex<double> theAmp = 0.0; // this color structure
    // check color of intermediate particle, add 4-vertex if necessary
    if(haveFourVertices && !includedFourVertices) {
      TwoBodyDecayMode* d2temp = vertices[j].begin()->pr.second;
      if(Particle::pl[d2temp->Parent()].NColors() == 1) {
	if(fourVertices[0].Type() == "SSSS") {
	  // don't need to care about order due to symmetry;
	  // P[0] is always parent
          ScalarWaveFunction s1 = GetScalarWave(POrig[0], S_IN);
	  ScalarWaveFunction s2 = GetScalarWave(POrig[1], S_OUT);
	  ScalarWaveFunction s3 = GetScalarWave(POrig[2], S_OUT);
	  ScalarWaveFunction s4 = GetScalarWave(POrig[3], S_OUT);
          for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
            theAmp += SSSSAmp(s1,s2,s3,s4,fourVertices[v4i].Couplings(),
			      fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	} else if(fourVertices[0].Type() == "VVSS") {
	  // Need to figure out which particles are scalars vs vectors...
	  // Are we decaying a vector, or a scalar?
	  // scalar...
	  if(Particle::pl[Parent()].TwiceSpin() == 0) {
            ScalarWaveFunction s1 = GetScalarWave(POrig[0], S_IN);
	    // use POrig since they are in a definite order
	    if(Particle::pl[ListDaughters()[0]].TwiceSpin() == 0) {
	      ScalarWaveFunction s2 = GetScalarWave(POrig[1], S_OUT);
	      VectorWaveFunction v1 = GetVectorWave(POrig[2], V_OUT);
	      VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    } else if(Particle::pl[ListDaughters()[1]].TwiceSpin() == 0) {
	      ScalarWaveFunction s2 = GetScalarWave(POrig[2], S_OUT);
	      VectorWaveFunction v1 = GetVectorWave(POrig[1], V_OUT);
	      VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    } else if(Particle::pl[ListDaughters()[2]].TwiceSpin() == 0) {
	      ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	      VectorWaveFunction v1 = GetVectorWave(POrig[1], V_OUT);
	      VectorWaveFunction v2 = GetVectorWave(POrig[2], V_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    }
	  } else if(Particle::pl[Parent()].TwiceSpin() == 2) {
	    VectorWaveFunction v1 = GetVectorWave(POrig[0], V_IN);
	    // use POrig since they are in a definite order
	    if(Particle::pl[ListDaughters()[0]].TwiceSpin() == 2) {
	      VectorWaveFunction v2 = GetVectorWave(POrig[1], V_OUT);
	      ScalarWaveFunction s1 = GetScalarWave(POrig[2], S_OUT);
	      ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    } else if(Particle::pl[ListDaughters()[1]].TwiceSpin() == 2) {
	      VectorWaveFunction v2 = GetVectorWave(POrig[2], V_OUT);
	      ScalarWaveFunction s1 = GetScalarWave(POrig[1], S_OUT);
	      ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    } else if(Particle::pl[ListDaughters()[2]].TwiceSpin() == 2) {
	      VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	      ScalarWaveFunction s1 = GetScalarWave(POrig[1], S_OUT);
	      ScalarWaveFunction s2 = GetScalarWave(POrig[2], S_OUT);
	      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	      }
	      includedFourVertices = true;
	    }
	  }
	}
      }
    }
    int ic = -1;
    for(i = vertices[j].begin(); i != vertices[j].end(); i++) {
      ic++;
      TwoBodyDecayMode* dec1 = i->pr.first;
      TwoBodyDecayMode* dec2 = i->pr.second;
      // Permute P[0], P[1], P[2], P[3] so this code works....
      // The order is P -> 0 + 1, I -> 2 + 3 where I is in {0,1}.
      // We want P[1] = momentum of the daughter n such that in = 0
      // or 1; P[2] = momentum of the daughter n such that in = 2,
      // P[3] = momentum of the daughter n such that in = 3.
      if(i->i0 == 0 || i->i0 == 1) { 
	// daughter 0 is in the first position
	P[1] = POrig[1];
//	cout << "j = " << j << ", P1 = PO1\n";
      } else if(i->i1 == 0 || i->i1 == 1) { 
	// daughter 1 is in the first position
	P[1] = POrig[2];
//	cout << "j = " << j << ", P1 = PO2\n";
      } else if(i->i2 == 0 || i->i2 == 1) { 
	// daughter2 is in the first position
	P[1] = POrig[3];
//	cout << "j = " << j << ", P1 = PO3\n";
      } else {
	// throw an exception
      }
      if(i->i0 == 2) {
	// daughter 0 is in the second position
	P[2] = POrig[1];
      } else if(i->i1 == 2) {
	// daughter 1 is in the second position
	P[2] = POrig[2];
      } else if(i->i2 == 2) {
	// daughter 2 is in the second position
	P[2] = POrig[3];
      } else {
	// throw an exception
      }
      if(i->i0 == 3) { 
	// daughter 0 is in the third position
	P[3] = POrig[1];
      } else if(i->i1 == 3) {
	// daughter 1 is in the third position
	P[3] = POrig[2];
      } else if(i->i2 == 3) {
	// daughter 2 is in the third position
	P[3] = POrig[3];
      }
      //////////////////////////////////////////////////////////////////
      // SCALAR DECAYS
      //////////////////////////////////////////////////////////////////
      if(Particle::pl[Parent()].TwiceSpin() == 0) {
	// Three body scalar decays
	ScalarWaveFunction s1 = GetScalarWave(P[0], S_IN);
	if(Particle::pl[dec2->Parent()].TwiceSpin() == 0) {
	  // Construct off-shell scalar current
	  double sM = Particle::pl[dec2->Parent()].Mass();
	  double sW = Particle::pl[dec2->Parent()].Width();
	  ScalarWaveFunction oss;
	  int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	  if((d2Spin_11 == 0 && d2Spin_12 == 2) ||
	     (d2Spin_11 == 2 && d2Spin_12 == 0)) {
	    VectorWaveFunction v1 = GetVectorWave(P[1], V_OUT);
	    oss = OffShellScalarFromVS(v1,s1,
				       dec1->getVertex().Couplings(),
				       sM,sW);
	  } else if(d2Spin_11 == 0 && d2Spin_12 == 0) {
	    ScalarWaveFunction s2 = GetScalarWave(P[1], S_OUT);
	    oss = OffShellScalarFromSS(s1,s2,
				       dec1->getVertex().Couplings(),
				       sM,sW);
	  } else {
	    // throw some sort of exception
	  }
	  int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	  if(d2Spin_1 == 0) {
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	      ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	      theAmp += SSSAmp(oss,sw1,sw2,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag()); 
	    } else if(d2Spin_2 == 2) {
	      ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	      theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 1) {
	      // throw some sort of error...
	    }
	  } else if(d2Spin_1 == 2) { 
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	      theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 2) {
	      VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	      VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	      theAmp += VVSAmp(vw1,vw2,oss,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    }
	  } else if(d2Spin_1 == 1) {
	    // fermions
	    assert(d2Spin_2 == 1);
	    int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	    int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	    if(f1Num == 2 && f2Num != 2) {
              // particle one is Majorana, particle 2 is not, so route line according to #2
	      f1Num = -f2Num; 
	    }
	    if (f1Num > 0) {
	      FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	      FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	      theAmp += FFSAmp(fwfAnti, fwfPart, oss, 
			       dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(f1Num < 0) {
	      FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	      FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	      theAmp += FFSAmp(fwfAnti, fwfPart, oss, 
			       dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw some sort of error...
	    }
	  }
	} else if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
	  // Construct off-shell fermion current
	  double fM = Particle::pl[dec2->Parent()].Mass();
	  double fW = Particle::pl[dec2->Parent()].Width();
          // figure out whether the fermionic daughter is to be considered fermion or antifermion
          int fnum = Particle::pl[dec2->Parent()].FermionNumber();
	  int fno = fnum;
          // only tricky case is Majorana; check the other fermionic daughter of the first decay
          if(fnum == 2) {
	    int fn1 = Particle::pl[dec1->ListDaughters()[0]].FermionNumber();
	    int fn2 = Particle::pl[dec1->ListDaughters()[1]].FermionNumber();
            if(fn1 == 2 && fn2 != 2) {
	      fnum = -fn2;
            } else if(fn1 != 2 && fn2 == 2) { 
	      fnum = -fn1;
	    } else if(fn1 == 2 && fn2 == 2) {
	      fnum = 1;
	    }
          }   
	  if(fnum == 1) {
	    // the first decay product is an anti-fermion
	    FermionWaveFunction f1 = GetFermionWave(P[1], F_INANTI);
	    FermionWaveFunction fOff = OffShellFermionFromFInS(f1,s1,
							       dec1->getVertex().Couplings(),
							       fM,fW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      //int fn2 = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      FermionWaveFunction fOut = GetFermionWave(P[2], F_OUTPART);
	      ScalarWaveFunction sOut = GetScalarWave(P[3], S_OUT);
	      theAmp += FFSAmp(fOff,fOut,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      FermionWaveFunction fOut = GetFermionWave(P[2], F_OUTPART);
	      VectorWaveFunction vOut = GetVectorWave(P[3], V_OUT);
	      theAmp += FFVAmp(fOff,fOut,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      FermionWaveFunction fOut = GetFermionWave(P[3], F_OUTPART);
	      ScalarWaveFunction sOut = GetScalarWave(P[2], S_OUT);
	      theAmp += FFSAmp(fOff,fOut,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      FermionWaveFunction fOut = GetFermionWave(P[3], F_OUTPART);
	      VectorWaveFunction vOut = GetVectorWave(P[2], V_OUT);
	      theAmp += FFVAmp(fOff,fOut,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw an exception
	    }
	  } else if(fnum == -1) {
	    // the first decay product is a fermion
	    FermionWaveFunction f1 = GetFermionWave(P[1], F_OUTPART);
	    FermionWaveFunction fOff = OffShellFermionFromFOutS(f1,s1,
								dec1->getVertex().Couplings(),
								fM,fW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      FermionWaveFunction fIn = GetFermionWave(P[2], F_INANTI);
	      ScalarWaveFunction sOut = GetScalarWave(P[3], S_OUT);
	      theAmp += FFSAmp(fIn,fOff,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      FermionWaveFunction fIn = GetFermionWave(P[2], F_INANTI);
	      VectorWaveFunction vOut = GetVectorWave(P[3], V_OUT);
	      theAmp += FFVAmp(fIn,fOff,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      FermionWaveFunction fIn = GetFermionWave(P[3], F_INANTI);
	      ScalarWaveFunction sOut = GetScalarWave(P[2], S_OUT);
	      theAmp += FFSAmp(fIn,fOff,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      FermionWaveFunction fIn = GetFermionWave(P[3], F_INANTI);
	      VectorWaveFunction vOut = GetVectorWave(P[2], V_OUT);
	      theAmp += FFVAmp(fIn,fOff,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw an exception
	    }
	  }
	} else if(Particle::pl[dec2->Parent()].TwiceSpin() == 2) {
	  // Construct off-shell vector current
	  double vM = Particle::pl[dec2->Parent()].Mass();
	  double vW = Particle::pl[dec2->Parent()].Width();
	  VectorWaveFunction osv;
	  int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	  if((d2Spin_11 == 0 && d2Spin_12 == 2) ||
	     (d2Spin_11 == 2 && d2Spin_12 == 0)) {
	    ScalarWaveFunction s2 = GetScalarWave(P[1], S_OUT);
	    // careful about sign for interference effects
	    if(Particle::pl[Parent()].IDCode() > 0) {
  	      osv = OffShellVectorFromSS(s2,s1,
		  		         dec1->getVertex().Couplings(),
				         vM,vW);
	    } else {
  	      osv = OffShellVectorFromSS(s1,s2,
		  		         dec1->getVertex().Couplings(),
				         vM,vW);
	    }
	  } else if(d2Spin_11 == 2 && d2Spin_12 == 2) {
	    VectorWaveFunction v = GetVectorWave(P[1], V_OUT);
	    osv = OffShellVectorFromVS(v,s1,
				       dec1->getVertex().Couplings(),
				       vM,vW);
	  } else {
	    // throw some sort of exception
	  }
	  int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	  if(d2Spin_1 == 0) {
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	      ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	      theAmp += VSSAmp(osv,sw1,sw2,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag()); 
	    } else if(d2Spin_2 == 2) {
	      ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	      theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 1) {
	      // throw some sort of error...
	    }
	  } else if(d2Spin_1 == 2) { 
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	      theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 2) {
	      VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	      VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	      theAmp += VVVAmp(vw1,vw2,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    }
	  } else if(d2Spin_1 == 1) {
	    // fermions
	    assert(d2Spin_2 == 1);
	    int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	    int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	    if(f1Num == 2 && f2Num != 2) {
              // particle one is Majorana, particle 2 is not, so route line according to #2
	      f1Num = -f2Num; 
	    }
	    if (f1Num > 0) {
	      FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	      FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	      theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(f1Num < 0) {
	      FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	      FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	      theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw some sort of error...
	    }
	  }
	}
	//////////////////////////////////////////////////////////////////
	// FERMION DECAYS: FIGURE OUT DIRECTION OF LINE 
	//////////////////////////////////////////////////////////////////
      } else if(Particle::pl[Parent()].TwiceSpin() == 1) {
	int fnum = Particle::pl[Parent()].FermionNumber();
        if(fnum == 2) {
          // Majorana
	  int fn1 = Particle::pl[dec1->ListDaughters()[0]].FermionNumber();
	  if(fn1 == 1 || fn1 == -1) {
	    fnum = fn1;
	  }
	  else if(fn1 == 2) {
	    if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
	      int fn2 = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      if(fn2 == 1 || fn2 == -1) {
		fnum = fn2;
	      } else if(fn2 == 2) {
		// give up...
		fnum = 1;
	      } else {
		int fn3 = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
                if(fn3 == 1 || fn3 == -1) {
		  fnum = fn3;
	        } else if(fn3 == 2) {
		  // give up...
		  fnum = 1;
	        } else {
		  // throw an error
		}
	      }
	    } else {
	      // give up...
	      fnum = 1;
            }
	  } else {
            int fn2 = Particle::pl[dec1->ListDaughters()[1]].FermionNumber();
	    if(fn2 == 1 || fn2 == -1) {
	      fnum = fn2;
	    }
	    else if(fn2 == 2) {
	      if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
		int fn4 = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	        if(fn4 == 1 || fn4 == -1) {
		  fnum = fn4;
	        } else if(fn4 == 2) {
		  // give up...
		  fnum = 1;
	        } else {
		  int fn3 = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
                  if(fn3 == 1 || fn3 == -1) {
		    fnum = fn3;
	          } else if(fn3 == 2) {
		    // give up...
		    fnum = 1;
	          } else {
		    // throw an error
		  }
	        }
	      } else {
	        // give up...
	        fnum = 1;
              }       
	    } else {
	      // throw an error
	    }
	  }
	}
	assert(fnum == 1 || fnum == -1);
	//////////////////////////////////////////////////////////////////
	// FERMION DECAYS (INCOMING LINE)
	//////////////////////////////////////////////////////////////////
	if(fnum == 1) {
#ifdef DEBUG
	  cout << "Decaying a fermion.\n";
#endif
	  // Three body fermion decays, incoming fermion
	  FermionWaveFunction fIn = GetFermionWave(P[0], F_INPART);
	  if(Particle::pl[dec2->Parent()].TwiceSpin() == 0) {
	    // Construct off-shell scalar current
  	    double sM = Particle::pl[dec2->Parent()].Mass();
	    double sW = Particle::pl[dec2->Parent()].Width();
	    //cout << "sM, sW = " << sM << ", " << sW << "\n";
	    FermionWaveFunction fOut = GetFermionWave(P[1], F_OUTPART);
	    ScalarWaveFunction oss = OffShellScalarFromFF(fIn, fOut,
		  					  dec1->getVertex().Couplings(),
							  sM,sW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0) {
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	        ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	        theAmp += SSSAmp(oss,sw1,sw2,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag()); 
	      } else if(d2Spin_2 == 2) {
	        ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	        theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 1) {
	        // throw some sort of error...
	      }
	    } else if(d2Spin_1 == 2) { 
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	        theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 2) {
	        VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	        VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	        theAmp += VVSAmp(vw1,vw2,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      }
	    } else if(d2Spin_1 == 1) {
	      // fermions
	      assert(d2Spin_2 == 1);
	      int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	      if (f1Num == 1 || (f1Num == 2 && f2Num != 1)) {
	        FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	        FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	        theAmp += FFSAmp(fwfAnti,fwfPart,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(f1Num == -1 || (f1Num == 2 && f2Num == 1)) {
	        FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	        FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	        theAmp += FFSAmp(fwfAnti,fwfPart,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());

	        FermionWaveFunction fwfPart1 = GetFermionWave(P[2], F_OUTPART);
	        FermionWaveFunction fwfAnti1 = GetFermionWave(P[3], F_INANTI);
	      } else {
	      // throw some sort of error...
	      }
	    }
	  } else if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
	    // Construct off-shell fermion current
	    double fM = Particle::pl[dec2->Parent()].Mass();
	    double fW = Particle::pl[dec2->Parent()].Width();
	    int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	    FermionWaveFunction osf;
	    if(d2Spin_11 == 0 || d2Spin_12 == 0) {
	      // Scalar outgoing particle
	      assert(d2Spin_11 + d2Spin_12 == 1);
	      ScalarWaveFunction sw1 = GetScalarWave(P[1], S_OUT);
	      osf = OffShellFermionFromFInS(fIn, sw1,
					    dec1->getVertex().Couplings(),
					    fM,fW);
	    } else if(d2Spin_11 == 2 || d2Spin_12 == 2) {
	      // Vector outgoing particle
	      assert(d2Spin_11 + d2Spin_12 == 3);
	      VectorWaveFunction vw1 = GetVectorWave(P[1], V_OUT);
	      osf = OffShellFermionFromFInV(fIn, vw1,
					    dec1->getVertex().Couplings(),
					    fM,fW);
	    }
	    // Build amplitude with off-shell fermion and other outgoing particles
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      ScalarWaveFunction sw2 = GetScalarWave(P[2], S_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[3], F_OUTPART);
	      theAmp += FFSAmp(osf, fw, sw2, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      ScalarWaveFunction sw2 = GetScalarWave(P[3], S_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[2], F_OUTPART);
	      theAmp += FFSAmp(osf, fw, sw2, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      VectorWaveFunction vw = GetVectorWave(P[2], V_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[3], F_OUTPART);
	      theAmp += FFVAmp(osf, fw, vw, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      VectorWaveFunction vw = GetVectorWave(P[3], V_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[2], F_OUTPART);
	      theAmp += FFVAmp(osf, fw, vw, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw some sort of error...
	    }
	  } else if(Particle::pl[dec2->Parent()].TwiceSpin() == 2) {
	    // Construct off-shell vector current
	    double vM = Particle::pl[dec2->Parent()].Mass();
	    double vW = Particle::pl[dec2->Parent()].Width();
	    FermionWaveFunction fOut = GetFermionWave(P[1], F_OUTPART);
	    VectorWaveFunction osv = OffShellVectorFromFF(fIn,fOut,
							  dec1->getVertex().Couplings(),
							  vM,vW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0) {
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	        ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	        theAmp += VSSAmp(osv,sw1,sw2,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag()); 
	      } else if(d2Spin_2 == 2) {
	        ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	        theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 1) {
	        // throw some sort of error...
	      }
	    } else if(d2Spin_1 == 2) { 
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	        theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 2) {
	        VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	        VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	        theAmp += VVVAmp(vw1,vw2,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      }
	  } else if(d2Spin_1 == 1) {
	      // fermions
	      assert(d2Spin_2 == 1);
	      int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	      if (f1Num == 1 || (f1Num == 2 && f2Num != 1)) {
	        FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	        FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	        theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(f1Num == -1 || (f1Num == 2 && f2Num == 1)) {
	        FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	        FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	        theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else {
	        // throw some sort of error...
	      }
	    }
	  }
	  //////////////////////////////////////////////////////////////////
	  // FERMION DECAYS (OUTGOING LINE, I.E. INCOMING ANTIFERMION)
	  //////////////////////////////////////////////////////////////////
        }  else if(fnum == -1) {
	  // Three body fermion decays, incoming antifermion
	  FermionWaveFunction fOut = GetFermionWave(P[0], F_OUTANTI);
	  if(Particle::pl[dec2->Parent()].TwiceSpin() == 0) {
	    // Construct off-shell scalar current
	    double sM = Particle::pl[dec2->Parent()].Mass();
	    double sW = Particle::pl[dec2->Parent()].Width();
	    FermionWaveFunction fIn = GetFermionWave(P[1], F_INANTI);
	    ScalarWaveFunction oss = OffShellScalarFromFF(fIn, fOut,
							  dec1->getVertex().Couplings(),
							  sM,sW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0) {
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	        ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	        theAmp += SSSAmp(oss,sw1,sw2,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag()); 
	      } else if(d2Spin_2 == 2) {
	        ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	        theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 1) {
	        // throw some sort of error...
	      }
	    } else if(d2Spin_1 == 2) { 
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	        theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 2) {
	        VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	        VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	        theAmp += VVSAmp(vw1,vw2,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      }
	    } else if(d2Spin_1 == 1) {
	      // fermions
	      assert(d2Spin_2 == 1);
	      int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	      if (f1Num == 1 || (f1Num == 2 && f2Num != 1)) {
	        FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	        FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	        theAmp += FFSAmp(fwfAnti,fwfPart,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(f1Num == -1 || (f1Num == 2 && f2Num == 1)) {
	        FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	        FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	        theAmp += FFSAmp(fwfAnti,fwfPart,oss,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else {
	        // throw some sort of error...
	      }
	    }
	  } else if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
	    // Construct off-shell fermion current
	    double fM = Particle::pl[dec2->Parent()].Mass();
	    double fW = Particle::pl[dec2->Parent()].Width();
	    int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	    FermionWaveFunction osf;
	    if(d2Spin_11 == 0 || d2Spin_12 == 0) {
	      // Scalar outgoing particle
	      assert(d2Spin_11 + d2Spin_12 == 1);
	      ScalarWaveFunction sw1 = GetScalarWave(P[1], S_OUT);
	      osf = OffShellFermionFromFOutS(fOut, sw1,
					     dec1->getVertex().Couplings(),
					     fM,fW);
	    } else if(d2Spin_11 == 2 || d2Spin_12 == 2) {
	      // Vector outgoing particle
	      assert(d2Spin_11 + d2Spin_12 == 3);
	      VectorWaveFunction vw1 = GetVectorWave(P[1], V_OUT);
	      osf = OffShellFermionFromFOutV(fOut, vw1,
					     dec1->getVertex().Couplings(),
					     fM,fW);
	    }
	    // Build amplitude with off-shell fermion and other outgoing particles
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      ScalarWaveFunction sw2 = GetScalarWave(P[2], S_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[3], F_INANTI);
	      theAmp += FFSAmp(fw, osf, sw2, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      ScalarWaveFunction sw2 = GetScalarWave(P[3], S_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[2], F_INANTI);
	      theAmp += FFSAmp(fw, osf, sw2, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      VectorWaveFunction vw = GetVectorWave(P[2], V_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[3], F_INANTI);
	      theAmp += FFVAmp(fw, osf, vw, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      VectorWaveFunction vw = GetVectorWave(P[3], V_OUT);
	      FermionWaveFunction fw = GetFermionWave(P[2], F_INANTI);
	      theAmp += FFVAmp(fw, osf, vw, dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw some sort of error...
	    }
	  } else if(Particle::pl[dec2->Parent()].TwiceSpin() == 2) {
	    // Construct off-shell vector current
	    double vM = Particle::pl[dec2->Parent()].Mass();
	    double vW = Particle::pl[dec2->Parent()].Width();
	    FermionWaveFunction fIn = GetFermionWave(P[1], F_INANTI);
	    VectorWaveFunction osv = OffShellVectorFromFF(fIn,fOut,
							  dec1->getVertex().Couplings(),
							  vM,vW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 0) {
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	        ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	        theAmp += VSSAmp(osv,sw1,sw2,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag()); 
	      } else if(d2Spin_2 == 2) {
	        ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	        theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 1) {
	        // throw some sort of error...
	      }
	    } else if(d2Spin_1 == 2) { 
	      if(d2Spin_2 == 0) {
	        ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	        VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	        theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(d2Spin_2 == 2) {
	        VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	        VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	        theAmp += VVVAmp(vw1,vw2,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      }
	    } else if(d2Spin_1 == 1) {
	      // fermions
	      assert(d2Spin_2 == 1);
	      int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	      int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	      if (f1Num == 1 || (f1Num == 2 && f2Num != 1)) {
	        FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	        FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	        theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else if(f1Num == -1 || (f1Num == 2 && f2Num == 1)) {
	        FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	        FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	        theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			         dec2->getVertex().UserFlag());
	      } else {
	        // throw some sort of error...
	      }
	    }
	  }      
        }
	//////////////////////////////////////////////////////////////////
	// VECTOR DECAYS
	//////////////////////////////////////////////////////////////////
      } else if(Particle::pl[Parent()].TwiceSpin() == 2) {
	// Three body vector decays
	VectorWaveFunction vIn = GetVectorWave(P[0], V_IN);
	if(Particle::pl[dec2->Parent()].TwiceSpin() == 0) {
	  // Construct off-shell scalar current
	  double sM = Particle::pl[dec2->Parent()].Mass();
	  double sW = Particle::pl[dec2->Parent()].Width();
	  int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	  ScalarWaveFunction oss;
	  if(d2Spin_11 == 0 && d2Spin_12 == 0) {
	    ScalarWaveFunction sw1 = GetScalarWave(P[1], S_OUT);
	    oss = OffShellScalarFromVS(vIn, sw1,
				       dec1->getVertex().Couplings(),
				       sM,sW);
	  } else if((d2Spin_11 == 0 && d2Spin_12 == 2)
		    || (d2Spin_11 == 2 && d2Spin_12 == 0)) {
	    VectorWaveFunction vw1 = GetVectorWave(P[1], V_OUT);
	    oss = OffShellScalarFromVV(vIn, vw1,
				       dec1->getVertex().Couplings(),
				       sM,sW);
	  }
	  // Contract off-shell scalar with other final-state particles
	  int d2Spin_21 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_22 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	  if(d2Spin_21 == 0 && d2Spin_22 == 0) {
	    ScalarWaveFunction sw1 = GetScalarWave(P[2], S_OUT);
	    ScalarWaveFunction sw2 = GetScalarWave(P[3], S_OUT);
	    theAmp += SSSAmp(oss,sw1,sw2,dec2->getVertex().Couplings(),
			     dec2->getVertex().UserFlag());
	  } else if(d2Spin_21 == 0 && d2Spin_22 == 2) {
	    ScalarWaveFunction sw = GetScalarWave(P[2], S_OUT);
	    VectorWaveFunction vw = GetVectorWave(P[3], V_OUT);
	    theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			     dec2->getVertex().UserFlag());
	  } else if(d2Spin_21 == 2 && d2Spin_22 == 0) {
	    ScalarWaveFunction sw = GetScalarWave(P[3], S_OUT);
	    VectorWaveFunction vw = GetVectorWave(P[2], V_OUT);
	    theAmp += VSSAmp(vw,sw,oss,dec2->getVertex().Couplings(),
			     dec2->getVertex().UserFlag());
	  } else if(d2Spin_21 == 2 && d2Spin_22 == 2) {
	    VectorWaveFunction vw1 = GetVectorWave(P[2], V_OUT);
	    VectorWaveFunction vw2 = GetVectorWave(P[3], V_OUT);
	    theAmp += VVSAmp(vw1,vw2,oss,dec2->getVertex().Couplings(),
			     dec2->getVertex().UserFlag());
	  } else if(d2Spin_21 == 1 && d2Spin_22 == 1) {
	    FermionWaveFunction fIn, fOut;
	    int fn1 = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	    int fn2 = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	    if(fn1 == 1 || (fn1 == 2 && fn2 != 1)) {
	      fIn = GetFermionWave(P[3], F_INANTI);
	      fOut = GetFermionWave(P[2], F_OUTPART);
	    } else if(fn1 == -1 || (fn1 == 2 && fn2 == 1)) {
	      fIn = GetFermionWave(P[2], F_INANTI);
	      fOut = GetFermionWave(P[3], F_OUTPART);
	    } else {
	      // throw some sort of error...
	    }
	    theAmp += FFSAmp(fIn,fOut,oss,dec2->getVertex().Couplings(),
			   dec2->getVertex().UserFlag());
	  } else {
	    // throw some sort of error...
	  }
	} else if(Particle::pl[dec2->Parent()].TwiceSpin() == 1) {
	  // Construct off-shell fermion current
	  double fM = Particle::pl[dec2->Parent()].Mass();
	  double fW = Particle::pl[dec2->Parent()].Width();
          // figure out whether the fermionic daughter is to be considered fermion or antifermion
          int fnum = Particle::pl[dec2->Parent()].FermionNumber();
          // only tricky case is Majorana; check the other fermionic daughter of the first decay
          if(fnum == 2) {
	    int fn1 = Particle::pl[dec1->ListDaughters()[0]].FermionNumber();
	    int fn2 = Particle::pl[dec1->ListDaughters()[1]].FermionNumber();
            if(fn1 == 2 && fn2 != 2) {
	      fnum = -fn2;
            } else if(fn1 != 2 && fn2 == 2) { 
	      fnum = -fn1;
	    } else if(fn1 == 2 && fn2 == 2) {
	      fnum = 1;
	    }
          }   
	  if(fnum == 1) {
	    // the first decay product is an anti-fermion
	    FermionWaveFunction f1 = GetFermionWave(P[1], F_INANTI);
	    FermionWaveFunction fOff = OffShellFermionFromFInV(f1,vIn,
							       dec1->getVertex().Couplings(),
							       fM,fW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      FermionWaveFunction fOut = GetFermionWave(P[2], F_OUTPART);
	      ScalarWaveFunction sOut = GetScalarWave(P[3], S_OUT);
	      theAmp += FFSAmp(fOff,fOut,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      FermionWaveFunction fOut = GetFermionWave(P[2], F_OUTPART);
	      VectorWaveFunction vOut = GetVectorWave(P[3], V_OUT);
	      theAmp += FFVAmp(fOff,fOut,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      FermionWaveFunction fOut = GetFermionWave(P[3], F_OUTPART);
	      ScalarWaveFunction sOut = GetScalarWave(P[2], S_OUT);
	      theAmp += FFSAmp(fOff,fOut,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      FermionWaveFunction fOut = GetFermionWave(P[3], F_OUTPART);
	      VectorWaveFunction vOut = GetVectorWave(P[2], V_OUT);
	      theAmp += FFVAmp(fOff,fOut,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw an exception
	    }
	  } else if(fnum == -1) {
	    // the first decay product is a fermion
	    FermionWaveFunction f1 = GetFermionWave(P[1], F_OUTPART);
	    FermionWaveFunction fOff = OffShellFermionFromFOutV(f1,vIn,
								dec1->getVertex().Couplings(),
							      fM,fW);
	    int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	    int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	    if(d2Spin_1 == 1 && d2Spin_2 == 0) {
	      FermionWaveFunction fIn = GetFermionWave(P[2], F_INANTI);
	      ScalarWaveFunction sOut = GetScalarWave(P[3], S_OUT);
	      theAmp += FFSAmp(fIn,fOff,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 1 && d2Spin_2 == 2) {
	      FermionWaveFunction fIn = GetFermionWave(P[2], F_INANTI);
	      VectorWaveFunction vOut = GetVectorWave(P[3], V_OUT);
	      theAmp += FFVAmp(fIn,fOff,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 0 && d2Spin_2 == 1) {
	      FermionWaveFunction fIn = GetFermionWave(P[3], F_INANTI);
	      ScalarWaveFunction sOut = GetScalarWave(P[2], S_OUT);
	      theAmp += FFSAmp(fIn,fOff,sOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_1 == 2 && d2Spin_2 == 1) {
	      FermionWaveFunction fIn = GetFermionWave(P[3], F_INANTI);
	      VectorWaveFunction vOut = GetVectorWave(P[2], V_OUT);
	      theAmp += FFVAmp(fIn,fOff,vOut,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw an exception
	    }
	  }
	} else if(Particle::pl[dec2->Parent()].TwiceSpin() == 2) {
	  // Construct off-shell vector current
	  double vM = Particle::pl[dec2->Parent()].Mass();
	  double vW = Particle::pl[dec2->Parent()].Width();
	  VectorWaveFunction osv;
	  int d2Spin_11 = Particle::pl[dec1->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_12 = Particle::pl[dec1->ListDaughters()[1]].TwiceSpin();
	  if((d2Spin_11 == 0 && d2Spin_12 == 2) ||
	     (d2Spin_11 == 2 && d2Spin_12 == 0)) {
	    ScalarWaveFunction sOut = GetScalarWave(P[1], S_OUT);
	    osv = OffShellVectorFromVS(vIn,sOut,
				       dec1->getVertex().Couplings(),
				       vM,vW);
	  } else if(d2Spin_11 == 2 && d2Spin_12 == 2) {
	    VectorWaveFunction v = GetVectorWave(P[1], V_OUT);
	    osv = OffShellVectorFromVV(vIn,v,
				       dec1->getVertex().Couplings(),
				       vM,vW);
	  } else {
	    // throw some sort of exception
	  }
	  int d2Spin_1 = Particle::pl[dec2->ListDaughters()[0]].TwiceSpin();
	  int d2Spin_2 = Particle::pl[dec2->ListDaughters()[1]].TwiceSpin();
	  if(d2Spin_1 == 0) {
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw1 = GetScalarWave(P[2],S_OUT);
	      ScalarWaveFunction sw2 = GetScalarWave(P[3],S_OUT);
	      theAmp += VSSAmp(osv,sw1,sw2,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag()); 
	    } else if(d2Spin_2 == 2) {
	      ScalarWaveFunction sw = GetScalarWave(P[2],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[3],V_OUT);
	      theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 1) {
	      // throw some sort of error...
	    }
	  } else if(d2Spin_1 == 2) { 
	    if(d2Spin_2 == 0) {
	      ScalarWaveFunction sw = GetScalarWave(P[3],S_OUT);
	      VectorWaveFunction vw = GetVectorWave(P[2],V_OUT);
	      theAmp += VVSAmp(osv,vw,sw,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(d2Spin_2 == 2) {
	      VectorWaveFunction vw1 = GetVectorWave(P[2],V_OUT);
	      VectorWaveFunction vw2 = GetVectorWave(P[3],V_OUT);
	      theAmp += VVVAmp(vw1,vw2,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    }
	  } else if(d2Spin_1 == 1) {
	    // fermions
	    assert(d2Spin_2 == 1);
	    int f1Num = Particle::pl[dec2->ListDaughters()[0]].FermionNumber();
	    int f2Num = Particle::pl[dec2->ListDaughters()[1]].FermionNumber();
	    if (f1Num == 1 || (f1Num == 2 && f2Num != 1)) {
	      FermionWaveFunction fwfPart = GetFermionWave(P[2], F_OUTPART);
	      FermionWaveFunction fwfAnti = GetFermionWave(P[3], F_INANTI);
	      theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else if(f1Num == -1 || (f1Num == 2 && f2Num == 1)) {
	      FermionWaveFunction fwfAnti = GetFermionWave(P[2], F_INANTI);
	      FermionWaveFunction fwfPart = GetFermionWave(P[3], F_OUTPART);
	      theAmp += FFVAmp(fwfAnti,fwfPart,osv,dec2->getVertex().Couplings(),
			       dec2->getVertex().UserFlag());
	    } else {
	      // throw some sort of error...
	    }
	  }
	}
      }
//      debug << "ic = " << ic << ", j = " << j << ", theAmp = " << theAmp << "\n";
//      cout << "j = " << j << ", theAmp = " << theAmp << "\n";
    }
    finalValue += real(theAmp * conj(theAmp) * ColorFactor(j));
    if(j == 0) {
      out1 += real(theAmp * conj(theAmp) * ColorFactor(j));
    } if(j == 1) {
      out2 += real(theAmp * conj(theAmp) * ColorFactor(j));
    }
  }

  // Now, if we *didn't* include the four-vertices, do it now...
  if(haveFourVertices && !includedFourVertices) {
    complex<double> theAmp;
    if(fourVertices[0].Type() == "SSSS") {
      // don't need to care about order due to symmetry;
      // P[0] is always parent
      ScalarWaveFunction s1 = GetScalarWave(P[0], S_IN);
      ScalarWaveFunction s2 = GetScalarWave(P[1], S_OUT);
      ScalarWaveFunction s3 = GetScalarWave(P[2], S_OUT);
      ScalarWaveFunction s4 = GetScalarWave(P[3], S_OUT);
      for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	theAmp += SSSSAmp(s1,s2,s3,s4,fourVertices[v4i].Couplings(),
			  fourVertices[v4i].UserFlag());
      }
      includedFourVertices = true;
    } else if(fourVertices[0].Type() == "VVSS") {
      // Need to figure out which particles are scalars vs vectors...
      // Are we decaying a vector, or a scalar?
      // scalar...
      if(Particle::pl[Parent()].TwiceSpin() == 0) {
	ScalarWaveFunction s1 = GetScalarWave(P[0], S_IN);
	// use POrig since they are in a definite order
	if(Particle::pl[ListDaughters()[0]].TwiceSpin() == 0) {
	  ScalarWaveFunction s2 = GetScalarWave(POrig[1], S_OUT);
	  VectorWaveFunction v1 = GetVectorWave(POrig[2], V_OUT);
	  VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	    theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
			      fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	} else if(Particle::pl[ListDaughters()[1]].TwiceSpin() == 0) {
	  ScalarWaveFunction s2 = GetScalarWave(POrig[2], S_OUT);
	  VectorWaveFunction v1 = GetVectorWave(POrig[1], V_OUT);
	  VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	    theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
			      fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	} else if(Particle::pl[ListDaughters()[2]].TwiceSpin() == 0) {
	  ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	  VectorWaveFunction v1 = GetVectorWave(POrig[1], V_OUT);
	  VectorWaveFunction v2 = GetVectorWave(POrig[2], V_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	    theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
			      fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	}
      } else if(Particle::pl[Parent()].TwiceSpin() == 2) {
	VectorWaveFunction v1 = GetVectorWave(P[0], V_IN);
	// use POrig since they are in a definite order
	if(Particle::pl[ListDaughters()[0]].TwiceSpin() == 2) {
	  VectorWaveFunction v2 = GetVectorWave(POrig[1], V_OUT);
	  ScalarWaveFunction s1 = GetScalarWave(POrig[2], S_OUT);
	  ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	    theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
			      fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	} else if(Particle::pl[ListDaughters()[1]].TwiceSpin() == 2) {
	  VectorWaveFunction v2 = GetVectorWave(POrig[2], V_OUT);
	  ScalarWaveFunction s1 = GetScalarWave(POrig[1], S_OUT);
	  ScalarWaveFunction s2 = GetScalarWave(POrig[3], S_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
  	        theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	} else if(Particle::pl[ListDaughters()[2]].TwiceSpin() == 2) {
	  VectorWaveFunction v2 = GetVectorWave(POrig[3], V_OUT);
	  ScalarWaveFunction s1 = GetScalarWave(POrig[1], S_OUT);
	  ScalarWaveFunction s2 = GetScalarWave(POrig[2], S_OUT);
	  for(int v4i = 0; v4i < fourVertices.size(); v4i++) {
	    theAmp += VVSSAmp(v1,v2,s1,s2,fourVertices[v4i].Couplings(),
				  fourVertices[v4i].UserFlag());
	  }
	  includedFourVertices = true;
	}
      }
    }
    finalValue += real(theAmp * conj(theAmp) * ColorFactor(-1));
  }
//  debug.close();
  P[0] = POrig[0];
  P[1] = POrig[1];
  P[2] = POrig[2];
  P[3] = POrig[3]; 
  if(blah % 10000 == 0) {
//      cout << "out1, out2 = " << out1 << ", " << out2 << "\n";
  }
//  cout << "finalValue = " << finalValue << "\n";
  return finalValue;
}

double ThreeBodyDecayMode::ColorFactor(int n) {
  // we have a decay of the form P -> 0 + 1, I -> 2 + 3, I is 0 or 1.
  // first figure out the colors of each.
  int parentC = Particle::pl[parent].NColors();

  // special case: n = -1 means to use a direct four-body vertex
  if(n == -1) {
    int d1C, d2C, d3C;
    d1C = Particle::pl[products[0]].NColors();
    d2C = Particle::pl[products[0]].NColors();
    d3C = Particle::pl[products[0]].NColors();
    int n1 = 0;
    int n3 = 0;
    int n8 = 0;
    if(d1C == 1) n1++;
    else if(d1C == 3) n3++;
    else if(d1C == 8) n8++;
    if(d2C == 1) n1++;
    else if(d2C == 3) n3++;
    else if(d2C == 8) n8++;
    if(d3C == 1) n1++;
    else if(d3C == 3) n3++;
    else if(d3C == 8) n8++;
    if(n1 == 3) {
      return 1.0;
    }
    if(parentC == 1) {
      if(n1 == 1 && n3 == 2) {
	return 3;
      } else if(n1 == 1 && n8 == 2) {
	return 8;
      } else {
	cout << "Weirdness in ThreeBodyDecay::ColorFactor, mark 1a\n";
	return 0.;
      }
    } else if(parentC == 3) {
      if(n1 == 2 && n3 == 1) {
        return 1;
      } else if(n8 == 2 && n3 == 1) {
        return 8;
      } else if(n3 == 3) {
	return 3;
      } else if(n1 == 1 && n3 == 1 && n8 == 1) {
	return 4./3;
      } else {
	cout << "Weirdness in ThreeBodyDecay::ColorFactor, mark 1b\n";
	return 0.;
      }
    } else if(parentC == 8) {
      if(n1 == 2 && n8 == 1) {
	return 1;
      } else if(n3 == 2 && n8 == 1) {
	return 3;
      } else if(n8 == 3) {
	return 8;
      } else if(n3 == 2 && n1 == 1) {
	return 1./2.;
      } else if(n8 == 2 && n1 == 1) {
	return 4./3.;
      } else {
	cout << "Weirdness in ThreeBodyDecay::ColorFactor, mark 1c\n";
	return 0.;
      }
    }
    return 1.;
  }

  list< TwoBodyDecayPair >::iterator pairN = vertices[n].begin();
  TwoBodyDecayMode* dec2 = pairN->pr.second;
  int d1C, interC, d2C, d3C;
  // These label the colors: parentC -> d1C + interC -> d1C + d2C + d3C
  interC = Particle::pl[dec2->Parent()].NColors();
  int d1N = 1 - pairN->I; // pairN->I is 0 or 1, so this is the opposite.
  if(pairN->i0 == d1N) {
    d1C = Particle::pl[products[0]].NColors();
    d2C = Particle::pl[products[1]].NColors();
    d3C = Particle::pl[products[2]].NColors();
  } else if(pairN->i1 == d1N) {
    d1C = Particle::pl[products[1]].NColors();
    d2C = Particle::pl[products[0]].NColors();
    d3C = Particle::pl[products[2]].NColors();
  } else if(pairN->i2 == d1N) {
    d1C = Particle::pl[products[2]].NColors();
    d2C = Particle::pl[products[0]].NColors();
    d3C = Particle::pl[products[1]].NColors();
  } else {
    // error!
    cout << "Weirdness in ThreeBodyDecay::ColorFactor, mark 2\n";
    return 0.;
  }

  // Now, fill in every option.
  // First, 1 -> 1 + 1 + 1 or 1 -> 1 + 3 + 3 or 1 -> 1 + 8 + 8
  if((parentC == 1 && d1C == 1) || (parentC == 1 && d3C == 1)) {
    return d2C;
  }
  if(parentC == 1 && d2C == 1) {
    return d1C;
  }

  // Next, 1 -> 3 + 3 + 8
  // case 1: 1 -> 8 + 8 -> 8 + 3 + 3
  if(parentC == 1 && d1C == 8 && d2C == 3 && d3C == 3) {
    return 4.;
  // case 2: 1 -> 3 + 3 -> 3 + 8 + 3
  } else if(parentC == 1 && d1C == 3 && ((d2C == 8 && d3C == 3) 
					 || (d2C == 3 && d3C == 8))) {
    return 3.;
  }

  // 3 -> 1 + 1 + 3, or 8 -> 1 + 1 + 8?
  if(parentC == 3 && ((d1C == 1 && d2C == 1)||(d1C == 1 && d3C == 1)||(d2C == 1 && d3C == 1))) {
    return 1;
  }

  // 3 -> 3 + 8 + 1
  // case 1: 3 -> 1 + 3 -> 1 + 3 + 8
  if(parentC == 3 && d1C == 1 && ((d2C == 8 && d3C == 3) 
				  || (d2C == 3 && d3C == 8))) {
    return 4./3;
  // case 2: 3 -> 8 + 3 -> 8 + 3 + 1
  } else if(parentC == 3 && d1C == 8 && ((d2C == 1 && d3C == 3)
					 || (d3C == 3 && d2C == 1))) {
    return 4./3;
  }

  // 3 -> 3 + 3 + 3
  if(parentC == 3 && d1C == 3 && d2C == 3 && d3C == 3) {
    // case 1: 3 -> 3 + 8 -> 3 + 3 + 3
    if(interC == 8) {
      return 2./3;
    // case 2: 3 -> 3 + 1 -> 3 + 3 + 3
    } else if (interC == 1) {
      return 3.;
    }
  }

  // 3 -> 3 + 8 + 8
  if(parentC == 3 && ((d1C == 8 && d2C == 8) || (d1C == 8 && d3C == 8) || (d2C == 8 && d3C == 8))) {
    // case 1: 3 -> 3 + 1 -> 3 + 8 + 8
    if(interC == 1) {
      return 8;
    // case 2: 3 -> 3 + 8 -> 3 + 8 + 8
    } else if(interC == 8) {
      return 16./9;
    }
  }

  // 8 -> 3 + 3 + 1
  if(parentC == 8 && ((d1C == 3 && d2C == 3 && d3C == 1) || (d1C == 3 && d3C == 3 && d2C == 1) || (d2C == 3 && d3C == 3 && d1C == 1))) {
    // case 1: 8 -> 8 + 1 -> 3 + 3 + 1
    if(interC == 8) {
      return 1./2.;
    // case 2: 8 -> 3 + 3 -> 3 + 3 + 1
    } else if(interC == 3) {
      return 1./2.;
    } 
  }

  // 8 -> 3 + 3 + 8
  if(parentC == 8 && ((d1C == 3 && d2C == 3 && d3C == 8) || (d1C == 3 && d3C == 3 && d2C == 8) || (d2C == 3 && d3C == 3 && d1C == 8))) {
    // case 1: 8 -> 8 + 8 -> 3 + 3 + 8
    if(interC == 8) {
      return 2./3.;
    // case 2: 8 -> 3 + 3 -> 3 + 3 + 8
    } else if(interC == 3) {
      return 2./3.;
    // case 3: 8 -> 8 + 1 -> 8 + 3 + 3
    } else if(interC == 1) {
      return 3.;
    } 
  }

  // 8 -> 8 + 8 + 8
  if(parentC == 8 && d1C == 8 && d2C == 8 && d3C == 8) {
    if(interC == 1) {
      return 8.;
    } else {
      return 16./9.;
    }
  }

  // 8 -> 8 + 8 + 1
  if(parentC == 8 && ((d1C == 8 && d2C == 8 && d3C == 1) || (d1C == 8 && d3C == 8 && d2C == 1) || (d2C == 8 && d3C == 8 && d1C == 1))) {
    // case 1: 8 -> 8 + 1 -> 8 + 8 + 1
    if(interC == 1) {
      return 4./3.;
    // case 2: 8 -> 8 + 8 -> 8 + 8 + 1
    } else if(interC == 3) {
      return 4./3.;
    } 
  }

  return 1;
}
