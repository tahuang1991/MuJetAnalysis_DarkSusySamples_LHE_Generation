#include "Vertex.h"
#include "Values.h"
#include <fstream>
#include <iostream>
#include <cmath>
using namespace std;

// Access information

int Vertex::Count() {
  return particles.size();
}

std::complex<double> Vertex::Coupling1() {
  return Values::v[couplingName];
}

std::complex<double> Vertex::Coupling2() {
  return Values::v2[couplingName];
}

std::vector< std::complex<double> > Vertex::Couplings() {
  std::vector< std::complex<double> > thecouplings;
  thecouplings.push_back(this->Coupling1());
  thecouplings.push_back(this->Coupling2());
  return thecouplings;
}

std::string Vertex::Leg(int i) {
  return particles[i];
}

int Vertex::Multiplicity(std::string p) {
  int mult = 0;
  for(int j = 0; j < particles.size(); j++) {
    if(p == particles[j])
      mult++;
  }
  return mult;
}

bool Vertex::Decays(std::string p) {
  int mult = 0;
  double totmass = 0;
  for(int j = 0; j < particles.size(); j++) {
    if(p == particles[j])
      mult++;
    else
      totmass += fabs(Particle::pl[particles[j]].Mass());
  }
  if(mult == 1 && totmass < fabs(Particle::pl[p].Mass()))
    return true;
  return false;
}

std::string Vertex::Type() {
  return thetype;
}

char Vertex::UserFlag() {
  return usrFlag;
}

std::string Vertex::getCouplingName() {
  return couplingName;
}

// Alter the vertex

void Vertex::SetCoupling(std::string theCouplingName) {
  couplingName = theCouplingName;
}

void Vertex::AddParticle(std::string p) {
  particles.push_back(p);
}

void Vertex::SetType(std::string theType) {
  thetype = theType;
}

void Vertex::SetUserFlag(char usrf) {
  usrFlag = usrf;
}

std::list<Vertex> Vertex::vl;

void Vertex::ParseMGFile(std::string filename) {
  ifstream in(filename.c_str());
  string line;
  while(getline(in,line)) {
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
	words.push_back(line.substr(lastPos, pos-lastPos));
	lastPos = line.find_first_not_of(" ",pos);
	pos = line.find_first_of(" ",lastPos);
      }
      if(words.size() == 5 || words.size() == 6 || 
         (words.size() == 7 && (words[4] == "DUM0" || words[4] == "DUM1"))) {
	// Add a new 3-particle vertex
	map<string,Particle>::iterator part1 = Particle::pl.find(words[0]);
	map<string,Particle>::iterator part2 = Particle::pl.find(words[1]);
	map<string,Particle>::iterator part3 = Particle::pl.find(words[2]);
	if(part1 == Particle::pl.end() || part2 == Particle::pl.end()
	   || part3 == Particle::pl.end()) {
	  cout << "Error: particle in vertex is not defined!\n";
	  cout << "  Particles: " << words[0] << ", " << words[1]
	       << ", " << words[2]
	       << endl;
	} else {
	  Vertex vNew;
	  // For FFS, FFV vertices, we need to flip the second particle.
	  // E.g. the entries "t b w+" and "b t w-" define for us vertices
	  // "t b~ w+" and "b t~ w-".
	  // For FFS vertices, the MG convention is that "f1 f2 s" allows
	  // s* > f2 f1~, f2~ > f1~ s, f1 > f2 s
	  if(part2->second.FermionNumber() != 0) {
	    words[1] = part2->second.Antiparticle();
	    if(part3->second.TwiceSpin() == 0) {
	      words[2] = part3->second.Antiparticle();
	    }
	  }
	  // for SSS vertices, invert *every* particle, as the MG
	  // convention is that "a b c" allows a~ > b c, b~ > a c,
	  // c~ > a b
	  if(part1->second.TwiceSpin() == 0 && part2->second.TwiceSpin() == 0
	     && part3->second.TwiceSpin() == 0) {
	    words[0] = part1->second.Antiparticle();
	    words[1] = part2->second.Antiparticle();
	    words[2] = part3->second.Antiparticle();
	  }
	  vNew.AddParticle(words[0]);
	  vNew.AddParticle(words[1]);
	  vNew.AddParticle(words[2]);
	  // Force coupling to be all caps
	  for(int c = 0; c < words[3].length(); c++) {
	    words[3][c] = toupper(words[3][c]);
	  }
	  vNew.SetCoupling(words[3]);
	  int fcount=0, scount=0, vcount=0, tcount=0;
	  if(part1->second.TwiceSpin() == 0) scount++;
	  else if(part1->second.TwiceSpin() == 1) fcount++;
	  else if(part1->second.TwiceSpin() == 2) vcount++;
	  else if(part1->second.TwiceSpin() == 4) tcount++;
	  if(part2->second.TwiceSpin() == 0) scount++;
	  else if(part2->second.TwiceSpin() == 1) fcount++;
	  else if(part2->second.TwiceSpin() == 2) vcount++;
	  else if(part2->second.TwiceSpin() == 4) tcount++;
	  if(part3->second.TwiceSpin() == 0) scount++;
	  else if(part3->second.TwiceSpin() == 1) fcount++;
	  else if(part3->second.TwiceSpin() == 2) vcount++;
	  else if(part3->second.TwiceSpin() == 4) tcount++;
	  if(fcount == 1 || fcount == 3) {
	    cout << "Bad vertex! Odd fermion number.\n";
	    cout << line << endl;
	    continue;
	  }
	  if(scount == 3) {
	    vNew.SetType("SSS");
	  } else if(scount ==2 && vcount == 1) {
	    vNew.SetType("VSS");
	  } else if(scount == 1 && vcount == 2) {
	    vNew.SetType("VVS");
	  } else if(vcount == 3) {
	    vNew.SetType("VVV");
	  } else if(fcount == 2 && vcount == 1) {
	    vNew.SetType("FFV");
	  } else if(fcount == 2 && scount == 1) {
	    vNew.SetType("FFS");
	  } else if(fcount == 2 && tcount == 1) {
	    vNew.SetType("FFT");
	  } else if(scount == 1 && tcount == 2) {
	    vNew.SetType("STT");
	  } // etc...
	  if(words.size() == 6) {
	    vNew.SetUserFlag(words[5][0]);
	  } else {
	    vNew.SetUserFlag(' ');
	  }
	  Vertex::vl.push_back(vNew);
	}
      }
      else if(words.size() == 8 || words.size() == 9) {
	// Add a new 4-particle vertex
	map<string,Particle>::iterator part1 = Particle::pl.find(words[0]);
	map<string,Particle>::iterator part2 = Particle::pl.find(words[1]);
	map<string,Particle>::iterator part3 = Particle::pl.find(words[2]);
	map<string,Particle>::iterator part4 = Particle::pl.find(words[3]);
	if(part1 == Particle::pl.end() || part2 == Particle::pl.end()
	   || part3 == Particle::pl.end() || part4 == Particle::pl.end()) {
	  cout << "Error: particle in vertex is not defined!\n";
	  cout << "  Particles: " << words[0] << ", " << words[1]
	       << ", " << words[2] << ", " << words[3]
	       << endl;
	} else {
	  int fcount=0, scount=0, vcount=0, tcount=0;
	  if(part1->second.TwiceSpin() == 0) scount++;
	  else if(part1->second.TwiceSpin() == 1) fcount++;
	  else if(part1->second.TwiceSpin() == 2) vcount++;
	  else if(part1->second.TwiceSpin() == 4) tcount++;
	  if(part2->second.TwiceSpin() == 0) scount++;
	  else if(part2->second.TwiceSpin() == 1) fcount++;
	  else if(part2->second.TwiceSpin() == 2) vcount++;
	  else if(part2->second.TwiceSpin() == 4) tcount++;
	  if(part3->second.TwiceSpin() == 0) scount++;
	  else if(part3->second.TwiceSpin() == 1) fcount++;
	  else if(part3->second.TwiceSpin() == 2) vcount++;
	  else if(part3->second.TwiceSpin() == 4) tcount++;
	  if(part4->second.TwiceSpin() == 0) scount++;
	  else if(part4->second.TwiceSpin() == 1) fcount++;
	  else if(part4->second.TwiceSpin() == 2) vcount++;
	  else if(part4->second.TwiceSpin() == 4) tcount++;
          // case SSSS or VVSS
          if(scount == 4 || (vcount == 2 && scount == 2)) {
	    Vertex vNew;
	    // invert all, based on checking what decays MG allows
	    words[0] = part1->second.Antiparticle();
	    words[1] = part2->second.Antiparticle();
	    words[2] = part3->second.Antiparticle();
	    words[3] = part4->second.Antiparticle();
	    vNew.AddParticle(words[0]);
	    vNew.AddParticle(words[1]);
	    vNew.AddParticle(words[2]);
	    vNew.AddParticle(words[3]);
	    // Force coupling to be all caps
	    for(int c = 0; c < words[4].length(); c++) {
	      words[4][c] = toupper(words[4][c]);
	    }
	    vNew.SetCoupling(words[4]);
	    if(scount == 4) {
  	      vNew.SetType("SSSS");
	    } else if(vcount == 2 && scount == 2) {
	      vNew.SetType("VVSS");
	    }
	    if(words.size() == 9) {
	      vNew.SetUserFlag(words[8][0]);
	    } else {
	      vNew.SetUserFlag(' ');
	    }
	    Vertex::vl.push_back(vNew);
	  } else {
	    cout << "Unimplemented spin structure for vertex, ignoring\n";
	    cout << "  Particles: " << words[0] << ", " << words[1]
	         << ", " << words[2] << ", " << words[3]
	         << endl;
	    cout << "Some four-particle vertices are unimplemented. Email the authors if this is a problem\n";
	  }
	}
      }
    }
  }
}
