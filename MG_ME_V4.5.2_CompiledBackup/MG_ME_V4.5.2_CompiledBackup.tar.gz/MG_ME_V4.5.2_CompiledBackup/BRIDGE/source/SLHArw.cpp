#include "SLHArw.h"
using namespace std;

std::string stringtoupper(std::string in)
{
for (int i=0;i<in.length();i++)
    {
    in[i] = toupper(in[i]);
    }
return in;
}

void read_SLHA(SLHA& header,std::ifstream& in)
{
header.g1=0.0;
header.g2=0.0;
header.g3=0.0;
header.mw=0.0;
header.s2w=0.0;
string s1;
string block1="BLOCK MASS";
string block2="BLOCK NMIX";
string block3="BLOCK UMIX";
string block4="BLOCK VMIX";
string block5="BLOCK STOPMIX";
string block6="BLOCK SBOTMIX";
string block7="BLOCK STAUMIX";
string block8="BLOCK ALPHA";
string block9="BLOCK HMIX";
string block10="BLOCK AU";
string block11="BLOCK AD";
string block12="BLOCK AE";
string block13="BLOCK YU";
string block14="BLOCK YD";
string block15="BLOCK YE";
string block16="BLOCK SMINPUTS";
string block17="BLOCK MGSMPARM";
string block18="BLOCK GAUGE";
while(!in.eof())
        {
        getline(in,s1);
        s1=stringtoupper(s1);
        if(s1.find(block1)!=string::npos)
          readmass(header,in);
        if(s1.find(block2)!=string::npos)
          readnmix(header,in);
        if(s1.find(block3)!=string::npos)
          readumix(header,in);
        if(s1.find(block4)!=string::npos)
          readvmix(header,in);
        if(s1.find(block5)!=string::npos)
          readstopmix(header,in);
        if(s1.find(block6)!=string::npos)
          readsbotmix(header,in);
        if(s1.find(block7)!=string::npos)
          readstaumix(header,in);
        if(s1.find(block8)!=string::npos)
          readalpha(header,in);
        if(s1.find(block9)!=string::npos)
          readhmix(header,in);
        if(s1.find(block10)!=string::npos)
          readau(header,in);
        if(s1.find(block11)!=string::npos)
          readad(header,in);
        if(s1.find(block12)!=string::npos)
          readae(header,in);
        if(s1.find(block13)!=string::npos)
          readyu(header,in);
        if(s1.find(block14)!=string::npos)
          readyd(header,in);
        if(s1.find(block15)!=string::npos)
          readye(header,in);
        if(s1.find(block16)!=string::npos)
          readsminputs(header,in);
        if(s1.find(block17)!=string::npos)
          readmgsmparam(header,in); 
        if(s1.find(block18)!=string::npos)
          readgauge(header,in);     
        }
}

void read_SLHA_mass(std::ifstream& in)
{
  string s1;
  string block1="Block MASS";
  string block2="BLOCK MASS";
  while(!in.eof()) {
    getline(in,s1);
    if(s1.find(block1)!=string::npos || s1.find(block2)!=string::npos) {
      readmassmg(in);        
    }
  }
}

void readmassmg(std::ifstream& in)
{
string temp;
vector<string> tempsplit;
//two getlines since there is not a good exit character from the madgraph usrmod blocks vs regular blocks
getline(in,temp);
//getline(in,temp);
   // altered to stop reading if line begins with a letter rather than a number
   //   -- MR 3/31/09
while(!isalpha(temp[0]))
    {
      if((temp!="#")&&(temp[0]!='#'))
      {
        tempsplit=split(temp);
        //get particle now set its mass...
        Values::v[Particle::pl[Particle::plFromID[atoi(tempsplit[0].c_str())]].MassParam()]=atof(tempsplit[1].c_str());
	//        cout << tempsplit[0] << " mass: " << tempsplit[1] << endl;
      }
      getline(in,temp);
    }
  Values::v["ZERO"]=0.0;
}


void readmass(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    getline(in,temp);
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        header.mass.insert(make_pair(atoi(tempsplit[0].c_str()),atof(tempsplit[1].c_str())));
        //cout << tempsplit[0] << " mass: " << tempsplit[1] << endl;
        }
    }

}

void readnmix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<4;i++)
    {
    for(int j=0;j<4;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.nmix[i][j]=atof(tempsplit[2].c_str());
        //cout << "N[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readumix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<2;i++)
    {
    for(int j=0;j<2;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.umix[i][j]=atof(tempsplit[2].c_str());
        //cout << "U[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readvmix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<2;i++)
    {
    for(int j=0;j<2;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.vmix[i][j]=atof(tempsplit[2].c_str());
        //cout << "V[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readstopmix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<2;i++)
    {
    for(int j=0;j<2;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.stopmix[i][j]=atof(tempsplit[2].c_str());
        //cout << "stopmix[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readsbotmix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<2;i++)
    {
    for(int j=0;j<2;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.sbotmix[i][j]=atof(tempsplit[2].c_str());
        //cout << "sbotmix[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readstaumix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
for(int i=0;i<2;i++)
    {
    for(int j=0;j<2;j++)
        {
        getline(in,temp);
        tempsplit=split(temp);
        header.staumix[i][j]=atof(tempsplit[2].c_str());
        //cout << "staumix[" << i << "]" << "[" << j << "] :" << tempsplit[2] << endl;
        }
    }
}

void readalpha(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
tempsplit=split(temp);
header.alpha=atof(tempsplit[0].c_str());
//  cout << "alpha: " << tempsplit[0] << endl;
}

void readhmix(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
tempsplit=split(temp);
header.mu=atof(tempsplit[1].c_str());
//  cout << "mu: " << tempsplit[1] << endl;
getline(in,temp);
tempsplit=split(temp);
header.tanb=atof(tempsplit[1].c_str());
//  cout << "tanb: " << tempsplit[1] << endl;
getline(in,temp);
tempsplit=split(temp);
header.vev=atof(tempsplit[1].c_str());
//  cout << "vev: " << tempsplit[1] << endl;
}

void readau(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.au[0]=atof(tempsplit[2].c_str());
            //cout << "AU[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.au[1]=atof(tempsplit[2].c_str());
            //cout << "AU[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.au[2]=atof(tempsplit[2].c_str());
            //cout << "AU[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}

void readad(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.ad[0]=atof(tempsplit[2].c_str());
            //cout << "AD[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.ad[1]=atof(tempsplit[2].c_str());
            //cout << "AD[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.ad[2]=atof(tempsplit[2].c_str());
            //cout << "AD[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}

void readae(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.ae[0]=atof(tempsplit[2].c_str());
            //cout << "AE[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.ae[1]=atof(tempsplit[2].c_str());
            //cout << "AE[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.ae[2]=atof(tempsplit[2].c_str());
            //cout << "AE[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}

void readyu(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.yu[0]=atof(tempsplit[2].c_str());
            //cout << "YU[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.yu[1]=atof(tempsplit[2].c_str());
            //cout << "YU[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.yu[2]=atof(tempsplit[2].c_str());
            //cout << "YU[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}

void readyd(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.yd[0]=atof(tempsplit[2].c_str());
            //cout << "YD[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.yd[1]=atof(tempsplit[2].c_str());
            //cout << "YD[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.yd[2]=atof(tempsplit[2].c_str());
            //cout << "YD[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}

void readye(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        if(tempsplit[0]=="1"&&tempsplit[1]=="1")
            {
            header.ye[0]=atof(tempsplit[2].c_str());
            //cout << "YE[0]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="2"&&tempsplit[1]=="2")
            {
            header.ye[1]=atof(tempsplit[2].c_str());
            //cout << "YE[1]: " << tempsplit[2] <<endl;
            }
        if(tempsplit[0]=="3"&&tempsplit[1]=="3")
            {
            header.ye[2]=atof(tempsplit[2].c_str());
            //cout << "YE[2]: " << tempsplit[2] <<endl;
            } 
        }
    getline(in,temp);
    }
}


void readsminputs(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        switch(atoi(tempsplit[0].c_str()))
            {
            case 1:
                {
                header.alphaem=atof(tempsplit[1].c_str());
                break;
                }
            case 2:
                {
                header.gf=atof(tempsplit[1].c_str());
                break;
                }
            case 3:
                {
                header.alphas=atof(tempsplit[1].c_str());
                break;
                }
            case 4:
                {
                header.mz=atof(tempsplit[1].c_str());
                break;
                }
            case 5:
                {
                header.mb=atof(tempsplit[1].c_str());
                break;
                }
            case 6:
                {
                header.mt=atof(tempsplit[1].c_str());
                break;
                }
            case 7:
                {
                header.mtau=atof(tempsplit[1].c_str());
                break;
                }
            }
        }
    getline(in,temp);
    }
}

void readgauge(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        switch(atoi(tempsplit[0].c_str()))
            {
            case 1:
                header.g1=atof(tempsplit[1].c_str());
                //cout << "g1: " << header.g1 << endl;
                break;
            case 2:
                header.g2=atof(tempsplit[1].c_str());
                //cout << "g2: " << header.g2 << endl;
                break;
            case 3:
                header.g3=atof(tempsplit[1].c_str());
                //cout << "g3: " << header.g3 << endl;
                break;
            }
        }
    getline(in,temp);
    }
}

void readmgsmparam(SLHA& header,std::ifstream& in)
{
string temp;
vector<string> tempsplit;
getline(in,temp);
while(temp!="#" && (split(temp).size() > 1 || split(temp)[0] != "#") )
    {
    if((temp!="#")&&(temp[0]!='#'))
        {
        tempsplit=split(temp);
        switch(atoi(tempsplit[0].c_str()))
            {
            case 1:
                header.s2w=atof(tempsplit[1].c_str());
                break;
            case 2:
                header.mw=atof(tempsplit[1].c_str());
                break;
            }
        }
    getline(in,temp);
    }
}
