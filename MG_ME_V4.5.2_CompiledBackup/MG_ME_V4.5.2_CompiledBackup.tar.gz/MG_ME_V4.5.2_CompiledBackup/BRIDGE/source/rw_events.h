#ifndef RW_EVENTS_H
#define RW_EVENTS_H
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>

struct Events_Info
{
    double int_wgt;
    double av_wgt;
    double mx_wgt;
    int n_events;
    std::string event_format;
};

std::vector<std::string> read_banner(std::ifstream& in,std::ios::pos_type& bend,Events_Info& evt_inf);

bool issepchar(char c);
bool space(char c);
bool not_space(char c);
bool isnum(char c);
std::vector<std::string> split(const std::string& str);

std::vector<std::vector<std::string> > split_banner(std::vector<std::string>& banner);

void write_banner(std::ofstream& outfile,std::vector<std::string>& old_banner,std::vector<std::string>& new_banner);

bool extract_banner_info(std::vector<std::vector<std::string> >& banner,Events_Info& evt_inf);



#endif
