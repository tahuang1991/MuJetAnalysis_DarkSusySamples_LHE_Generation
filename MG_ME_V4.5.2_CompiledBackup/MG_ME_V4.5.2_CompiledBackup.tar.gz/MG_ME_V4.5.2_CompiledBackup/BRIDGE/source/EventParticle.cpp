#include "EventParticle.h"

EventParticle::EventParticle(): IDcode(0),mother1(0),mother2(0),color1(0),color2(0),status(0),P5(0.0),vti(0.0) { }

EventParticle::EventParticle(int a1, int a2, int a3, int a4, int a5, int a6, double fv[4], int hel): P5(0.0),vti(0.0)
{
setid(a1);
setmoth1(a2);
setmoth2(a3);
setcolor1(a4);
setcolor2(a5);
setstatus(a6); 
fv=P;
hel=Helicity;
}


int EventParticle::idup()
{
return IDcode;
}

int EventParticle::mothup1()
{
return mother1;
}

int EventParticle::mothup2()
{
return mother2;
}

int EventParticle::icolup1()
{
return color1;
}

int EventParticle::icolup2()
{
return color2;
}

int EventParticle::istup()
{
return status;
}

double EventParticle::p5()
{
return P5;
}

double EventParticle::vtimup()
{
return vti;
}

void EventParticle::setid(int theID)
{
IDcode=theID;
}

void EventParticle::setmoth1(int theM1)
{
mother1=theM1;
}

void EventParticle::setmoth2(int theM2)
{
mother2=theM2;
}

void EventParticle::setcolor1(int theCol1)
{
color1=theCol1;
}

void EventParticle::setcolor2(int theCol2)
{
color2=theCol2;
}

void EventParticle::setstatus(int theStatus)
{
status=theStatus;
}

void EventParticle::setP5(double thep5)
{
P5=thep5;
}
    
void EventParticle::setvtimup(double thevti)
{
vti=thevti;
}
