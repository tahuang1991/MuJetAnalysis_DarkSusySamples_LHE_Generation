#include "OffShell.h"
using namespace std;

// HELAS routines
extern "C" void jioxxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void jvvxxx_(Complex*,Complex*,double& ,double&,double&,Complex*);
extern "C" void jssxxx_(Complex*,Complex*,Complex&,double&,double&,Complex*);
extern "C" void jvsxxx_(Complex*,Complex*,Complex&,double&,double&,Complex*);
extern "C" void fsixxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void fsoxxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void fvixxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void fvoxxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void hioxxx_(Complex*,Complex*,Complex*,double&,double&,Complex*);
extern "C" void hssxxx_(Complex*,Complex*,Complex&,double&,double&,Complex*);
extern "C" void hvvxxx_(Complex*,Complex*,Complex&,double&,double&,Complex*);
extern "C" void hvsxxx_(Complex*,Complex*,Complex&,double&,double&,Complex*);

VectorWaveFunction OffShellVectorFromFF(FermionWaveFunction fIn, 
					FermionWaveFunction fOut, 
					vector< complex<double> > couplings, 
					double vMass, double vWidth)
{
  VectorWaveFunction v;
  Complex theCouplings[2];
  theCouplings[0] = CCxToFCx(couplings[0]);
  theCouplings[1] = CCxToFCx(couplings[1]);
  jioxxx_(fIn.FWF,fOut.FWF,theCouplings,vMass,vWidth,v.VWF);
  return v;
}

VectorWaveFunction OffShellVectorFromVV(VectorWaveFunction v1,
					VectorWaveFunction v2,
					vector< complex<double> > couplings,
					double vMass, double vWidth)
{
  VectorWaveFunction v;
  double coupling = couplings[0].real();
  jvvxxx_(v1.VWF,v2.VWF,coupling,vMass,vWidth,v.VWF);
  return v;
}

VectorWaveFunction OffShellVectorFromSS(ScalarWaveFunction s1,
					ScalarWaveFunction s2,
					vector< complex<double> > couplings,
					double vMass, double vWidth)
{
  VectorWaveFunction v;
  Complex theCoupling = CCxToFCx(couplings[0]);
  jssxxx_(s1.SWF,s2.SWF,theCoupling,vMass,vWidth,v.VWF);
  return v;
}

VectorWaveFunction OffShellVectorFromVS(VectorWaveFunction v,
					ScalarWaveFunction s,
					vector< complex<double> > couplings,
					double vMass, double vWidth)
{
  VectorWaveFunction vOut;
  Complex theCoupling = CCxToFCx(couplings[0]);
  jvsxxx_(v.VWF, s.SWF, theCoupling,vMass,vWidth,vOut.VWF);
  return vOut;
}

FermionWaveFunction OffShellFermionFromFInS(FermionWaveFunction f,
					    ScalarWaveFunction s,
					    vector< complex<double> > couplings,
					    double fMass, double fWidth)
{
  FermionWaveFunction fOut;
  Complex theCoupling[2];
  theCoupling[0] = CCxToFCx(couplings[0]);
  theCoupling[1] = CCxToFCx(couplings[1]);
  fsixxx_(f.FWF,s.SWF,theCoupling,fMass,fWidth,fOut.FWF);
  return fOut;
}

FermionWaveFunction OffShellFermionFromFOutS(FermionWaveFunction f,
					     ScalarWaveFunction s,
					     vector<complex<double> > couplings,
					     double fMass, double fWidth)
{
  FermionWaveFunction fOut;
  Complex theCoupling[2];
  theCoupling[0] = CCxToFCx(couplings[0]);
  theCoupling[1] = CCxToFCx(couplings[1]);
  fsoxxx_(f.FWF,s.SWF,theCoupling,fMass,fWidth,fOut.FWF);
  return fOut;
}

FermionWaveFunction OffShellFermionFromFInV(FermionWaveFunction f,
					    VectorWaveFunction v,
					    vector<complex<double> > couplings,
					    double fMass, double fWidth)
{
  FermionWaveFunction fOut;
  Complex theCoupling[2];
  theCoupling[0] = CCxToFCx(couplings[0]);
  theCoupling[1] = CCxToFCx(couplings[1]);
  fvixxx_(f.FWF,v.VWF,theCoupling,fMass,fWidth,fOut.FWF);
  return fOut;
}

FermionWaveFunction OffShellFermionFromFOutV(FermionWaveFunction f,
					     VectorWaveFunction v,
					     vector<complex<double> > couplings,
					     double fMass, double fWidth)
{
  FermionWaveFunction fOut;
  Complex theCoupling[2];
  theCoupling[0] = CCxToFCx(couplings[0]);
  theCoupling[1] = CCxToFCx(couplings[1]);
  fvoxxx_(f.FWF,v.VWF,theCoupling,fMass,fWidth,fOut.FWF);
  return fOut;
}

ScalarWaveFunction OffShellScalarFromFF(FermionWaveFunction fIn,
					FermionWaveFunction fOut,
					vector<complex<double> > couplings,
					double sMass, double sWidth)
{
  ScalarWaveFunction s;
  Complex theCoupling[2];
  theCoupling[0] = CCxToFCx(couplings[0]);
  theCoupling[1] = CCxToFCx(couplings[1]);
  hioxxx_(fIn.FWF,fOut.FWF,theCoupling,sMass,sWidth,s.SWF);
  return s;
}

ScalarWaveFunction OffShellScalarFromSS(ScalarWaveFunction s1,
					ScalarWaveFunction s2,
					vector<complex<double> > couplings,
					double sMass, double sWidth)
{
  ScalarWaveFunction s;
  Complex theCoupling = CCxToFCx(couplings[0]);
  hssxxx_(s1.SWF,s2.SWF,theCoupling,sMass,sWidth,s.SWF);
  return s;
}

ScalarWaveFunction OffShellScalarFromVV(VectorWaveFunction v1,
					VectorWaveFunction v2,
					vector<complex<double> > couplings,
					double sMass, double sWidth)
{
  ScalarWaveFunction s;
  Complex theCoupling = CCxToFCx(couplings[0]);
  hvvxxx_(v1.VWF,v2.VWF,theCoupling,sMass,sWidth,s.SWF);
  return s;
}

ScalarWaveFunction OffShellScalarFromVS(VectorWaveFunction v,
					ScalarWaveFunction s,
					vector< complex<double> > couplings,
					double sMass, double sWidth)
{
  ScalarWaveFunction sOut;
  Complex theCoupling = CCxToFCx(couplings[0]);
  hvsxxx_(v.VWF, s.SWF, theCoupling,sMass,sWidth,sOut.SWF);
  return sOut;
}
