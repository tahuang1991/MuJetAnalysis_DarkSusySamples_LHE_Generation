#include "WaveFunctions.h"

// HELAS routines
extern "C" void sxxxxx_(double*, int &, Complex*);
extern "C" void vxxxxx_(double*, double &, int &, int &, Complex*);
extern "C" void ixxxxx_(double*, double &, int &, int &, Complex*);
extern "C" void oxxxxx_(double*, double &, int &, int &, Complex*);

// compute a scalar wavefunction
ScalarWaveFunction GetScalarWave(FourVector p, ScalarDirection sd)
{
  int sdi = (sd == S_IN ? -1 : 1);
  ScalarWaveFunction swf;
  sxxxxx_(p.P, sdi, swf.SWF);
  return swf;
}

// compute a vector wavefunction
// Helicity should be -1, 0, 1 (not 0 if mass = 0)
VectorWaveFunction GetVectorWave(FourVector p, VectorDirection vd)
{
  double vmass = p.M();
  int vdi = (vd == V_IN ? -1 : 1);
  VectorWaveFunction vwf;
  vxxxxx_(p.P,vmass,p.Helicity,vdi,vwf.VWF);
  return vwf;
}

// compute a fermion wavefunction
FermionWaveFunction GetFermionWave(FourVector p, FermionDirection fd,
				   bool negMass)
{
  double fmass = p.M() * (negMass ? -1 : 1);
  FermionWaveFunction fwf;
  int nsf;
  if(fd == F_INPART) {
    nsf = 1;
    ixxxxx_(p.P,fmass,p.Helicity,nsf,fwf.FWF);
  } else if(fd == F_INANTI) {
    nsf = -1;
    ixxxxx_(p.P,fmass,p.Helicity,nsf,fwf.FWF);
  } else if(fd == F_OUTPART) {
    nsf = 1;
    oxxxxx_(p.P,fmass,p.Helicity,nsf,fwf.FWF);
  } else if(fd == F_OUTANTI) {
    nsf = -1;
    oxxxxx_(p.P,fmass,p.Helicity,nsf,fwf.FWF);
  }
  return fwf;
}
