#include "BRI.h"
#include "SLHArw.h"
#include <iostream>
#include <fstream>
#include <stdio.h>
#include "batchhelper.h"
using namespace std;

int mainOrig(vector<string> pargs) {
  // read SM parameters
  bool batch;
  if(pargs.size()!=0)
	  batch=true;
  else
	  batch=false;
  string particlefile;
  if(batch)
  {
	  particlefile=pargs[1];
  }
  else
  {
	cout << "Name of particle file (input/particles.dat): ";
	getline(cin,particlefile);
  }
  checkfile(particlefile);
  if(particlefile == "") particlefile = "input/particles.dat";
  Particle::ParseMGFile(particlefile);
  string parameterfile;
  if(batch)
  {
	  parameterfile=pargs[2];
  }
  else
  {
	cout << "Name of parameter file (input/SMparams.txt): ";
	getline(cin,parameterfile);
  }
  checkfile(parameterfile);
  if(parameterfile == "") parameterfile = "input/SMparams.txt";
  Values::ParseMGFile(parameterfile);
  string interactionsfile;
  if(batch)
  {
	  interactionsfile=pargs[3];
  }
  else
  {
	cout << "Name of interactions file (input/interactions.dat): ";
	getline(cin,interactionsfile);
  }
  checkfile(interactionsfile);
  if(interactionsfile == "") interactionsfile = "input/interactions.dat";
  Vertex::ParseMGFile(interactionsfile);

  string directory;
  if(batch)
  {
	  directory=pargs[4];
  }
  else
  {
	cout << "Please enter the (relative) directory to which you want to save the grids.\n(Include the / at the end; the directory must already exist, default is results/): ";
	getline(cin,directory);
  }
  if(directory == "") directory = "results/";
  
  string slhadecfile;
  if(batch)
  {
	  slhadecfile=pargs[5];
  }
  else
  {
	cout << "What file do you wish to place the SLHA decays in(include relative path)?" << endl;
	cin >> slhadecfile;
  }
  ofstream slhaout(slhadecfile.c_str(), ofstream::ate);

  int nparticles;

  //choose which type of running modes and which particles
  vector<string> particlelist;
  if(batch)
  {
          nparticles=atoi(pargs[pargs.size()-1].c_str());

	  for(int i=6;i<6+nparticles;i++)
	  {
		  particlelist.push_back(pargs[i]);
	  }
  }
  else
  {
	particlechoice(particlelist);
  }
  //set up seed for decays
  string randseed;
  if(batch)
  {
	  randseed=pargs[6+nparticles];
  }
  else
  {
	cout << "Please enter a random number seed or write 'time' to use the time\n";
	cin >> randseed;
  }
  unsigned int theseedtouse;
  int c1=-1;
  istringstream iss(randseed);
  if(!(iss >> theseedtouse).fail()) {
    cout << "We understood that as " << theseedtouse << ", using that seed\n";
    c1=1;  
  } else {
    cout << "Using the time as seed.\n";
  }
  
  int ncall = 50000;
  string yesno;
  if(batch)
  {
	  ncall=atoi(pargs[7+nparticles].c_str());
  }
  else
  {
	cout << "The default number of Vegas calls is 50000. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y") {
		cout << "How many Vegas calls do you want to use? ";
		cin >> ncall;
	}
  }

  int maxiter = 5;
  if(batch)
  {
	  maxiter=atoi(pargs[8+nparticles].c_str());
  }
  else
  {
	cout << "The default max. number of Vegas iterations is 5. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y" || yesno == "yes" || yesno == "YES") {
		cout << "What max. no. of Vegas iterations do you want to use? ";
		cin >> maxiter;
	}
  }

  if(batch)
  {
    yesno = pargs[9+nparticles];
  }
  else
  {
    cout << "Would you like to calculate three-body widths even for particles with open 2-body channels? (Y/N) ";
    cin >> yesno;
  }
  bool calc3if2;
  if(yesno == "Y" || yesno == "y" || yesno == "yes" || yesno == "YES")
  {
    calc3if2 = true;
  }
  else
  {
    calc3if2 = false;
  }

  VegasRandom vr;
  if(c1==1)
    vr.Seed(theseedtouse);

  //loop in decay tables;
  // do all two-body decays before any 3-body decays
  vector<double> twobodywidths(particlelist.size());
  vector<BRI> decayManager;
  for(int i=0;i<particlelist.size();i++)
  {
  
    cout << "NOW CALCULATING TWO-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable =directory + testparticle + "_decays.table";
    ifstream input(decayTable.c_str());
    string line;
    if(getline(input,line)) {
      cout << "Decay table appears to already exist. Should we recreate it? ";
      cout << "Type 'yes' if so, otherwise we will exit.\n";
      string response;
      cin >> response;
      if(response != "yes") {
        cout << "Exiting now.\n";
        return 0;
      }
    }

    BRI bri(testparticle, &vr, directory);
    bri.setNumberVegasCalls(ncall);
    bri.setMaxVegasIter(maxiter);
    bri.buildModeList();
    decayManager.push_back(bri);
    cout << "We found the decay modes: \n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << "\n";
    }

    cout << "Now computing the two-body widths: \n";
    twobodywidths[i] = decayManager[i].computeTwoBodyWidths();
    cout << "Listing two-body branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }

    // Set width parameter for use in further calculations, if it's currently set to zero
    if(Particle::pl[testparticle].Width() == 0.) {
      string plwidth = testparticle + "__brcalcwidth";
      Values::v[plwidth] = twobodywidths[i];
      Values::v2[plwidth] = 0.0;
      Particle::pl[testparticle].SetWidth(plwidth);
    }
  }
  // loop again for three-body widths
  for(int i=0;i<particlelist.size();i++)
  {  
    cout << "NOW CALCULATING THREE-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable =directory + testparticle + "_decays.table";

    if((twobodywidths[i] == 0.) || (twobodywidths[i] != 0. && calc3if2)) {
      cout << "Now computing the three-body widths: \n";
      decayManager[i].computeThreeBodyWidths(twobodywidths[i]);
    } else {
      cout << "No three-body modes to calculate for this particle, moving on to output.\n";
    }
    cout << "Writing decay table.\n";
    decayManager[i].writeBRTable();
    decayManager[i].writeSLHAtable(slhaout);
    cout << "Listing final branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k = 0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }
    cout << "Finished particle.\n";
    //end of overall for loop
  }
  
  return 0;
}

int mainMG(vector<string>  pargs) {
  // read parameters assuming everything done according to usrmod!
  // i.e. assuming there is a well formed param_card as well as a couplings_check.txt
  // beyond the usual definition of interactions.dat and particles.dat
	 bool batch;
     if(pargs.size()!=0)
	   batch=true;
     else
	   batch=false;
     cout << "BRIDGE: Madgraph USRMOD interface" << endl;
     string directory="";
	 if(batch)
		 directory=pargs[1];
	 else
	 {
		while(directory=="")
			{
			cout << "What is the name of the model directory(assuming that it is a subdirectory of Models/): ";
			getline(cin,directory);
			if(directory=="")
				cout << "Empty name, please try again!" << endl;
			}
	 }
     string path="../Models/"+directory+"/";
     string particlefile=path+"particles.dat";
     // check first for new version "helas_couplings.txt"
     bool helascouplings = false;
     fstream fin;
     string parameterfile=path+"helas_couplings.txt";
     fin.open(parameterfile.c_str(),ios::in);
     if(fin.is_open()) {
       helascouplings=true;
     }
     fin.close();
     if(!helascouplings) {
       // try old version "couplings_check.txt"
       parameterfile = path+"couplings_check.txt";
       fin.open(parameterfile.c_str(),ios::in);
       if(!fin.is_open()) {
         cout << "Problem: neither " << path << "couplings_check.txt"
              << " or " << path << "helas_couplings.txt found!\n";
         cout << "Please make the appropriate file in your MG model directory\n";
         exit(0);
       }
       fin.close();
     }     
     string interactionsfile=path+"interactions.dat";
     string paramcard=path+"param_card.dat";
     Particle::ParseMGFile(particlefile);
     Values::ParseMGFile(parameterfile);
     Vertex::ParseMGFile(interactionsfile);
     // need to now parse param_card;
     ifstream parammass(paramcard.c_str());
     read_SLHA_mass(parammass);
     parammass.close();
     

   //choose which type of running modes and which particles
  vector<string> particlelist;
  int nparticles;
  if(batch)
  {
      nparticles =atoi(pargs[pargs.size()-1].c_str());
      for(int i=2;i<2+nparticles;i++)
      {
	particlelist.push_back(pargs[i]);
      }
  }
  else
  {
	int allchoice=particlechoice(particlelist);
  }
  
  //set up seed for decays
  string randseed;
  if(batch)
  {
	  randseed=pargs[2+nparticles];
  }
  else
  {
	cout << "Please enter a random number seed or write 'time' to use the time\n";
	cin >> randseed;
  }
  unsigned int theseedtouse;
  int c1=-1;
  istringstream iss(randseed);
  if(!(iss >> theseedtouse).fail()) {
    cout << "We understood that as " << theseedtouse << ", using that seed\n";
    c1=1;  
  } else {
    cout << "Using the time as seed.\n";
  }
  
  int ncall = 50000;
  string yesno;
  if(batch)
  {
	  ncall=atoi(pargs[3+nparticles].c_str());
  }
  else
  {
	cout << "The default number of Vegas calls is 50000. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y") {
		cout << "How many Vegas calls do you want to use? ";
		cin >> ncall;
	}
  }
  
  int maxiter = 5;
  if(batch)
  {
	  maxiter=atoi(pargs[4+nparticles].c_str());
  }
  else
  {
	cout << "The default max. number of Vegas iterations is 5. Would you like to change this? (Y/N) ";
	cin >> yesno;
	if(yesno == "Y" || yesno == "y") {
		cout << "What max. no. of Vegas iterations do you want to use? ";
		cin >> maxiter;
	}
  }

  if(batch)
  {
    yesno = pargs[5+nparticles];
  }
  else
  {
    cout << "Would you like to calculate three-body widths even for particles with open 2-body channels? (Y/N) ";
    cin >> yesno;
  }
  bool calc3if2;
  if(yesno == "Y" || yesno == "y" || yesno == "yes" || yesno == "YES")
  {
    calc3if2 = true;
  }
  else
  {
    calc3if2 = false;
  }
  
  string slhadecfile=path+"slha.out";
  ofstream slhaout(slhadecfile.c_str());
  cout << "SLHA decay tables will be stored in the file " << path << "slha.out" << endl;
  VegasRandom vr;
  if(c1==1)
    vr.Seed(theseedtouse);

  //loop in decay tables;
  // do all two-body decays before any 3-body decays
  vector<double> twobodywidths(particlelist.size());
  vector<BRI> decayManager;
  for(int i=0;i<particlelist.size();i++)
  {
  
    cout << "NOW CALCULATING TWO-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable = path + testparticle + "_decays.table";
    ifstream input(decayTable.c_str());
    string line;
    if(getline(input,line)) {
      cout << "Decay table appears to already exist. Should we recreate it? ";
      cout << "Type 'yes' if so, otherwise we will exit.\n";
      string response;
      cin >> response;
      if(response != "yes") {
        cout << "Exiting now.\n";
        return 0;
      }
    }

    BRI bri(testparticle, &vr, path);
    bri.setNumberVegasCalls(ncall);
    bri.setMaxVegasIter(maxiter);
    bri.buildModeList();
    decayManager.push_back(bri);
    cout << "We found the decay modes: \n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << "\n";
    }

    cout << "Now computing the two-body widths: \n";
    twobodywidths[i] = decayManager[i].computeTwoBodyWidths();
    cout << "Listing two-body branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k=0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }

    // Set width parameter for use in further calculations, if it's currently set to zero
    if(Particle::pl[testparticle].Width() == 0.) {
      string plwidth = testparticle + "__brcalcwidth";
      Values::v[plwidth] = twobodywidths[i];
      Values::v2[plwidth] = 0.0;
      Particle::pl[testparticle].SetWidth(plwidth);
    }
  }
  // loop again for three-body widths
  for(int i=0;i<particlelist.size();i++)
  {  
    cout << "NOW CALCULATING THREE-BODY DECAYS OF PARTICLE " << i+1 << " OF " 
         << particlelist.size() << endl;
  
    string testparticle=particlelist[i];
  
    string decayTable =directory + testparticle + "_decays.table";

    if((twobodywidths[i] == 0.) || (twobodywidths[i] != 0. && calc3if2)) {
      cout << "Now computing the three-body widths: \n";
      decayManager[i].computeThreeBodyWidths(twobodywidths[i]);
    } else {
      cout << "No three-body modes to calculate for this particle, moving on to output.\n";
    }
    cout << "Writing decay table.\n";
    decayManager[i].writeBRTable();
    decayManager[i].writeSLHAtable(slhaout);
    cout << "Listing final branching ratios:\n";
    for(int j = 0; j < decayManager[i].allModes.size(); j++) {
      cout << "Mode #" << j << ": " << testparticle << " ->";
      for(int k = 0; k < decayManager[i].allModes[j].dm->NumberDaughters(); k++) 
        cout << " " << decayManager[i].allModes[j].dm->ListDaughters()[k];
      cout << " BR: " << decayManager[i].allModes[j].branchingRatio << "\n";
    }
    cout << "Finished particle.\n";
    //end of overall for loop
  }
  slhaout.close();
  
  if(batch)
  {
	  yesno=pargs[6+nparticles];
  }
  else
  {
  cout << "Do you wish to replace the values of the param_card.dat widths, with the values stored in slha.out?(Y/N) ";
  cin >> yesno;
  }
  if(yesno == "Y" || yesno == "y") 
    {
    updateparamcard(slhadecfile,paramcard,path,batch);
    }
  
  return 0;
}



int main(int argc, char *argv[]){
  vector<string> pargs;
  if(argc>1)
  {
	 if(runbribatch(argc,argv,pargs)==0)
		return 0;
  }

  if(argc==1)
  {
	cout << "Would you like to run from a MadGraph Model directory? (Y/N) ";
	string yesno1;
	getline(cin,yesno1);
	if(yesno1 == "Y" || yesno1 == "y") {
		return mainMG(pargs);
	}
	return mainOrig(pargs);
  }
  else
  {
	  if(pargs[0] == "Y" || pargs[0] == "y") 
	  {
		return mainMG(pargs);
	  }
	return mainOrig(pargs);
  }
	  
}
