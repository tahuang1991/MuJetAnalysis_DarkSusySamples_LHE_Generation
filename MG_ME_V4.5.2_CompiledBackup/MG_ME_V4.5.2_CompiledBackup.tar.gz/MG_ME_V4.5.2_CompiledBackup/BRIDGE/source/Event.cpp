#include "Event.h"
using namespace std;

Event::Event(): npart(0),idp(0),xwgt(0.0),scal(0.0),aqed(0.0),aqcd(0.0) {}
Event::Event(int theNP,int theIDR, double theWeight, double theScale, double theAQED, double theAQCD,std::vector<EventParticle> theParticles)
{
npart=theNP;
idp=theIDR;
xwgt=theWeight;
scal=theScale;
aqed=theAQED;
aqcd=theAQCD;
particles=theParticles;
}
Event::Event(ifstream& in,std::string evt_flag)
{
read_event(in,evt_flag);
}


ifstream& Event::read_event(ifstream& in,std::string evt_flag)
{
  int dum,i;
  if(evt_flag=="MG")
  {
    in >> npart >> idp >> xwgt >> scal >> aqed >> aqcd;
    vector<EventParticle> theparticles;
    EventParticle theparticle;
    for(i=1;i<=npart;i++)
      theparticles.push_back(theparticle);
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setid(dum);
    }
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setmoth1(dum);
    } 
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setmoth2(dum);
    } 
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setcolor1(dum);
    } 
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setcolor2(dum);
    } 
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setstatus(dum);
    } 
    for(i=0;i<npart;i++)
    {
      in >> theparticles[i].Helicity;
    } 
    for(i=0;i<npart;i++)
    {
      in >> dum >> theparticles[i].P[0] >> theparticles[i].P[1]
	 >> theparticles[i].P[2] >> theparticles[i].P[3];
    }
    particles=theparticles;
    return in;
  }
  else
  {
    //we are in a les houches event;
    string dum1;
    double dumd;
    in >> dum1;
    if(dum1!="<event>")
    {
      //throw an error eventually, here we just have the potential for 
      //an infinite loop from bridge but youll see whats going on
      cout << "No event found! " << dum1 << endl;
      return in;
    }
    in >> npart >> idp >> xwgt >> scal >> aqed >> aqcd;
    vector<EventParticle> theparticles;
    EventParticle theparticle;
    for(i=1;i<=npart;i++)
      theparticles.push_back(theparticle);
    for(i=0;i<npart;i++)
    {
      in >> dum;
      theparticles[i].setid(dum);
      in >> dum;
      theparticles[i].setstatus(dum);
      in >> dum;
      theparticles[i].setmoth1(dum);
      in >> dum;
      theparticles[i].setmoth2(dum);
      in >> dum;
      theparticles[i].setcolor1(dum);
      in >> dum;
      theparticles[i].setcolor2(dum);
      in >> theparticles[i].P[1] >> theparticles[i].P[2] 
	 >> theparticles[i].P[3] >> theparticles[i].P[0] >> dumd;
      theparticles[i].setP5(dumd);
      in >> dumd;
      theparticles[i].setvtimup(dumd);
      in >> dumd;
      theparticles[i].Helicity=int(dumd);
    }
    // now get </event>
    while (dum1 != "</event>") {
	in >> dum1;
    }
//    in >> dum1; /* in >> dum1; in >> dum1; in >> dum1; in >> dum1; */
    particles=theparticles;
    return in;
  }
}

ofstream& Event::write_event(ofstream& out,std::string evt_flag)
{
  int i;
  if(evt_flag=="MG")
  {
    std::_Ios_Fmtflags originalFlags=out.flags();
    int originalPrecision=out.precision();
    out << right << std::setw(8) << npart << std::setw(8) << idp <<  "  ";
    out.setf(ios::scientific,ios::floatfield);
    out.setf(ios::uppercase);
    out.precision(7);
    out << xwgt << "  " << scal << "  " << aqed << "  " << aqcd << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].idup();
    }
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].mothup1();
    } 
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].mothup2();
    } 
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].icolup1();
    } 
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].icolup2();
    } 
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].istup();
    } 
    out << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].Helicity;
    } 
    out << endl;
    out.setf(ios::scientific,ios::floatfield);
    out.setf(ios::uppercase);
    out.precision(10);
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(3) << i+1 << "  " << right << std::setw(17) 
	  << particles[i].P[0] << "  " << std::setw(17) << particles[i].P[1] 
	  << "  " << std::setw(17) << particles[i].P[2] << "  " 
	  << std::setw(17) << particles[i].P[3] << endl;
    }
    out.flags(originalFlags);
    out.precision(originalPrecision);
    return out;
  }
  else
  {
    std::_Ios_Fmtflags originalFlags=out.flags();
    int originalPrecision=out.precision();
    out << "<event>" << endl;
    out << right << std::setw(3) << npart << std::setw(4) << idp <<  "  ";
    out.setf(ios::scientific,ios::floatfield);
    out.setf(ios::uppercase);
    out.precision(7);
    out << xwgt << "  " << scal << "  " << aqed << "  " << aqcd << endl;
    for(i=0;i<npart;i++)
    {
      out << right << std::setw(5) << particles[i].idup() 
	  << std::setw(5)<<particles[i].istup() 
	  << std::setw(5)<< particles[i].mothup1() << std::setw(5)  
	  << particles[i].mothup2() << std::setw(5) << particles[i].icolup1() 
	  << std::setw(5) << particles[i].icolup2() << "  ";
      out.setf(ios::scientific,ios::floatfield);
      out.setf(ios::uppercase);
      out.precision(10);
      out << right << std::setw(17) << particles[i].P[1] << "  " 
	  << std::setw(17) << particles[i].P[2] << "  " << std::setw(17) 
	  << particles[i].P[3] << "  " << std::setw(17) << particles[i].P[0] 
	  << "  " << std::setw(17) << particles[i].p5() << "  ";
      out.precision(4);
      out.setf(ios::floatfield);
      out << right  << std::setw(8) << showpoint <<particles[i].vtimup() 
	  << "  ";
      out.precision(1);
      out << std::setw(3) << showpoint << float(particles[i].Helicity) 
	  << endl;
    }
    out << "</event>" << endl;
    out.flags(originalFlags);
    out.precision(originalPrecision);
    return out;
  }    
}

int Event::nup()
{
  return npart;
}

int Event::idprup()
{
  return idp;
}

double Event::xwgtup()
{
  return xwgt;
}

double Event::scalup()
{
  return xwgt;
}

double Event::aqedup()
{
  return aqed;
}

double Event::aqcdup()
{
  return aqcd;
}

void Event::setnup(int theNpart)
{
  npart=theNpart;
}

void Event::setidprup(int theIDR)
{
  idp=theIDR;
}

void Event::setxwgtup(double theXwgt)
{
  xwgt=theXwgt;
}

void Event::setscalup(double theScal)
{
  scal=theScal;
}

void Event::setaqedup(double theAqed)
{
  aqed=theAqed;
}

void Event::setaqcdup(double theAqcd)
{
  aqcd=theAqcd;
}

void Event::add_particles(std::vector<EventParticle> theParticles)
{
  particles=theParticles;
}

void Event::add_particle(EventParticle theParticle)
{
  particles.push_back(theParticle);
}

std::vector<EventParticle> Event::get_particles()
{
  return particles;
}

EventParticle Event::get_particle(int i)
{
  return particles[i-1];
}

std::vector<int> Event::Find_Particle(std::string theName)
{
  vector<int> particlelocations;
  Particle dumb;
  int idnumber=dumb.pl[theName].IDCode();
  for(int i=0; i!=particles.size(); i++)
  {
    if(idnumber==particles[i].idup())
    {
      particlelocations.push_back(i);
    }
  }
  return particlelocations;
}

int Event::max_color()
{
  int test=0;
  for(int i=0; i!=particles.size(); i++)
  {
    test=max(test,particles[i].icolup1());
    test=max(test,particles[i].icolup2());
  }
  return test;
}
