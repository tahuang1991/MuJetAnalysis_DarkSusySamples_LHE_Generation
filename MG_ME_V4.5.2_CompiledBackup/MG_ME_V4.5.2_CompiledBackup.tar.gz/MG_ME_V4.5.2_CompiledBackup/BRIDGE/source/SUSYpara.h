#ifndef SUSYpara_h
#define SUSYpara_h

#include "SLHArw.h"
#include "Values.h"
#include <complex>
using namespace std;

void SUSYpara(SLHA slha);

#endif
