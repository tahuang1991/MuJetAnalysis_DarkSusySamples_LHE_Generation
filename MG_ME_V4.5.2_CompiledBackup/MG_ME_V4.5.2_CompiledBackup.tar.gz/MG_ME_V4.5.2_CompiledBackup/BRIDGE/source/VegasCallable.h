#ifndef VEGAS_CALLABLE
#define VEGAS_CALLABLE

#include <vector>

// Another reason C++ should have Java-style interfaces....
// Something for Vegas to integrate
class VegasCallable {
 public:
  virtual ~VegasCallable() {}
  virtual double VegasInput(std::vector<double>, double) = 0;
};

#endif
