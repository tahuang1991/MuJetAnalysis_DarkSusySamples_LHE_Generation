#ifndef DECAY_BUILDER_H
#define DECAY_BUILDER_H

#include "DecayMode.h"

class DecayBuilder {
public:
  static std::vector<DecayMode *> GetTwoBodyDecayModes(std::string p);
  static std::vector<DecayMode *> GetDecayModes(std::string p);
};

#endif
