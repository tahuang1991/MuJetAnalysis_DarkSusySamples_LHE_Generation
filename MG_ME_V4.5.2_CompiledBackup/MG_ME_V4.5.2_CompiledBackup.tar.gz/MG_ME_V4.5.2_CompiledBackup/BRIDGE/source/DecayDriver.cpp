#include "DecayDriver.h"
#include "HelasUtil.h"
#include "DecayUtil.h"
#include <vector>
#include <cstdlib>
#include <cassert>
#include <iostream>
using namespace std;

int VCWithRandom::GetRandomHelicity(std::string particle) {
  int N = Particle::pl[particle].NHelicities();
  double random = (*getRandom)(); // between 0 and 1
  if(N == 2) {
    if(random < 0.5) return -1;
    return 1;
  }
  if(N == 3) {
    if(random < 1./3) return -1;
    if(random < 2./3) return 0;
    return 1;
  }
  return 0;
}

void TwoBodyDecayDriver::SetMotherMomentum(FourVector PIn) {
  P[0] = PIn;
}

FourVector TwoBodyDecayDriver::MotherMomentum() {
  return P[0];
}

FourVector TwoBodyDecayDriver::Daughter1Momentum() {
  return P[1];
}

FourVector TwoBodyDecayDriver::Daughter2Momentum() {
  return P[2];
}

// MEMBERS OF CLASS TWOBODYDECAYDRIVER:
// FOUR-MOMENTA P[0..2]
// VECTOR OF RANDOM NUMBERS, randIn, SUPPLIED BY VEGAS
// IN RANGE [0,1]
// randIn[0] = (cos(theta)+1)/2
// randIn[1] = phi/(2 pi)

// This is the function that Vegas gets as a callback.
double TwoBodyDecayDriver::VegasInput(vector<double> x, double weight)
{
  return RunEvent(x, weight, true);
}

double TwoBodyDecayDriver::RunEvent(vector<double> x, double weight, 
                      bool vegasCalling)
{
  //  cout << "VegasInput called with: x[0] = " << x[0]
  //     << ", x[1] = " << x[1] << ", weight = " << weight << endl;

  // initialize P[0] here
  bool boosted=false;
  if(vegasCalling) {
    //    cout << "x[0], x[1] = " << x[0] << ", " << x[1] << "\n";
    double theMass = fabs(Particle::pl[dm->Parent()].Mass());
    P[0].P[1] = P[0].P[2] = P[0].P[3] = 0.0;
    P[0].P[3] = 0.00000000000001;
    P[0].E()=sqrt(theMass*theMass+P[0].P[1]*P[0].P[1]+
          P[0].P[2]*P[0].P[2]+P[0].P[3]*P[0].P[3]);
    P[0].Helicity = GetRandomHelicity(dm->Parent());
  }
  // otherwise use the P[0] the user has set
  else {
    if(P[0].P[1] == P[0].P[2] == P[0].P[3] == 0.0) {
	FourVector Pdum;
	Pdum.P[0]=1;
	Pdum.P[1]=0;
	Pdum.P[2]=0;
	Pdum.P[3]=0.0000000000001; 
	boostx_(P[0].P,Pdum.P,P[0].P);
	boosted = true;
    }
  }

  // Save the random numbers, which the rest of the code
  // will use....
  if(x[0] < 0. || x[0] > 1. || x[0] != x[0]) {
    // throw an error
    cout << "Invalid x[0] = " << x[0] << "\n";
    exit(1);
    assert(false);
    return 0.;
  } else if(x[1] < 0. || x[1] > 1. || x[1] != x[1]) {
    // throw an error
    cout << "Invalid x[1] = " << x[1] << "\n";
    exit(1);
    assert(false);
    return 0.;
  }
  for(int i = 0; i < x.size(); i++) {
    randIn[i] = x[i];
  }

  // pass color labels, particle IDs??
  // (put color label in the FourVector?)
  // the return value is phaseSpaceWeight * |M|^2 * factor
  double evtweight = DecayEvent();
  if(boosted) {
      FourVector Pdum;
      Pdum.P[0]=1;
      Pdum.P[1]=0;
      Pdum.P[2]=0;
      Pdum.P[3]=-0.0000000000001; 
      boostx_(P[0].P,Pdum.P,P[0].P);
      boostx_(P[1].P,Pdum.P,P[1].P);
      boostx_(P[2].P,Pdum.P,P[2].P);
  }
  return evtweight; 
}

// mimic the routine TWOMOM in decay_mom.f
// sets up momenta of decay products using random numbers supplied by Vegas
// returns the weight (i.e. the phase space part of differential cross section)
double TwoBodyDecayDriver::PhaseSpace() {
  double rootS = P[0].M();  
  double S = rootS*rootS;

  // Choose helicities at random
  P[1].Helicity = GetRandomHelicity(dm->ListDaughters()[0]);
  P[2].Helicity = GetRandomHelicity(dm->ListDaughters()[1]);

  double cosTheta = -1. + 2.*randIn[0];
  double phi = 2.*M_PI*randIn[1];

  double jac = 4.*M_PI;

  double m1 = fabs(Particle::pl[dm->ListDaughters()[0]].Mass());
  double m2 = fabs(Particle::pl[dm->ListDaughters()[1]].Mass());

  // Call a HELAS routine for this...
  // Calculate decay product four-vectors in their CM frame,
  // then boost each one to the lab frame.
  mom2cx_(rootS,m1,m2,cosTheta,phi,P[1].P,P[2].P);
  boostx_(P[1].P,P[0].P,P[1].P);
  boostx_(P[2].P,P[0].P,P[2].P);

  jac = jac/(2.0*M_PI)/(2.0*M_PI);

  // Calculate the factor d(sigma)/dcos(theta)
  double psWeight = 1.0/(2.0*rootS); // flux factor
  psWeight *= 0.5*M_PI*sqrt(LambdaMG(1.,m1*m1/S,m2*m2/S))/(4.*M_PI);
  psWeight *= jac;
  return psWeight;
}

double TwoBodyDecayDriver::DecayEvent() {
  // Choose daughter momenta at random, and get phase space weight:
  double psWeight = PhaseSpace();
  complex<double> theAmp = dm->Amplitude(P);
  double theAmpSq = (theAmp * conj(theAmp)).real();
  double theWeight = psWeight * theAmpSq;
  // Multiply by color, statistics factors.
  theWeight *= dm->ColorFactor();
  theWeight *= Particle::pl[dm->ListDaughters()[0]].NHelicities();
  theWeight *= Particle::pl[dm->ListDaughters()[1]].NHelicities();
  // Bose factor (e.g. h -> z z, but *not* h -> g g, so check NColors ())
   if(dm->ListDaughters()[0] == dm->ListDaughters()[1] &&
      Particle::pl[dm->ListDaughters()[0]].NColors() == 1) 
   {
     if(Particle::pl[dm->ListDaughters()[0]].TwiceSpin() == 0
        || Particle::pl[dm->ListDaughters()[0]].TwiceSpin() == 2) {
       theWeight /= 2;
     }
   }


  return theWeight; // figure out return type
}

/////////////////////////////////////////////////////////////////////
// THREE BODY DECAYS
//

double ThreeBodyDecayDriver::VegasInput(vector<double> x, double weight)
{
  return RunEvent(x, weight, true);
}

double ThreeBodyDecayDriver::RunEvent(vector<double> x, double weight, 
                      bool vegasCalling)
{
  assert(x.size() == 5.);

//cout << "Parent mass = " << Particle::pl[dm->Parent()].Mass() << "\n";
//cout << "x[0] = " << x[0] << "\n";

  // initialize P[0] here
  // initialize P[0] here
  bool boosted=false;
  if(vegasCalling) {
    //    cout << "x[0], x[1] = " << x[0] << ", " << x[1] << "\n";
    double theMass = fabs(Particle::pl[dm->Parent()].Mass());
    P[0].P[1] = P[0].P[2] = P[0].P[3] = 0.0;
    P[0].P[3] = 0.00000000000001;
    P[0].E()=sqrt(theMass*theMass+P[0].P[1]*P[0].P[1]+
          P[0].P[2]*P[0].P[2]+P[0].P[3]*P[0].P[3]);
    P[0].Helicity = GetRandomHelicity(dm->Parent());
  }
  // otherwise use the P[0] the user has set
  else {
    if(P[0].P[1] == P[0].P[2] == P[0].P[3] == 0.0) {
	FourVector Pdum;
	Pdum.P[0]=1;
	Pdum.P[1]=0;
	Pdum.P[2]=0;
	Pdum.P[3]=0.0000000000001; 
	boostx_(P[0].P,Pdum.P,P[0].P);
	boosted = true;
    }
  }

  // Save the random numbers, which the rest of the code
  // will use....
  for(int i = 0; i < x.size(); i++) {
    if(x[i] < 0. || x[i] > 1. || x[i] != x[i]) {
      // throw an error
      cout << "Invalid x[" << i << "] = " << x[i] << "!\n";
      exit(1);
      return 0.;
    }
    randIn[i] = x[i];
  }

  // pass color labels, particle IDs??
  // (put color label in the FourVector?)
  // the return value is phaseSpaceWeight * |M|^2 * factor
  double evtweight = DecayEvent(!vegasCalling);
  if(boosted) {
      FourVector Pdum;
      Pdum.P[0]=1;
      Pdum.P[1]=0;
      Pdum.P[2]=0;
      Pdum.P[3]=-0.0000000000001; 
      boostx_(P[0].P,Pdum.P,P[0].P);
      boostx_(P[1].P,Pdum.P,P[1].P);
      boostx_(P[2].P,Pdum.P,P[2].P);
      boostx_(P[3].P,Pdum.P,P[3].P);
  }

  return evtweight; 
}

// mimic the routine THREEMOM in decay_mom.f
// sets up momenta of decay products using random numbers supplied by Vegas
// returns the weight (i.e. the phase space part of differential cross section)
double ThreeBodyDecayDriver::PhaseSpace(bool debug) {
  double rootS = fabs(P[0].M());  
  double S = rootS*rootS;

  // Choose helicities at random
  P[1].Helicity = GetRandomHelicity(dm->ListDaughters()[0]);
  P[2].Helicity = GetRandomHelicity(dm->ListDaughters()[1]);
  P[3].Helicity = GetRandomHelicity(dm->ListDaughters()[2]);

  // Get masses
  double m1 = fabs(Particle::pl[dm->ListDaughters()[0]].Mass());
  double m2 = fabs(Particle::pl[dm->ListDaughters()[1]].Mass());
  double m3 = fabs(Particle::pl[dm->ListDaughters()[2]].Mass());

  // NEW CODE: use Dalitz variables
  // construct momenta in CM frame
//  cout << "Masses: " << rootS << ", " << m1 << ", " << m2 << ", " << m3 << "\n";
  double E1max = (rootS*rootS + m1*m1 - m2*m2 - 2*m2*m3 - m3*m3)/(2*rootS);
//  cout << "E1max: " << E1max << "\n";
  double E1 = m1 + randIn[0]*(E1max - m1); 
  double E1jac = E1max - m1;
  if(E1jac < 0) {
      cout << "Weird sign: (E1max, m1) = " << E1max << ", " << m1 << "\n";
  }
//  cout << "E1 = " << E1 << "\n";
//  cout << "blah1 = " << ((m3-m2)*(m3-m2)-m1*m1+2*E1*rootS-rootS*rootS) << "\n";
//  cout << "blah2 = " << ((m3+m2)*(m3+m2)-m1*m1+2*E1*rootS-rootS*rootS) << "\n";
  double E2min = ((E1-rootS)*(m3*m3-m2*m2-m1*m1+2*E1*rootS-rootS*rootS) - 
		  sqrt((E1-m1)*(E1+m1)*((m3-m2)*(m3-m2)-m1*m1+2*E1*rootS-rootS*rootS)*
                       ((m3+m2)*(m3+m2)-m1*m1+2*E1*rootS-rootS*rootS)))
                   / (2*(m1*m1 + rootS*(-2*E1 + rootS)));
  double E3min = ((E1-rootS)*(m2*m2-m3*m3-m1*m1+2*E1*rootS-rootS*rootS) - 
		  sqrt((E1-m1)*(E1+m1)*((m2-m3)*(m2-m3)-m1*m1+2*E1*rootS-rootS*rootS)*
                       ((m3+m2)*(m3+m2)-m1*m1+2*E1*rootS-rootS*rootS)))
                   / (2*(m1*m1 + rootS*(-2*E1 + rootS)));
  double E2max = rootS - m1 - m3;
//  cout << "E2min = " << E2min << "\n";
//  cout << "E3min = " << E3min << "\n";
//  cout << "E2max = " << E2max << "\n";
  if(E3min > rootS - E1 - E2max) {
      E2max = rootS - E1 - E3min;
//      cout << "Revised E2max = " << E2max << "\n";
  }
//  if(E2min > E2max) return 0.;
  double E2 = E2min + randIn[1]*(E2max-E2min);
  double E2jac = E2max - E2min;
  if(E2jac < 0) {
      cout << "Weird sign: (E2max, E2min) = " << E2max << ", " << E2min << "\n";
  }
//  cout << "E1, E2 = " << E1 << ", " << E2 << "\n";
  double E3 = rootS - E1 - E2;
  double cosTheta = -1. + 2.*randIn[2];
  double sinTheta = sqrt(1 - cosTheta*cosTheta);
  double phi = 2.*M_PI*randIn[3];
  double psi = 2.*M_PI*randIn[4];
  double angjac = 8.*M_PI*M_PI;
  double P1 = sqrt(E1 * E1 - m1 * m1);
  double P2 = sqrt(E2 * E2 - m2 * m2);
  double P3 = sqrt(E3 * E3 - m3 * m3);
//  cout << "P1, P2, P3 = " << P1 << ", " << P2 << ", " << P3 << "\n";
  P[1].P[0] = E1;
  double stcp = sinTheta * cos(phi);
  double stsp = sinTheta * sin(phi);
  double ct = cosTheta;
  P[1].P[1] = stcp * P1;
  P[1].P[2] = stsp * P1;
  P[1].P[3] = ct * P1;
  double vtemp[4], vrot[4];
  vtemp[0] = 1;
  vtemp[1] = cos(psi);
  vtemp[2] = sin(psi);
  vtemp[3] = 0;
  rotxxx_(vtemp, P[1].P, vrot);
  double B = (P3*P3-P2*P2-P1*P1)/(2*P1);
//  cout << "vrot = " << vrot[1] << ", " << vrot[2] << ", " << vrot[3] << "\n";
//  cout << "p1h = " << stcp << ", " << stsp << ", " << ct << "\n";
//  cout << "B = " << B << "\n";
  double A;
  if(P2 * P2 - B * B > 0.0) {
    A = sqrt(P2 * P2 - B * B);
  } else {
    A = 0.0;
  }
//  cout << "A = " << A << "\n";
  P[2].P[0] = E2;
  P[2].P[1] = A*vrot[1] + B*stcp;
  P[2].P[2] = A*vrot[2] + B*stsp;
  P[2].P[3] = A*vrot[3] + B*ct;
  P[3].P[0] = E3;
  double C = - B - P1;
  P[3].P[1] = -A*vrot[1] + C*stcp;
  P[3].P[2] = -A*vrot[2] + C*stsp;
  P[3].P[3] = -A*vrot[3] + C*ct;
  for(int i = 0; i < 4; i++) {
//      cout << "Four-vector: (" << P[i].P[0] << ", " << P[i].P[1] << ", " << P[i].P[2] << ", " << P[i].P[3] << "), m = " << P[i].M() << "\n";
  }
//  exit(0);
  // boost to lab frame
  boostx_(P[1].P,P[0].P,P[1].P);
  boostx_(P[2].P,P[0].P,P[2].P);
  boostx_(P[3].P,P[0].P,P[3].P);
  for(int i = 0; i < 4; i++) {
      for(int j = 0; j < 4; j++) {
	  if(P[i].P[j] != P[i].P[j]) {
	      cout << "Assertion failed! vrot[0], stcp, stsp, ct = " << 
		  vrot[0] << ", " << stcp << ", " << stsp << ", " << ct << "\n";
              cout << "Masses: " << rootS << ", " << m1 << ", " << m2 << ", " << m3 << "\n";
              cout << "E1 = " << E1 << "\n";
              cout << "E1max = " << E1max << "\n";
              cout << "blah1 = " << ((m3-m2)*(m3-m2)-m1*m1+2*E1*rootS-rootS*rootS) << "\n";
              cout << "blah2 = " << ((m3+m2)*(m3+m2)-m1*m1+2*E1*rootS-rootS*rootS) << "\n";
	      cout << "P[" << i << "] = " << P[i].P[0] << ", " << P[i].P[1]
		   << ", " << P[i].P[2] << ", " << P[i].P[3] << "\n";
	      cout << "E1,E2,E3 = " << E1 << ", " << E2 << ", " << E3 << "\n";
	      cout << "x = " << randIn[0] << ", " << randIn[1] 
		   << ", " << randIn[2] <<
		  ", " << randIn[3] << ", " << randIn[4] << "\n";
	  }
	  assert(P[i].P[j] == P[i].P[j]);
      }
  }
  double piToTheFifth = 306.01968478528141;
  double psWeight = E1jac*E2jac*angjac/(rootS*512*piToTheFifth);
  return psWeight;
}

double ThreeBodyDecayDriver::DecayEvent(bool debug) {
  // Choose daughter momenta at random, and get phase space weight:
  double psWeight = PhaseSpace(debug);
  double Ediff = fabs(P[0].P[0] - P[1].P[0] - P[2].P[0] - P[3].P[0]);
/*
  if(Ediff > 1.e-4) {
      cout << "Momentum conservation problem #0, psWeight = " << psWeight << "\n";
      for(int k = 0; k < 4; k++) {
	  cout << "P[" << k << "] = " << P[k].P[0] << ", " << P[k].P[1] << ", " << P[k].P[2] << ", " << P[k].P[3] << "\n";
      }
      }*/
//  if(debug) {
//cout << "phase space weight = " << psWeight << "\n";
//  }

  // Multiply by |M|^2 * color factor:
  double factors = dm->AmpSquareColor(P);
  if(factors < 0) {
      cout << "Weird sign: AmpSquareColor = " << factors << "\n";
  }
  assert(factors == factors);
//  if(debug) {
//cout << "|M|^2 * color = " << factors << "\n";
//  }
  double theWeight = psWeight * factors;

  // Multiply by statistics factors.
  theWeight *= Particle::pl[dm->ListDaughters()[0]].NHelicities();
  theWeight *= Particle::pl[dm->ListDaughters()[1]].NHelicities();
  theWeight *= Particle::pl[dm->ListDaughters()[2]].NHelicities();

  if(theWeight < 0) cout << "theWeight = " << theWeight << "\n";

  return theWeight; // figure out return type
}

void ThreeBodyDecayDriver::SetMotherMomentum(FourVector PIn) {
  P[0] = PIn;
}

FourVector ThreeBodyDecayDriver::MotherMomentum() {
  return P[0];
}

FourVector ThreeBodyDecayDriver::Daughter1Momentum() {
  return P[1];
}

FourVector ThreeBodyDecayDriver::Daughter2Momentum() {
  return P[2];
}

FourVector ThreeBodyDecayDriver::Daughter3Momentum() {
  return P[3];
}
