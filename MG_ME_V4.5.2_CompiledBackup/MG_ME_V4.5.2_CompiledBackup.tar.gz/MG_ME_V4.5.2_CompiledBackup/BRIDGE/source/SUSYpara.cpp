#include "SUSYpara.h"
#include "SLHArw.h"
#include "Values.h"
#include <complex>
using namespace std;

// Set up all the SUSY couplings. Based on MadGraph's couplings.f
void SUSYpara(SLHA slha) {
  double tgb = slha.tanb;
  double cb = 1.0/sqrt(1+tgb*tgb);
  double sb = tgb*cb;
  double ca=cos(slha.alpha);
  double sa=sin(slha.alpha);
  double cbma=cb*ca+sb*sa;
  double sbma=sb*ca-cb*sa;
  double cbpa=ca*cb-sa*sb;
  double sbpa=sa*cb+ca*sb;
  double caa=2.0*ca*ca-1.0;
  double saa=2.0*sa*ca;
  double cbb=2.0*cb*cb-1.0;
  double sbb=2.0*sb*cb;
  double mu=slha.mu;
  complex<double> i_unit(0.0,1.0);
  complex<double> cd1=-sa;
  complex<double> cd2=ca;
  complex<double> cd3=sb*i_unit;
  complex<double> cu1=ca;
  complex<double> cu2=sa;
  complex<double> cu3=cb*i_unit;
  complex<double> cucc1=cu1;
  complex<double> cdcc1=cd1;
  complex<double> cucc2=cu2;
  complex<double> cdcc2=cd2;
  complex<double> cucc3=-cu3;
  complex<double> cdcc3=-cd3;
  double a_tau = slha.ae[2];
  double a_top = slha.au[2];
  double a_bot = slha.ad[2];

  // SM params
  // need to make this more consistent in terms of renormalization scale
  // also possibly include optional running
  //depending on mgsmpar
  double wmass;
  if(slha.mw!=0.0)
    wmass = slha.mw;
  else
    wmass = 79.82;
  double hmass = slha.mass[25];
  double alphas = slha.alphas;
  //depending on mgsmpar
  double sin2w;
  if(slha.s2w!=0.0)
    sin2w = slha.s2w;
  else
    sin2w = .2336;
  double sw = sqrt(sin2w);
  double cw = sqrt(1-sin2w);
  double tw = sw/cw;
  double alpha=1/slha.alphaem;
  double ee = sqrt(4*3.1416*alpha);
  double ez = ee/(sw*cw);
  double ey = ee*(sw/cw);
  double sc2=sin2w*(1-sin2w);
  double v = slha.vev;
  double lambda = hmass*hmass/(2*v*v);
  double gs;
  if(slha.g3!=0.0)
    gs=slha.g3;
  else
    gs = sqrt(4.*3.1416*alphas);
  double rt2 = sqrt(2.);
  double gx;
  if(slha.g2!=0.0)
    gx =slha.g2;
  else
    gx = ee/sw;
  double t3e = -0.5;
  double t3v = 0.5;
  double qe = -1.0;  
  double qu = 2./3.;
  double t3u = 0.5;
  double qd = -1/3.;
  double t3d = -0.5;
  double mwx = wmass;
  double mzx = slha.mz;
  double s2w = sw*sw;
  double c2w = cw*cw;
  double e=ee;
  double rmt = v*sb*slha.yu[2]/rt2;
  double rmb = v*cb*slha.yd[2]/rt2;
  double rml = v*cb*slha.ye[2]/rt2;
  if(rmt == 0.0) rmt = slha.mt;
  if(rmb == 0.0) rmb = slha.mb;
  if(rml == 0.0) rml = slha.mtau;
  double sw2 = sin2w;
  double gz;
  if(slha.g1!=0.0)
    gz = sqrt(slha.g1*slha.g1+gx*gx);
  else
    gz = gx/cw;
  
  double gw = gx;

  // Set up standard SM 
  Values::v["ZERO"] = 0.0;
  Values::v["BMASS"] = slha.mb;
  Values::v["LMASS"] = slha.mtau;
  Values::v["TMASS"] = slha.mt;
  Values::v["ZMASS"] = slha.mz;
  Values::v["WMASS"] = wmass;
  Values::v["MH1"] = hmass;
  Values::v["G"] = gs;
  Values::v["GG"] = -Values::v["G"];
  Values::v2["GG"] = Values::v["GG"];
  Values::v["GW"] = ee/sw;
  Values::v["GWWA"] = ee;
  Values::v["GWWZ"] = ee*cw/sw;
  Values::v["GWWH"] = ee*ee*0.5*v/sin2w;
  Values::v["GZZH"] = ee*ee/sc2*0.5*v;
  Values::v["GHHH"] = -hmass*hmass/v*3.0;
  Values::v["GWWHH"] = ee*ee/sin2w*0.5;
  Values::v["GZZHH"] = ee*ee/sc2*0.5;
  Values::v["GHHHH"] = Values::v["GHHH"]/v;
  Values::v["GAL"] = ee;
  Values::v2["GAL"] = ee;
  Values::v["GAU"]=-ee*2.0/3.0;
  Values::v2["GAU"]=-ee*2.0/3.0;
  Values::v["GAD"]=ee/3.0;
  Values::v2["GAD"]=ee/3.0;
  Values::v["GWF"]=-ee/sqrt(2*sin2w);
  Values::v2["GWF"]=0.0;
  Values::v["GZN"]=-ez*0.5;
  Values::v2["GZN"]=0.0;
  Values::v["GZL"]=-ez*(-0.5+sin2w);
  Values::v2["GZL"]=-ey;
  Values::v2["GZU"]=-ez*(0.5-sin2w*2.0/3.0);
  Values::v["GZD"]=-ez*(-0.5+sin2w/3.0);
  Values::v2["GZD"]=-ey/3.0;
  Values::v["GHTOP"]=-Values::v["TMASS"]/v;
  Values::v2["GHTOP"]=Values::v["GHTOP"];
  Values::v["GHBOT"]=-Values::v["BMASS"]/v;
  Values::v2["GHBOT"]=Values::v["GHBOT"];
  Values::v["GHTAU"]=Values::v["LMASS"]/v;
  Values::v2["GHTAU"]=Values::v["GHTAU"];

  // Masses of SUSY particles
  Values::v["MGO"] = slha.mass[1000021];
  Values::v["MN1"] = slha.mass[1000022];
  Values::v["MN2"] = slha.mass[1000023];
  Values::v["MN3"] = slha.mass[1000025];
  Values::v["MN4"] = slha.mass[1000035];
  Values::v["MX1"] = slha.mass[1000024];
  Values::v["MX2"] = slha.mass[1000037];
  Values::v["MDL"] = slha.mass[1000001];
  Values::v["MDR"] = slha.mass[2000001];
  Values::v["MUL"] = slha.mass[1000002];
  Values::v["MUR"] = slha.mass[2000002];
  Values::v["MSL"] = slha.mass[1000003];
  Values::v["MSR"] = slha.mass[2000003];
  Values::v["MCL"] = slha.mass[1000004];
  Values::v["MCR"] = slha.mass[2000004];
  Values::v["MB1"] = slha.mass[1000005];
  Values::v["MB2"] = slha.mass[2000005];
  Values::v["MT1"] = slha.mass[1000006];
  Values::v["MT2"] = slha.mass[2000006];
  Values::v["MEL"] = slha.mass[1000011];
  Values::v["MER"] = slha.mass[2000011];
  Values::v["MML"] = slha.mass[1000013];
  Values::v["MMR"] = slha.mass[2000013];
  Values::v["ML1"] = slha.mass[1000015];
  Values::v["ML2"] = slha.mass[2000015];
  Values::v["MVE"] = slha.mass[1000012];
  Values::v["MVM"] = slha.mass[1000014];
  Values::v["MVT"] = slha.mass[1000016];

  // Masses of higgses
  Values::v["MH1"] = slha.mass[25];
  Values::v["MH2"] = slha.mass[35];
  Values::v["MH3"] = slha.mass[36];
  Values::v["MHC"] = slha.mass[37];

  // Mixing angles
  // NEUTRALINOS
  // "bw": neutralino mixing matrix in the bino-wino basis
  // basis: bino, wino, higgsino1, higgsino2
  complex<double> bw11 = slha.nmix[0][0], bw12 = slha.nmix[0][1], 
    bw13 = slha.nmix[0][2], bw14 = slha.nmix[0][3];
  complex<double> bw21 = slha.nmix[1][0], bw22 = slha.nmix[1][1], 
    bw23 = slha.nmix[1][2], bw24 = slha.nmix[1][3];
  complex<double> bw31 = slha.nmix[2][0], bw32 = slha.nmix[2][1], 
    bw33 = slha.nmix[2][2], bw34 = slha.nmix[2][3];
  complex<double> bw41 = slha.nmix[3][0], bw42 = slha.nmix[3][1], 
    bw43 = slha.nmix[3][2], bw44 = slha.nmix[3][3];

  // CHARGINOS
  complex<double> uu11 = slha.umix[0][0], uu12 = slha.umix[0][1];
  complex<double> uu21 = slha.umix[1][0], uu22 = slha.umix[1][1];
  complex<double> vv11 = slha.vmix[0][0], vv12 = slha.vmix[0][1];
  complex<double> vv21 = slha.vmix[1][0], vv22 = slha.vmix[1][1];

  // SFERMION MIXINGS
  // b~1 = rb11 b~l + rb12 b~r, etc.
  // sbottoms
  double rb11 = slha.sbotmix[0][0], rb12 = slha.sbotmix[0][1];
  double rb21 = slha.sbotmix[1][0], rb22 = slha.sbotmix[1][1];
  // stops
  double rt11 = slha.stopmix[0][0], rt12 = slha.stopmix[0][1];
  double rt21 = slha.stopmix[1][0], rt22 = slha.stopmix[1][1];
  // staus
  double rl11 = slha.staumix[0][0], rl12 = slha.staumix[0][1];
  double rl21 = slha.staumix[1][0], rl22 = slha.staumix[1][1];

  // Gluino couplings
  Values::v["GQLGOM"] = -rt2 * gs;
  Values::v2["GQLGOM"] = 0.;
  Values::v["GQRGOM"] = 0.;
  Values::v2["GQRGOM"] = rt2 * gs;
  Values::v["GQLGOP"] = Values::v2["GQLGOM"];
  Values::v2["GQLGOP"] = Values::v["GQLGOM"];
  Values::v["GQRGOP"] = Values::v2["GQRGOM"];
  Values::v2["GQRGOP"] = Values::v["GQRGOM"];
  Values::v["GB1GOM"] = rb11 * Values::v["GQLGOM"] + rb12 * Values::v["GQRGOM"];
  Values::v["GB2GOM"] = rb21 * Values::v["GQLGOM"] + rb22 * Values::v["GQRGOM"];
  Values::v2["GB1GOM"] = rb11 * Values::v2["GQLGOM"] 
    + rb12 * Values::v2["GQRGOM"];
  Values::v2["GB2GOM"] = rb21 * Values::v2["GQLGOM"] 
    + rb22 * Values::v2["GQRGOM"];
  Values::v["GB1GOP"] = Values::v2["GB1GOM"];
  Values::v2["GB1GOP"] = Values::v["GB1GOM"];
  Values::v["GB2GOP"] = Values::v2["GB2GOM"];
  Values::v2["GB2GOP"] = Values::v["GB2GOM"];
  Values::v["GT1GOM"] = rt11 * Values::v["GQLGOM"] + rt12 * Values::v["GQRGOM"];
  Values::v["GT2GOM"] = rt21 * Values::v["GQLGOM"] + rt22 * Values::v["GQRGOM"];
  Values::v2["GT1GOM"] = rt11 * Values::v2["GQLGOM"] 
    + rt12 * Values::v2["GQRGOM"];
  Values::v2["GT2GOM"] = rt21 * Values::v2["GQLGOM"] 
    + rt22 * Values::v2["GQRGOM"];
  Values::v["GT1GOP"] = Values::v2["GT1GOM"];
  Values::v2["GT1GOP"] = Values::v["GT1GOM"];
  Values::v["GT2GOP"] = Values::v2["GT2GOM"];
  Values::v2["GT2GOP"] = Values::v["GT2GOM"];

  // VSS Couplings -- non-Higgs
  Values::v["GAELEL"] = -ee * qe;
  Values::v["GAULUL"] = -ee * qu;
  Values::v["GADLDL"] = -ee * qd;
  Values::v["GZELEL"] = -gz * (t3e - qe * sw2);
  Values::v["GZERER"] = -gz * (-qe * sw2);
  Values::v["GZSVSV"] = -gz * t3v;
  Values::v["GZL1L1"] = rl11*rl11*Values::v["GZELEL"]
    +rl12*rl12*Values::v["GZERER"];
  Values::v["GZL2L2"] = rl21*rl21*Values::v["GZELEL"]
    +rl22*rl22*Values::v["GZERER"];
  Values::v["GZL1L2"] = rl21*rl11*Values::v["GZELEL"]
    +rl12*rl22*Values::v["GZERER"];
  Values::v["GZL2L1"] = Values::v["GZL1L2"];
  Values::v["GZDLDL"] = -gz*(t3d-qd*sw2);
  Values::v["GZDRDR"] = -gz*(-qd*sw2);
  Values::v["GZB1B1"] = rb11*rb11*Values::v["GZDLDL"]
    +rb12*rb12*Values::v["GZDRDR"];
  Values::v["GZB2B2"] = rb21*rb21*Values::v["GZDLDL"]
    +rb22*rb22*Values::v["GZDRDR"];
  Values::v["GZB1B2"] = rb21*rb11*Values::v["GZDLDL"]
    +rb12*rb22*Values::v["GZDRDR"];
  Values::v["GZB2B1"] = Values::v["GZB1B2"];
  Values::v["GZULUL"] = -gz*(t3u-qu*sw2);
  Values::v["GZURUR"] = -gz*(-qu*sw2);
  Values::v["GZT1T1"] = rt11*rt11*Values::v["GZULUL"]
    + rt12*rt12*Values::v["GZURUR"];
  Values::v["GZT2T2"] = rt21*rt21*Values::v["GZULUL"]
    + rt22*rt22*Values::v["GZURUR"];
  Values::v["GZT1T2"] = rt21*rt11*Values::v["GZULUL"]
    + rt12*rt22*Values::v["GZURUR"];
  Values::v["GZT2T1"] = Values::v["GZT1T2"];
  Values::v["GWELVE"] = -gx/rt2;
  Values::v["GWL1VT"] = rl11*Values::v["GWELVE"];
  Values::v["GWL2VT"] = rl21*Values::v["GWELVE"];
  Values::v["GWQLQL"] = -gx/rt2;
  Values::v["GWB1T1"] = rb11*rt11*Values::v["GWQLQL"];
  Values::v["GWB1T2"] = rb11*rt21*Values::v["GWQLQL"];
  Values::v["GWB2T1"] = rb21*rt11*Values::v["GWQLQL"];
  Values::v["GWB2T2"] = rb21*rt21*Values::v["GWQLQL"];
  Values::v["GWT1B1"] = Values::v["GWB1T1"];
  Values::v["GWT1B2"] = Values::v["GWB2T1"];
  Values::v["GWT2B1"] = Values::v["GWB1T2"];
  Values::v["GWT2B2"] = Values::v["GWB2T2"];

  // FFV couplings
  Values::v["GZX11"] = gz*(conj(uu11)*uu11+conj(uu12)*uu12/2. - sw2);
  Values::v2["GZX11"] = gz*(vv11*conj(vv11)+vv12*conj(vv12)/2. - sw2);
  Values::v["GZX12"] = gz*(conj(uu11)*uu21+conj(uu12)*uu22/2.);
  Values::v2["GZX12"] = gz*(vv11*conj(vv21)+vv12*conj(vv22)/2.);
  Values::v["GZX22"] = gz*(conj(uu21)*uu21+conj(uu22)*uu22/2. - sw2);
  Values::v2["GZX22"] = gz*(vv21*conj(vv21)+vv22*conj(vv22)/2. - sw2);
  Values::v["GAX"] = ee;
  Values::v2["GAX"] = ee;
  Values::v["GZN11"] = -gz*(conj(bw13)*bw13 - conj(bw14)*bw14)/2.;
  Values::v2["GZN11"] = -conj(Values::v["GZN11"]);
  Values::v["GZN12"] = -gz*(conj(bw13)*bw23 - conj(bw14)*bw24)/2.;
  Values::v2["GZN12"] = -conj(Values::v["GZN12"]);
  Values::v["GZN13"] = -gz*(conj(bw13)*bw33 - conj(bw14)*bw34)/2.;
  Values::v2["GZN13"] = -conj(Values::v["GZN13"]);
  Values::v["GZN14"] = -gz*(conj(bw13)*bw43 - conj(bw14)*bw44)/2.;
  Values::v2["GZN14"] = -conj(Values::v["GZN14"]);
  Values::v["GZN21"] = -gz*(conj(bw23)*bw13 - conj(bw24)*bw14)/2.;
  Values::v2["GZN21"] = -conj(Values::v["GZN21"]);
  Values::v["GZN22"] = -gz*(conj(bw23)*bw23 - conj(bw24)*bw24)/2.;
  Values::v2["GZN22"] = -conj(Values::v["GZN22"]);
  Values::v["GZN23"] = -gz*(conj(bw23)*bw33 - conj(bw24)*bw34)/2.;
  Values::v2["GZN23"] = -conj(Values::v["GZN23"]);
  Values::v["GZN24"] = -gz*(conj(bw23)*bw43 - conj(bw24)*bw44)/2.;
  Values::v2["GZN24"] = -conj(Values::v["GZN24"]);
  Values::v["GZN31"] = -gz*(conj(bw33)*bw13 - conj(bw34)*bw14)/2.;
  Values::v2["GZN31"] = -conj(Values::v["GZN31"]);
  Values::v["GZN32"] = -gz*(conj(bw33)*bw23 - conj(bw34)*bw24)/2.;
  Values::v2["GZN32"] = -conj(Values::v["GZN32"]);
  Values::v["GZN33"] = -gz*(conj(bw33)*bw33 - conj(bw34)*bw34)/2.;
  Values::v2["GZN33"] = -conj(Values::v["GZN33"]);
  Values::v["GZN34"] = -gz*(conj(bw33)*bw43 - conj(bw34)*bw44)/2.;
  Values::v2["GZN34"] = -conj(Values::v["GZN34"]);
  Values::v["GZN41"] = -gz*(conj(bw43)*bw13 - conj(bw44)*bw14)/2.;
  Values::v2["GZN41"] = -conj(Values::v["GZN41"]);
  Values::v["GZN42"] = -gz*(conj(bw43)*bw23 - conj(bw44)*bw24)/2.;
  Values::v2["GZN42"] = -conj(Values::v["GZN42"]);
  Values::v["GZN43"] = -gz*(conj(bw43)*bw33 - conj(bw44)*bw34)/2.;
  Values::v2["GZN43"] = -conj(Values::v["GZN43"]);
  Values::v["GZN44"] = -gz*(conj(bw43)*bw43 - conj(bw44)*bw44)/2.;
  Values::v2["GZN44"] = -conj(Values::v["GZN44"]);
  Values::v2["GWN1X1"] = gx/rt2 * (-conj(bw13)*uu12-rt2*conj(bw12)*uu11);
  Values::v["GWN1X1"] = gx/rt2 * (bw14*conj(vv12)-rt2*bw12*conj(vv11));
  Values::v2["GWN2X1"] = gx/rt2 * (-conj(bw23)*uu12-rt2*conj(bw22)*uu11);
  Values::v["GWN2X1"] = gx/rt2 * (bw24*conj(vv12)-rt2*bw22*conj(vv11));
  Values::v2["GWN3X1"] = gx/rt2 * (-conj(bw33)*uu12-rt2*conj(bw32)*uu11);
  Values::v["GWN3X1"] = gx/rt2 * (bw34*conj(vv12)-rt2*bw32*conj(vv11));
  Values::v2["GWN4X1"] = gx/rt2 * (-conj(bw43)*uu12-rt2*conj(bw42)*uu11);
  Values::v["GWN4X1"] = gx/rt2 * (bw44*conj(vv12)-rt2*bw42*conj(vv11));
  Values::v2["GWN1X2"] = gx/rt2 * (-conj(bw13)*uu22-rt2*conj(bw12)*uu21);
  Values::v["GWN1X2"] = gx/rt2 * (bw14*conj(vv22)-rt2*bw12*conj(vv21));
  Values::v2["GWN2X2"] = gx/rt2 * (-conj(bw23)*uu22-rt2*conj(bw22)*uu21);
  Values::v["GWN2X2"] = gx/rt2 * (bw24*conj(vv22)-rt2*bw22*conj(vv21));
  Values::v2["GWN3X2"] = gx/rt2 * (-conj(bw33)*uu22-rt2*conj(bw32)*uu21);
  Values::v["GWN3X2"] = gx/rt2 * (bw34*conj(vv22)-rt2*bw32*conj(vv21));
  Values::v2["GWN4X2"] = gx/rt2 * (-conj(bw43)*uu22-rt2*conj(bw42)*uu21);
  Values::v["GWN4X2"] = gx/rt2 * (bw44*conj(vv22)-rt2*bw42*conj(vv21));
  Values::v["GWX1N1"] = Values::v["GWN1X1"];
  Values::v2["GWX1N1"] = Values::v2["GWN1X1"];
  Values::v["GWX1N2"] = Values::v["GWN2X1"];
  Values::v2["GWX1N2"] = Values::v2["GWN2X1"];
  Values::v["GWX1N3"] = Values::v["GWN3X1"];
  Values::v2["GWX1N3"] = Values::v2["GWN3X1"];
  Values::v["GWX1N4"] = Values::v["GWN4X1"];
  Values::v2["GWX1N4"] = Values::v2["GWN4X1"];
  Values::v["GWX2N1"] = Values::v["GWN1X2"];
  Values::v2["GWX2N1"] = Values::v2["GWN1X2"];
  Values::v["GWX2N2"] = Values::v["GWN2X2"];
  Values::v2["GWX2N2"] = Values::v2["GWN2X2"];
  Values::v["GWX2N3"] = Values::v["GWN3X2"];
  Values::v2["GWX2N3"] = Values::v2["GWN3X2"];
  Values::v["GWX2N4"] = Values::v["GWN4X2"];
  Values::v2["GWX2N4"] = Values::v2["GWN4X2"];

  // FFS couplings -- non-Higgs
  Values::v["GELN1M"] = -rt2*gx*(t3e*bw12+bw11*(qe-t3e)*tw);
  Values::v2["GELN1M"] = 0.;
  Values::v["GERN1M"] = 0.;
  Values::v2["GERN1M"] = rt2*gx*(bw11*qe*tw);
  Values::v["GELN2M"] = -rt2*gx*(t3e*bw22+bw21*(qe-t3e)*tw);
  Values::v2["GEL2M"] = 0.;
  Values::v["GERN2M"] = 0.;
  Values::v2["GERN2M"] = rt2*gx*(bw21*qe*tw);
  Values::v["GELN3M"] = -rt2*gx*(t3e*bw32+bw31*(qe-t3e)*tw);
  Values::v2["GELN3M"] = 0.;
  Values::v["GERN3M"] = 0.;
  Values::v2["GERN3M"] = rt2*gx*(bw31*qe*tw);
  Values::v["GELN4M"] = -rt2*gx*(t3e*bw42+bw41*(qe-t3e)*tw);
  Values::v2["GELN4M"] = 0.;
  Values::v["GERN4M"] = 0.;
  Values::v["GERN4M"] = rt2*gx*bw41*qe*tw;
  Values::v["GELN1P"] = Values::v2["GELN1M"];
  Values::v2["GELN1P"] = Values::v["GELN1M"];
  Values::v["GERN1P"] = Values::v2["GERN1M"];
  Values::v2["GERN1P"] = Values::v["GERN1M"];
  Values::v["GELN2P"] = Values::v2["GELN2M"];
  Values::v2["GELN2P"] = Values::v["GELN2M"];
  Values::v["GERN2P"] = Values::v2["GERN2M"];
  Values::v2["GERN2P"] = Values::v["GERN2M"];
  Values::v["GELN3P"] = Values::v2["GELN3M"];
  Values::v2["GELN3P"] = Values::v["GELN3M"];
  Values::v["GERN3P"] = Values::v2["GERN3M"];
  Values::v2["GERN3P"] = Values::v["GERN3M"];
  Values::v["GELN4P"] = Values::v2["GELN4M"];
  Values::v2["GELN4P"] = Values::v["GELN4M"];
  Values::v["GERN4P"] = Values::v2["GERN4M"];
  Values::v2["GERN4P"] = Values::v["GERN4M"];
  Values::v["GLLN1M"] = -rt2*gx*(t3e*bw12+bw11*(qe-t3e)*tw);
  Values::v2["GLLN1M"] = -rt2*gx*rml/(2.*mwx*cb) * bw13;
  Values::v["GLRN1M"] = -rt2*gx*rml/(2.*mwx*cb) * bw13;
  Values::v2["GLRN1M"] = rt2*gx*bw11*qe*tw;
  Values::v["GLLN2M"] = -rt2*gx*(t3e*bw22+bw21*(qe-t3e)*tw);
  Values::v2["GLLN2M"] = -rt2*gx*rml/(2.*mwx*cb)*bw23;
  Values::v["GLRN2M"] =  -rt2*gx*rml/(2.*mwx*cb)*bw23;
  Values::v2["GLRN2M"] = rt2*gx*bw21*qe*tw;
  Values::v["GLLN3M"] = -rt2*gx*(t3e*bw32+bw31*(qe-t3e)*tw);
  Values::v2["GLLN3M"] = -rt2*gx*rml/(2.*mwx*cb)*bw33;
  Values::v["GLRN3M"] = -rt2*gx*rml/(2.*mwx*cb)*bw33;
  Values::v2["GLRN3M"] = rt2*gx*bw31*qe*tw;
  Values::v["GLLN4M"] = -rt2*gx*(t3e*bw42+bw41*(qe-t3e)*tw);
  Values::v2["GLLN4M"] = -rt2*gx*rml/(2.*mwx*cb)*bw43;
  Values::v["GLRN4M"] = -rt2*gx*rml/(2.*mwx*cb)*bw43;
  Values::v2["GLRN4M"] = rt2*gx*bw41*qe*tw;
  Values::v["GL1N1M"] = rl11 * Values::v["GLLN1M"]
    + rl12 * Values::v["GLRN1M"];
  Values::v["GL2N1M"] = rl21 * Values::v["GLLN1M"]
    + rl22 * Values::v["GLRN1M"];
  Values::v2["GL1N1M"] = rl11 * Values::v2["GLLN1M"]
    + rl12 * Values::v2["GLRN1M"];
  Values::v2["GL2N1M"] = rl21 * Values::v2["GLLN1M"]
    + rl22 * Values::v2["GLRN1M"];
  Values::v["GL1N2M"] = rl11 * Values::v["GLLN2M"]
    + rl12 * Values::v["GLRN2M"];
  Values::v["GL2N2M"] = rl21 * Values::v["GLLN2M"]
    + rl22 * Values::v["GLRN2M"];
  Values::v2["GL1N2M"] = rl11 * Values::v2["GLLN2M"]
    + rl12 * Values::v2["GLRN2M"];
  Values::v2["GL2N2M"] = rl21 * Values::v2["GLLN2M"]
    + rl22 * Values::v2["GLRN2M"];
  Values::v["GL1N3M"] = rl11 * Values::v["GLLN3M"]
    + rl12 * Values::v["GLRN3M"];
  Values::v["GL2N3M"] = rl21 * Values::v["GLLN3M"]
    + rl22 * Values::v["GLRN3M"];
  Values::v2["GL1N3M"] = rl11 * Values::v2["GLLN3M"]
    + rl12 * Values::v2["GLRN3M"];
  Values::v2["GL2N3M"] = rl21 * Values::v2["GLLN3M"]
    + rl22 * Values::v2["GLRN3M"];
  Values::v["GL1N4M"] = rl11 * Values::v["GLLN4M"]
    + rl12 * Values::v["GLRN4M"];
  Values::v["GL2N4M"] = rl21 * Values::v["GLLN4M"]
    + rl22 * Values::v["GLRN4M"];
  Values::v2["GL1N4M"] = rl11 * Values::v2["GLLN4M"]
    + rl12 * Values::v2["GLRN4M"];
  Values::v2["GL2N4M"] = rl21 * Values::v2["GLLN4M"]
    + rl22 * Values::v2["GLRN4M"];
  Values::v["GLLN1P"] = Values::v2["GLLN1M"];
  Values::v2["GLLN1P"] = Values::v["GLLN1M"];
  Values::v["GLRN1P"] = Values::v2["GLRN1M"];
  Values::v2["GLRN1P"] = Values::v["GLRN1M"];
  Values::v["GLLN2P"] = Values::v2["GLLN2M"];
  Values::v2["GLLN2P"] = Values::v["GLLN2M"];
  Values::v["GLRN2P"] = Values::v2["GLRN2M"];
  Values::v2["GLRN2P"] = Values::v["GLRN2M"];
  Values::v["GLLN3P"] = Values::v2["GLLN3M"];
  Values::v2["GLLN3P"] = Values::v["GLLN3M"];
  Values::v["GLRN3P"] = Values::v2["GLRN3M"];
  Values::v2["GLRN3P"] = Values::v["GLRN3M"];
  Values::v["GLLN4P"] = Values::v2["GLLN4M"];
  Values::v2["GLLN4P"] = Values::v["GLLN4M"];
  Values::v["GLRN4P"] = Values::v2["GLRN4M"];
  Values::v2["GLRN4P"] = Values::v["GLRN4M"];
  Values::v["GL1N1P"] = Values::v2["GL1N1M"];
  Values::v2["GL1N1P"] = Values::v["GL1N1M"];
  Values::v["GL2N1P"] = Values::v2["GL2N1M"];
  Values::v2["GL2N1P"] = Values::v["GL2N1M"];
  Values::v["GL1N2P"] = Values::v2["GL1N2M"];
  Values::v2["GL1N2P"] = Values::v["GL1N2M"];
  Values::v["GL2N2P"] = Values::v2["GL2N2M"];
  Values::v2["GL2N2P"] = Values::v["GL2N2M"];
  Values::v["GL1N3P"] = Values::v2["GL1N3M"];
  Values::v2["GL1N3P"] = Values::v["GL1N3M"];
  Values::v["GL2N3P"] = Values::v2["GL2N3M"];
  Values::v2["GL2N3P"] = Values::v["GL2N3M"];
  Values::v["GL1N4P"] = Values::v2["GL1N4M"];
  Values::v2["GL1N4P"] = Values::v["GL1N4M"];
  Values::v["GL2N4P"] = Values::v2["GL2N4M"];
  Values::v2["GL2N4P"] = Values::v["GL2N4M"];
  Values::v["GSVN1M"] = -rt2*gx*(t3v*bw12+bw11*(-t3v)*tw);
  Values::v2["GSVN1M"] = 0.;
  Values::v["GSVN2M"] = -rt2*gx*(t3v*bw22+bw21*(-t3v)*tw);
  Values::v2["GSVN2M"] = 0.;
  Values::v["GSVN3M"] = -rt2*gx*(t3v*bw32+bw31*(-t3v)*tw);
  Values::v2["GSVN3M"] = 0.;
  Values::v["GSVN4M"] = -rt2*gx*(t3v*bw42+bw41*(-t3v)*tw);
  Values::v2["GSVN4M"] = 0.;
  Values::v["GSVN1P"] = Values::v2["GSVN1M"];
  Values::v2["GSVN1P"] = Values::v["GSVN1M"];
  Values::v["GSVN2P"] = Values::v2["GSVN2M"];
  Values::v2["GSVN2P"] = Values::v["GSVN2M"];
  Values::v["GSVN3P"] = Values::v2["GSVN3M"];
  Values::v2["GSVN3P"] = Values::v["GSVN3M"];
  Values::v["GSVN4P"] = Values::v2["GSVN4M"];
  Values::v2["GSVN4P"] = Values::v["GSVN4M"];

  // Squark-quark-neutralino couplings
  Values::v["GDLN1M"] = -rt2*gx*(t3d*bw12+bw11*(qd-t3d)*tw);
  Values::v2["GDLN1M"] = 0.;
  Values::v["GDRN1M"] = 0.;
  Values::v2["GDRN1M"] = rt2*gx*bw11*qd*tw;
  Values::v["GDLN2M"] = -rt2*gx*(t3d*bw22+bw21*(qd-t3d)*tw);
  Values::v2["GDLN2M"] = 0.;
  Values::v["GDRN2M"] = 0.;
  Values::v2["GDRN2M"] = rt2*gx*bw21*qd*tw;
  Values::v["GDLN3M"] = -rt2*gx*(t3d*bw32+bw31*(qd-t3d)*tw);
  Values::v2["GDLN3M"] = 0.;
  Values::v["GDRN3M"] = 0.;
  Values::v2["GDRN3M"] = rt2*gx*bw31*qd*tw;
  Values::v["GDLN4M"] = -rt2*gx*(t3d*bw42+bw41*(qd-t3d)*tw);
  Values::v2["GDLN4M"] = 0.;
  Values::v["GDRN4M"] = 0.;
  Values::v2["GDRN4M"] = rt2*gx*bw41*qd*tw;
  Values::v["GDLN1P"] = Values::v2["GDLN1M"];
  Values::v2["GDLN1P"] = Values::v["GDLN1M"];
  Values::v["GDRN1P"] = Values::v2["GDRN1M"];
  Values::v2["GDRN1P"] = Values::v["GDRN1M"];
  Values::v["GDLN2P"] = Values::v2["GDLN2M"];
  Values::v2["GDLN2P"] = Values::v["GDLN2M"];
  Values::v["GDRN2P"] = Values::v2["GDRN2M"];
  Values::v2["GDRN2P"] = Values::v["GDRN2M"];
  Values::v["GDLN3P"] = Values::v2["GDLN3M"];
  Values::v2["GDLN3P"] = Values::v["GDLN3M"];
  Values::v["GDRN3P"] = Values::v2["GDRN3M"];
  Values::v2["GDRN3P"] = Values::v["GDRN3M"];
  Values::v["GDLN4P"] = Values::v2["GDLN4M"];
  Values::v2["GDLN4P"] = Values::v["GDLN4M"];
  Values::v["GDRN4P"] = Values::v2["GDRN4M"];
  Values::v2["GDRN4P"] = Values::v["GDRN4M"];
  Values::v["GBLN1M"] = -rt2*gx*(t3d*bw12+bw11*(qd-t3d)*tw);
  Values::v2["GBLN1M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw13;
  Values::v["GBRN1M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw13;
  Values::v2["GBRN1M"] = rt2*gx*bw11*qd*tw;
  Values::v["GBLN2M"] = -rt2*gx*(t3d*bw22+bw21*(qd-t3d)*tw);
  Values::v2["GBLN2M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw23;
  Values::v["GBRN2M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw23;
  Values::v2["GBRN2M"] = rt2*gx*bw21*qd*tw;
  Values::v["GBLN3M"] = -rt2*gx*(t3d*bw32+bw31*(qd-t3d)*tw);
  Values::v2["GBLN3M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw33;
  Values::v["GBRN3M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw33;
  Values::v2["GBRN3M"] = rt2*gx*bw31*qd*tw;
  Values::v["GBLN4M"] = -rt2*gx*(t3d*bw42+bw41*(qd-t3d)*tw);
  Values::v2["GBLN4M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw43;
  Values::v["GBRN4M"] = -rt2*gx*rmb/(2.*mwx*cb)*bw43;
  Values::v2["GBRN4M"] = rt2*gx*bw41*qd*tw;
  Values::v["GB1N1M"] = rb11*Values::v["GBLN1M"]+rb12*Values::v["GBRN1M"];
  Values::v["GB2N1M"] = rb21*Values::v["GBLN1M"]+rb22*Values::v["GBRN1M"];
  Values::v2["GB1N1M"] = rb11*Values::v2["GBLN1M"]+rb12*Values::v2["GBRN1M"];
  Values::v2["GB2N1M"] = rb21*Values::v2["GBLN1M"]+rb22*Values::v2["GBRN1M"];
  Values::v["GB1N2M"] = rb11*Values::v["GBLN2M"]+rb12*Values::v["GBRN2M"];
  Values::v["GB2N2M"] = rb21*Values::v["GBLN2M"]+rb22*Values::v["GBRN2M"];
  Values::v2["GB1N2M"] = rb11*Values::v2["GBLN2M"]+rb12*Values::v2["GBRN2M"];
  Values::v2["GB2N2M"] = rb21*Values::v2["GBLN2M"]+rb22*Values::v2["GBRN2M"];
  Values::v["GB1N3M"] = rb11*Values::v["GBLN3M"]+rb12*Values::v["GBRN3M"];
  Values::v["GB2N3M"] = rb21*Values::v["GBLN3M"]+rb22*Values::v["GBRN3M"];
  Values::v2["GB1N3M"] = rb11*Values::v2["GBLN3M"]+rb12*Values::v2["GBRN3M"];
  Values::v2["GB2N3M"] = rb21*Values::v2["GBLN3M"]+rb22*Values::v2["GBRN3M"];
  Values::v["GB1N4M"] = rb11*Values::v["GBLN4M"]+rb12*Values::v["GBRN4M"];
  Values::v["GB2N4M"] = rb21*Values::v["GBLN4M"]+rb22*Values::v["GBRN4M"];
  Values::v2["GB1N4M"] = rb11*Values::v2["GBLN4M"]+rb12*Values::v2["GBRN4M"];
  Values::v2["GB2N4M"] = rb21*Values::v2["GBLN4M"]+rb22*Values::v2["GBRN4M"];
  Values::v["GBLN1P"] = Values::v2["GBLN1M"];
  Values::v2["GBLN1P"] = Values::v["GBLN1M"];
  Values::v["GBRN1P"] = Values::v2["GBRN1M"];
  Values::v2["GBRN1P"] = Values::v["GBRN1M"];
  Values::v["GBLN2P"] = Values::v2["GBLN2M"];
  Values::v2["GBLN2P"] = Values::v["GBLN2M"];
  Values::v["GBRN2P"] = Values::v2["GBRN2M"];
  Values::v2["GBRN2P"] = Values::v["GBRN2M"];
  Values::v["GBLN3P"] = Values::v2["GBLN3M"];
  Values::v2["GBLN3P"] = Values::v["GBLN3M"];
  Values::v["GBRN3P"] = Values::v2["GBRN3M"];
  Values::v2["GBRN3P"] = Values::v["GBRN3M"];
  Values::v["GBLN4P"] = Values::v2["GBLN4M"];
  Values::v2["GBLN4P"] = Values::v["GBLN4M"];
  Values::v["GBRN4P"] = Values::v2["GBRN4M"];
  Values::v2["GBRN4P"] = Values::v["GBRN4M"];
  Values::v["GB1N1P"] = Values::v2["GB1N1M"];
  Values::v2["GB1N1P"] = Values::v["GB1N1M"];
  Values::v["GB2N1P"] = Values::v2["GB2N1M"];
  Values::v2["GB2N1P"] = Values::v["GB2N1M"]; 
  Values::v["GB1N2P"] = Values::v2["GB1N2M"];
  Values::v2["GB1N2P"] = Values::v["GB1N2M"];
  Values::v["GB2N2P"] = Values::v2["GB2N2M"];
  Values::v2["GB2N2P"] = Values::v["GB2N2M"];
  Values::v["GB1N3P"] = Values::v2["GB1N3M"];
  Values::v2["GB1N3P"] = Values::v["GB1N3M"];
  Values::v["GB2N3P"] = Values::v2["GB2N3M"];
  Values::v2["GB2N3P"] = Values::v["GB2N3M"];
  Values::v["GB1N4P"] = Values::v2["GB1N4M"];
  Values::v2["GB1N4P"] = Values::v["GB1N4M"];
  Values::v["GB2N4P"] = Values::v2["GB2N4M"];
  Values::v2["GB2N4P"] = Values::v["GB2N4M"];
  Values::v["GULN1M"] = -rt2*gx*(t3u*bw12+bw11*(qu-t3u)*tw);
  Values::v2["GULN1M"] = 0.;
  Values::v["GURN1M"] = 0.;
  Values::v2["GURN1M"] = rt2*gx*bw11*qu*tw;
  Values::v["GULN2M"] = -rt2*gx*(t3u*bw22+bw21*(qu-t3u)*tw);
  Values::v2["GULN2M"] = 0.;
  Values::v["GURN2M"] = 0.;
  Values::v2["GURN2M"] = rt2*gx*bw21*qu*tw;
  Values::v["GULN3M"] = -rt2*gx*(t3u*bw32+bw31*(qu-t3u)*tw);
  Values::v2["GULN3M"] = 0.;
  Values::v["GURN3M"] = 0.;
  Values::v2["GURN3M"] = rt2*gx*bw31*qu*tw;
  Values::v["GULN4M"] = -rt2*gx*(t3u*bw42+bw41*(qu-t3u)*tw);
  Values::v2["GULN4M"] = 0.;
  Values::v["GURN4M"] = 0.;
  Values::v2["GURN4M"] = rt2*gx*bw41*qu*tw;
  Values::v["GULN1P"] = Values::v2["GULN1M"];
  Values::v2["GULN1P"] = Values::v["GULN1M"];
  Values::v["GURN1P"] = Values::v2["GURN1M"];
  Values::v2["GURN1P"] = Values::v["GURN1M"];
  Values::v["GULN2P"] = Values::v2["GULN2M"];
  Values::v2["GULN2P"] = Values::v["GULN2M"];
  Values::v["GURN2P"] = Values::v2["GURN2M"];
  Values::v2["GURN2P"] = Values::v["GURN2M"];
  Values::v["GULN3P"] = Values::v2["GULN3M"];
  Values::v2["GULN3P"] = Values::v["GULN3M"];
  Values::v["GURN3P"] = Values::v2["GURN3M"];
  Values::v2["GURN3P"] = Values::v["GURN3M"];
  Values::v["GULN4P"] = Values::v2["GULN4M"];
  Values::v2["GULN4P"] = Values::v["GULN4M"];
  Values::v["GURN4P"] = Values::v2["GURN4M"];
  Values::v2["GURN4P"] = Values::v["GURN4M"];
  Values::v["GTLN1M"] = -rt2*gx*(t3u*bw12+bw11*(qu-t3u)*tw);
  Values::v2["GTLN1M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw14;
  Values::v["GTRN1M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw14;
  Values::v2["GTRN1M"] = rt2*gw*bw11*qu*tw;
  Values::v["GTLN2M"] = -rt2*gx*(t3u*bw22+bw21*(qu-t3u)*tw);
  Values::v2["GTLN2M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw24;
  Values::v["GTRN2M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw24;
  Values::v2["GTRN2M"] = rt2*gx*bw21*qu*tw;
  Values::v["GTLN3M"] = -rt2*gx*(t3u*bw32+bw31*(qu-t3u)*tw);
  Values::v2["GTLN3M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw34;
  Values::v["GTRN3M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw34;
  Values::v2["GTRN3M"] = rt2*gx*bw31*qu*tw;
  Values::v["GTLN4M"] = -rt2*gx*(t3u*bw42+bw41*(qu-t3u)*tw);
  Values::v2["GTLN4M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw44;
  Values::v["GTRN4M"] = -rt2*gx*rmt/(2.*mwx*sb)*bw44;
  Values::v2["GTRN4M"] = rt2*gx*bw41*qu*tw;
  Values::v["GT1N1M"] = rt11*Values::v["GTLN1M"]+rt12*Values::v["GTRN1M"];
  Values::v["GT2N1M"] = rt21*Values::v["GTLN1M"]+rt22*Values::v["GTRN1M"];
  Values::v2["GT1N1M"] = rt11*Values::v2["GTLN1M"]+rt12*Values::v2["GTRN1M"];
  Values::v2["GT2N1M"] = rt21*Values::v2["GTLN1M"]+rt22*Values::v2["GTRN1M"];
  Values::v["GT1N2M"] = rt11*Values::v["GTLN2M"]+rt12*Values::v["GTRN2M"];
  Values::v["GT2N2M"] = rt21*Values::v["GTLN2M"]+rt22*Values::v["GTRN2M"];
  Values::v2["GT1N2M"] = rt11*Values::v2["GTLN2M"]+rt12*Values::v2["GTRN2M"];
  Values::v2["GT2N2M"] = rt21*Values::v2["GTLN2M"]+rt22*Values::v2["GTRN2M"];
  Values::v["GT1N3M"] = rt11*Values::v["GTLN3M"]+rt12*Values::v["GTRN3M"];
  Values::v["GT2N3M"] = rt21*Values::v["GTLN3M"]+rt22*Values::v["GTRN3M"];
  Values::v2["GT1N3M"] = rt11*Values::v2["GTLN3M"]+rt12*Values::v2["GTRN3M"];
  Values::v2["GT2N3M"] = rt21*Values::v2["GTLN3M"]+rt22*Values::v2["GTRN3M"];
  Values::v["GT1N4M"] = rt11*Values::v["GTLN4M"]+rt12*Values::v["GTRN4M"];
  Values::v["GT2N4M"] = rt21*Values::v["GTLN4M"]+rt22*Values::v["GTRN4M"];
  Values::v2["GT1N4M"] = rt11*Values::v2["GTLN4M"]+rt12*Values::v2["GTRN4M"];
  Values::v2["GT2N4M"] = rt21*Values::v2["GTLN4M"]+rt22*Values::v2["GTRN4M"];
  Values::v["GTLN1P"] = Values::v2["GTLN1M"];
  Values::v2["GTLN1P"] = Values::v["GTLN1M"];
  Values::v["GTRN1P"] = Values::v2["GTRN1M"];
  Values::v2["GTRN1P"] = Values::v["GTRN1M"];
  Values::v["GTLN2P"] = Values::v2["GTLN2M"];
  Values::v2["GTLN2P"] = Values::v["GTLN2M"];
  Values::v["GTRN2P"] = Values::v2["GTRN2M"];
  Values::v2["GTRN2P"] = Values::v["GTRN2M"];
  Values::v["GTLN3P"] = Values::v2["GTLN3M"];
  Values::v2["GTLN3P"] = Values::v["GTLN3M"];
  Values::v["GTRN3P"] = Values::v2["GTRN3M"];
  Values::v2["GTRN3P"] = Values::v["GTRN3M"];
  Values::v["GTLN4P"] = Values::v2["GTLN4M"];
  Values::v2["GTLN4P"] = Values::v["GTLN4M"];
  Values::v["GTRN4P"] = Values::v2["GTRN4M"];
  Values::v2["GTRN4P"] = Values::v["GTRN4M"];
  Values::v["GT1N1P"] = Values::v2["GT1N1M"];
  Values::v2["GT1N1P"] = Values::v["GT1N1M"];
  Values::v["GT2N1P"] = Values::v2["GT2N1M"];
  Values::v2["GT2N1P"] = Values::v["GT2N1M"];
  Values::v["GT1N2P"] = Values::v2["GT1N2M"];
  Values::v2["GT1N2P"] = Values::v["GT1N2M"];
  Values::v["GT2N2P"] = Values::v2["GT2N2M"];
  Values::v2["GT2N2P"] = Values::v["GT2N2M"];
  Values::v["GT1N3P"] = Values::v2["GT1N3M"];
  Values::v2["GT1N3P"] = Values::v["GT1N3M"];
  Values::v["GT2N3P"] = Values::v2["GT2N3M"];
  Values::v2["GT2N3P"] = Values::v["GT2N3M"];
  Values::v["GT1N4P"] = Values::v2["GT1N4M"];
  Values::v2["GT1N4P"] = Values::v["GT1N4M"];
  Values::v["GT2N4P"] = Values::v2["GT2N4M"];
  Values::v2["GT2N4P"] = Values::v["GT2N4M"];

  // chargino-lepton-slepton
  Values::v["GELX1M"] = -rt2*gx*uu11/rt2;
  Values::v2["GELX1M"] = 0.;
  Values::v["GELX2M"] = -rt2*gx*uu21/rt2;
  Values::v2["GELX2M"] = 0.;
  Values::v["GELX1P"] = Values::v2["GELX1M"];
  Values::v2["GELX1P"] = Values::v["GELX1M"];
  Values::v["GELX2P"] = Values::v2["GELX2M"];
  Values::v2["GELX2P"] = Values::v["GELX2M"];
  Values::v["GLLX1M"] = -rt2*gx*uu11/rt2;
  Values::v2["GLLX1M"] = 0.;
  Values::v["GLRX1M"] = -rt2*gx*(-rml/(2.*mwx*cb)*uu12);
  Values::v2["GLRX1M"] = 0.;
  Values::v["GLLX2M"] = -rt2*gx*uu21/rt2;
  Values::v2["GLLX2M"] = 0.;
  Values::v["GLRX2M"] = -rt2*gx*(-rml/(2.*mwx*cb)*uu22);
  Values::v2["GLRX2M"] = 0.;
  Values::v["GL1X1M"] = rl11*Values::v["GLLX1M"]+rl12*Values::v["GLRX1M"];
  Values::v["GL2X1M"] = rl21*Values::v["GLLX1M"]+rl22*Values::v["GLRX1M"];
  Values::v2["GL1X1M"] = rl11*Values::v2["GLLX1M"]+rl12*Values::v2["GLRX1M"];
  Values::v2["GL2X1M"] = rl21*Values::v2["GLLX1M"]+rl22*Values::v2["GLRX1M"];
  Values::v["GL1X2M"] = rl11*Values::v["GLLX2M"]+rl12*Values::v["GLRX2M"];
  Values::v["GL2X2M"] = rl21*Values::v["GLLX2M"]+rl22*Values::v["GLRX2M"];
  Values::v2["GL1X2M"] = rl11*Values::v2["GLLX2M"]+rl12*Values::v2["GLRX2M"];
  Values::v2["GL2X2M"] = rl21*Values::v2["GLLX2M"]+rl22*Values::v2["GLRX2M"];
  Values::v["GLLX1P"] = Values::v2["GLLX1M"];
  Values::v2["GLLX1P"] = Values::v["GLLX1M"];
  Values::v["GLLX2P"] = Values::v2["GLLX2M"];
  Values::v2["GLLX2P"] = Values::v["GLLX2M"];
  Values::v["GLRX1P"] = Values::v2["GLRX1M"];
  Values::v2["GLRX1P"] = Values::v["GLRX1M"];
  Values::v["GLRX2P"] = Values::v2["GLRX2M"];
  Values::v2["GLRX2P"] = Values::v["GLRX2M"];
  Values::v["GL1X1P"] = Values::v2["GL1X1M"];
  Values::v2["GL1X1P"] = Values::v["GL1X1M"];
  Values::v["GL1X2P"] = Values::v2["GL1X2M"];
  Values::v2["GL1X2P"] = Values::v["GL1X2M"];
  Values::v["GL2X1P"] = Values::v2["GL2X1M"];
  Values::v2["GL2X1P"] = Values::v["GL2X1M"];
  Values::v["GL2X2P"] = Values::v2["GL2X2M"];
  Values::v2["GL2X2P"] = Values::v["GL2X2M"];
  Values::v["GVEX1M"] = -rt2*gx*vv11/rt2;
  Values::v2["GVEX1M"] = 0.;
  Values::v["GVEX2M"] = -rt2*gx*vv21/rt2;
  Values::v2["GVEX2M"] = 0.;
  Values::v["GVEX1P"] = Values::v2["GVEX1M"];
  Values::v2["GVEX1P"] = Values::v["GVEX1M"];
  Values::v["GVEX2P"] = Values::v2["GVEX2M"];
  Values::v2["GVEX2P"] = Values::v["GVEX2M"];
  Values::v["GVTX1M"] = -rt2*gx*vv11/rt2;
  Values::v2["GVTX1M"] = -rt2*gx*(-rml/(2.*mwx*cb)*uu12);
  Values::v["GVTX2M"] = -rt2*gx*vv21/rt2;
  Values::v2["GVTX2M"] = -rt2*gx*(-rml/(2.*mwx*cb)*uu22);
  Values::v["GVTX1P"] = Values::v2["GVTX1M"];
  Values::v2["GVTX1P"] = Values::v["GVTX1M"];
  Values::v["GVTX2P"] = Values::v2["GVTX2M"];
  Values::v2["GVTX2P"] = Values::v["GVTX2M"];

  // chargino-quark-squark
  Values::v["GDLX1M"] = -rt2*gx*uu11/rt2;
  Values::v2["GDLX1M"] = 0.;
  Values::v["GDLX2M"] = -rt2*gx*uu21/rt2;
  Values::v2["GDLX2M"] = 0.;
  Values::v["GDLX1P"] = Values::v2["GDLX1M"];
  Values::v2["GDLX1P"] = Values::v["GDLX1M"];
  Values::v["GDLX2P"] = Values::v2["GDLX2M"];
  Values::v2["GDLX2P"] = Values::v["GDLX2M"];
  Values::v["GBLX1M"] = -rt2*gx*uu11/rt2;
  Values::v2["GBLX1M"] = -rt2*gx*(-rmt/(2.*mwx*sb)*vv12);
  Values::v["GBRX1M"] = -rt2*gx*(-rmb/(2.*mwx*cb)*uu12);
  Values::v2["GBRX1M"] = 0.;
  Values::v["GBLX2M"] = -rt2*gx*uu21/rt2;
  Values::v2["GBLX2M"] = -rt2*gx*(-rmt/(2.*mwx*sb)*vv22);
  Values::v["GBRX2M"] = -rt2*gx*(-rmb/(2.*mwx*cb)*uu22);
  Values::v2["GBRX2M"] = 0.;
  Values::v["GB1X1M"] = rb11*Values::v["GBLX1M"]+rb12*Values::v["GBRX1M"];
  Values::v["GB2X1M"] = rb21*Values::v["GBLX1M"]+rb22*Values::v["GBRX1M"];
  Values::v2["GB1X1M"] = rb11*Values::v2["GBLX1M"]+rb12*Values::v2["GBRX1M"];
  Values::v2["GB2X1M"] = rb21*Values::v2["GBLX1M"]+rb22*Values::v2["GBRX1M"];
  Values::v["GB1X2M"] = rb11*Values::v["GBLX2M"]+rb12*Values::v["GBRX2M"];
  Values::v["GB2X2M"] = rb21*Values::v["GBLX2M"]+rb22*Values::v["GBRX2M"];
  Values::v2["GB1X2M"] = rb11*Values::v2["GBLX2M"]+rb12*Values::v2["GBRX2M"];
  Values::v2["GB2X2M"] = rb21*Values::v2["GBLX2M"]+rb22*Values::v2["GBRX2M"];
  Values::v["GBLX1P"] = Values::v2["GBLX1M"];
  Values::v2["GBLX1P"] = Values::v["GBLX1M"]; 
  Values::v["GBLX2P"] = Values::v2["GBLX2M"];
  Values::v2["GBLX2P"] = Values::v["GBLX2M"]; 
  Values::v["GBRX1P"] = Values::v2["GBRX1M"];
  Values::v2["GBRX1P"] = Values::v["GBRX1M"]; 
  Values::v["GBRX2P"] = Values::v2["GBRX2M"];
  Values::v2["GBRX2P"] = Values::v["GBRX2M"]; 
  Values::v["GB1X1P"] = Values::v2["GB1X1M"];
  Values::v2["GB1X1P"] = Values::v["GB1X1M"]; 
  Values::v["GB1X2P"] = Values::v2["GB1X2M"];
  Values::v2["GB1X2P"] = Values::v["GB1X2M"]; 
  Values::v["GB2X1P"] = Values::v2["GB2X1M"];
  Values::v2["GB2X1P"] = Values::v["GB2X1M"]; 
  Values::v["GB2X2P"] = Values::v2["GB2X2M"];
  Values::v2["GB2X2P"] = Values::v["GB2X2M"]; 
  Values::v["GULX1M"] = -rt2*gx*vv11/rt2;
  Values::v2["GULX1M"] = 0.;
  Values::v["GULX2M"] = -rt2*gx*vv21/rt2;
  Values::v2["GULX2M"] = 0.;
  Values::v["GULX1P"] = Values::v2["GULX1M"];
  Values::v2["GULX1P"] = Values::v["GULX1M"];
  Values::v["GULX2P"] = Values::v2["GULX2M"];
  Values::v2["GULX2P"] = Values::v["GULX2M"];
  Values::v["GTLX1M"] = -rt2*gx*vv11/rt2;
  Values::v2["GTLX1M"] = -rt2*gx*(-rmb/(2.*mwx*cb)*uu12);
  Values::v["GTRX1M"] = -rt2*gx*(-rmt/(2.*mwx*sb)*vv12);
  Values::v2["GTRX1M"] = 0.;
  Values::v["GTLX2M"] = -rt2*gx*vv21/rt2;
  Values::v2["GTLX2M"] = -rt2*gx*(-rmb/(2.*mwx*cb)*uu22);
  Values::v["GTRX2M"] = -rt2*gx*(-rmt/(2.*mwx*sb)*vv22);
  Values::v2["GTRX2M"] = 0.;
  Values::v["GT1X1M"] = rt11*Values::v["GTLX1M"]+rt12*Values::v["GTRX1M"];
  Values::v["GT2X1M"] = rt21*Values::v["GTLX1M"]+rt22*Values::v["GTRX1M"];
  Values::v2["GT1X1M"] = rt11*Values::v2["GTLX1M"]+rt12*Values::v2["GTRX1M"];
  Values::v2["GT2X1M"] = rt21*Values::v2["GTLX1M"]+rt22*Values::v2["GTRX1M"];
  Values::v["GT1X2M"] = rt11*Values::v["GTLX2M"]+rt12*Values::v["GTRX2M"];
  Values::v["GT2X2M"] = rt21*Values::v["GTLX2M"]+rt22*Values::v["GTRX2M"];
  Values::v2["GT1X2M"] = rt11*Values::v2["GTLX2M"]+rt12*Values::v2["GTRX2M"];
  Values::v2["GT2X2M"] = rt21*Values::v2["GTLX2M"]+rt22*Values::v2["GTRX2M"];
  Values::v["GTLX1P"] = Values::v2["GTLX1M"];
  Values::v2["GTLX1P"] = Values::v["GTLX1M"]; 
  Values::v["GTLX2P"] = Values::v2["GTLX2M"];
  Values::v2["GTLX2P"] = Values::v["GTLX2M"]; 
  Values::v["GTRX1P"] = Values::v2["GTRX1M"];
  Values::v2["GTRX1P"] = Values::v["GTRX1M"]; 
  Values::v["GTRX2P"] = Values::v2["GTRX2M"];
  Values::v2["GTRX2P"] = Values::v["GTRX2M"]; 
  Values::v["GT1X1P"] = Values::v2["GT1X1M"];
  Values::v2["GT1X1P"] = Values::v["GT1X1M"]; 
  Values::v["GT1X2P"] = Values::v2["GT1X2M"];
  Values::v2["GT1X2P"] = Values::v["GT1X2M"]; 
  Values::v["GT2X1P"] = Values::v2["GT2X1M"];
  Values::v2["GT2X1P"] = Values::v["GT2X1M"]; 
  Values::v["GT2X2P"] = Values::v2["GT2X2M"];
  Values::v2["GT2X2P"] = Values::v["GT2X2M"]; 

  // Higgs couplings
  // FFS
  Values::v["GH1TT"] = -gx/2.0/mwx * rmt/sb * ca;
  Values::v["GH2TT"] = -gx/2.0/mwx * rmt/sb * sa;
  Values::v["GH3TT"] = -gx/2.0/mwx * rmt/sb * cb * i_unit;
  Values::v2["GH1TT"] = Values::v["GH1TT"];
  Values::v2["GH2TT"] = Values::v["GH2TT"];
  Values::v2["GH3TT"] = -Values::v["GH3TT"];
  Values::v["GH1BB"] = gx/2.0/mwx * rmb/cb * sa;
  Values::v["GH2BB"] = -gx/2.0/mwx * rmb/cb * ca;
  Values::v["GH3BB"] = -gx/2.0/mwx * rmb/cb * sb * i_unit;
  Values::v2["GH1BB"] = Values::v["GH1BB"];
  Values::v2["GH2BB"] = Values::v["GH2BB"];
  Values::v2["GH3BB"] = -Values::v["GH3BB"];
  Values::v["GH1LL"] = gx/2.0/mwx * rml/cb * sa;
  Values::v["GH2LL"] = -gx/2.0/mwx * rml/cb * ca;
  Values::v["GH3LL"] = -gx/2.0/mwx * rml/cb * sb * i_unit;
  Values::v2["GH1LL"] = Values::v["GH1LL"];
  Values::v2["GH2LL"] = Values::v["GH2LL"];
  Values::v2["GH3LL"] = -Values::v["GH3LL"];
  Values::v["GHMQ"] = gx/rt2/mwx * rmt / tgb;
  Values::v2["GHMQ"] = gx/rt2/mwx * rmb * tgb;
  Values::v["GHML"] = 0.0;
  Values::v2["GHML"] = gx/rt2/mwx * rml * tgb;
  Values::v["GHPQ"] = Values::v2["GHMQ"];
  Values::v["GHPL"] = Values::v2["GHML"];
  Values::v2["GHPQ"] = Values::v["GHMQ"];
  Values::v2["GHPL"] = Values::v["GHML"];

  // VVS 
  Values::v["GWWH1"] = gx * mwx * sbma;
  Values::v["GWWH2"] = gx * mwx * cbma;
  Values::v["GZZH1"] = gx * mzx / cw * sbma;
  Values::v["GZZH2"] = gx * mzx / cw * cbma;
  Values::v["GAHCHC"] = e;
  Values::v["GZHCHC"] = e * c2w / s2w;
  Values::v["GWHCH1"] = -gx/2.0 * (cd1 * sb - cucc1 * cb);
  Values::v["GWH1HC"] = Values::v["GWHCH1"];
  Values::v["GWHCH2"] = -gx/2.0 * (cd2 * sb - cucc2 * cb);
  Values::v["GWH2HC"] = Values::v["GWHCH2"];
  Values::v["GWHCH3"] = -gx/2.0 * (cd3 * sb - cucc3 * cb);
  Values::v["GWH3HC"] = -Values::v["GWHCH3"];
  Values::v["GZH1H3"] = -gz/2.0 * cbma * i_unit;
  Values::v["GZH2H3"] = gz/2.0 * sbma * i_unit;

  // SSS
  double ghhh =  -3.0/2.0 * mzx * gz;
  Values::v["GHHH"] = ghhh;
  Values::v["GH111"] = ghhh * caa * sbpa;
  Values::v["GH112"] = ghhh * 2.0/3.0 * (saa*sbpa - caa*cbpa/2.0);
  Values::v["GH122"] = -ghhh * 2.0/3.0 * (saa*cbpa + caa*sbpa/2.0);
  Values::v["GH222"] = ghhh * caa * cbpa;
  Values::v["GH133"] = ghhh * cbb * sbpa / 3.0;
  Values::v["GH233"] = -ghhh * cbb * cbpa / 3.0;
  Values::v["GH1CC"] = ghhh/3.0 * (2.0*cw*cw*sbma + cbb*sbpa);
  Values::v["GH2CC"] = ghhh/3.0 * (2.0*cw*cw*cbma - cbb*cbpa);
  Values::v["GH1ULUL"] = -gz*mzx*(t3u-qu*sw2) * (cd1*cb-cu1*sb);
  Values::v["GH1DLDL"] = -gz*mzx*(t3d-qd*sw2) * (cd1*cb-cu1*sb);
  Values::v["GH1ELEL"] = -gz*mzx*(t3e-qe*sw2) * (cd1*cb-cu1*sb);
  Values::v["GH1VEVE"] = -gz*mzx*(t3v) * (cd1*cb-cu1*sb);
  Values::v["GH1URUR"] = gz*mzx*(-qu*sw2)*(cd1*cb-cu1*sb);
  Values::v["GH1DRDR"] = gz*mzx*(-qd*sw2)*(cd1*cb-cu1*sb);
  Values::v["GH1ERER"] = gz*mzx*(-qe*sw2)*(cd1*cb-cu1*sb);
  Values::v["GH2ULUL"] = -gz*mzx*(t3u-qu*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH2DLDL"] = -gz*mzx*(t3d-qd*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH2ELEL"] = -gz*mzx*(t3e-qe*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH2VEVE"] = -gz*mzx*(t3v)*(cd2*cb-cu2*sb);
  Values::v["GH2URUR"] = gz*mzx*(-qu*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH2DRDR"] = gz*mzx*(-qd*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH2ERER"] = gz*mzx*(-qe*sw2)*(cd2*cb-cu2*sb);
  Values::v["GH1LLLL"] = Values::v["GH1ELEL"]-gx*rml*rml/mwx/cb * cd1;
  Values::v["GH1LRLR"] = Values::v["GH1ERER"]-gx*rml*rml/mwx/cb * cd1;
  Values::v["GH1LLLR"] = -gx*rml/2.0/mwx/cb * (a_tau*cdcc1 - mu*cu1);
  Values::v["GH1LRLL"] = conj(Values::v["GH1LLLR"]);
  Values::v["GH2LLLL"] = Values::v["GH2ELEL"]-gx*rml*rml/mwx/cb * cd2;
  Values::v["GH2LRLR"] = Values::v["GH2ERER"]-gx*rml*rml/mwx/cb * cd2;
  Values::v["GH2LLLR"] = -gx*rml/2.0/mwx/cb * (a_tau*cdcc2 - mu*cu2);
  Values::v["GH2LRLL"] = conj(Values::v["GH2LLLR"]);
  Values::v["GH3LLLL"] = 0.0;
  Values::v["GH3LRLR"] = 0.0;
  Values::v["GH3LLLR"] = -gx*rml/2.0/mwx/cb * (a_tau*cdcc3 - mu*cu3);
  Values::v["GH3LRLL"] = conj(Values::v["GH3LLLR"]);
  Values::v["GH1BLBL"] = Values::v["GH1DLDL"] - gx*rmb*rmb/mwx/cb * cd1;
  Values::v["GH1BRBR"] = Values::v["GH1DRDR"] - gx*rmb*rmb/mwx/cb * cd1;
  Values::v["GH1BLBR"] = -gx*rmb/2.0/mwx/cb * (a_bot*cdcc1 - mu*cu1);
  Values::v["GH1BRBL"] = conj(Values::v["GH1BLBR"]);
  Values::v["GH2BLBL"] = Values::v["GH2DLDL"] - gx*rmb*rmb/mwx/cb * cd2;
  Values::v["GH2BRBR"] = Values::v["GH2DRDR"] - gx*rmb*rmb/mwx/cb * cd2;
  Values::v["GH2BLBR"] = -gx*rmb/2.0/mwx/cb * (a_bot*cdcc2 - mu*cu2);
  Values::v["GH2BRBL"] = conj(Values::v["GH2BLBR"]);
  Values::v["GH3BLBL"] = 0.0;
  Values::v["GH3BRBR"] = 0.0;
  Values::v["GH3BLBR"] = -gx*rmb/2.0/mwx/cb * (a_bot*cdcc3 - mu*cu3);
  Values::v["GH3BRBL"] = conj(Values::v["GH3BLBR"]);
  Values::v["GH1TLTL"] = Values::v["GH1ULUL"] - gx*rmt*rmt/mwx/sb * cu1;
  Values::v["GH1TRTR"] = Values::v["GH1URUR"] - gx*rmt*rmt/mwx/sb * cu1;
  Values::v["GH1TLTR"] = -gx*rmt/2.0/mwx/sb * (a_top*cucc1 - mu*cd1);
  Values::v["GH1TRTL"] = conj(Values::v["GH1TLTR"]);
  Values::v["GH2TLTL"] = Values::v["GH2ULUL"] - gx*rmt*rmt/mwx/sb * cu2;
  Values::v["GH2TRTR"] = Values::v["GH2URUR"] - gx*rmt*rmt/mwx/sb * cu2;
  Values::v["GH2TLTR"] = -gx*rmt/2.0/mwx/sb * (a_top*cucc2 - mu*cd2);
  Values::v["GH2TRTL"] = conj(Values::v["GH2TLTR"]);
  Values::v["GH3TLTL"] = 0.0;
  Values::v["GH3TRTR"] = 0.0;
  Values::v["GH3TLTR"] = -gx*rmt/2.0/mwx/sb * (a_top*cucc3 - mu*cd3);
  Values::v["GH3TRTL"] = conj(Values::v["GH3TLTR"]);
  Values::v["GH1L1L1"] = rl11*rl11*Values::v["GH1LLLL"]
    + rl12*rl12*Values::v["GH1LRLR"]
    + rl11*rl12*Values::v["GH1LLLR"]
    + rl11*rl12*Values::v["GH1LRLL"];
  Values::v["GH1L2L2"] = rl21*rl21*Values::v["GH1LLLL"]
    + rl22*rl22*Values::v["GH1LRLR"]
    + rl21*rl22*Values::v["GH1LLLR"]
    + rl21*rl22*Values::v["GH1LRLL"];
  Values::v["GH1L1L2"] = rl11*rl21*Values::v["GH1LLLL"]
    + rl12*rl22*Values::v["GH1LRLR"]
    + rl11*rl22*Values::v["GH1LLLR"]
    + rl12*rl21*Values::v["GH1LRLL"];
  Values::v["GH1L2L1"] = conj(Values::v["GH1L1L2"]);

  Values::v["GH2L1L1"] = rl11*rl11*Values::v["GH2LLLL"]
    + rl12*rl12*Values::v["GH2LRLR"]
    + rl11*rl12*Values::v["GH2LLLR"]
    + rl11*rl12*Values::v["GH2LRLL"];
  Values::v["GH2L2L2"] = rl21*rl21*Values::v["GH2LLLL"]
    + rl22*rl22*Values::v["GH2LRLR"]
    + rl21*rl22*Values::v["GH2LLLR"]
    + rl21*rl22*Values::v["GH2LRLL"];
  Values::v["GH2L1L2"] = rl11*rl21*Values::v["GH2LLLL"]
    + rl12*rl22*Values::v["GH2LRLR"]
    + rl11*rl22*Values::v["GH2LLLR"]
    + rl12*rl21*Values::v["GH2LRLL"];
  Values::v["GH2L2L1"] = conj(Values::v["GH2L1L2"]);

  Values::v["GH3L1L1"] = rl11*rl11*Values::v["GH3LLLL"]
    + rl12*rl12*Values::v["GH3LRLR"]
    + rl11*rl12*Values::v["GH3LLLR"]
    + rl11*rl12*Values::v["GH3LRLL"];
  Values::v["GH3L2L2"] = rl21*rl21*Values::v["GH3LLLL"]
    + rl22*rl22*Values::v["GH3LRLR"]
    + rl21*rl22*Values::v["GH3LLLR"]
    + rl21*rl22*Values::v["GH3LRLL"];
  Values::v["GH3L1L2"] = rl11*rl21*Values::v["GH3LLLL"]
    + rl12*rl22*Values::v["GH3LRLR"]
    + rl11*rl22*Values::v["GH3LLLR"]
    + rl12*rl21*Values::v["GH3LRLL"];
  Values::v["GH3L2L1"] = conj(Values::v["GH3L1L2"]);

  Values::v["GH1B1B1"] = rb11*rb11*Values::v["GH1BLBL"]
    + rb12*rb12*Values::v["GH1BRBR"]
    + rb11*rb12*Values::v["GH1BLBR"]
    + rb11*rb12*Values::v["GH1BRBL"];
  Values::v["GH1B2B2"] = rb21*rb21*Values::v["GH1BLBL"]
    + rb22*rb22*Values::v["GH1BRBR"]
    + rb21*rb22*Values::v["GH1BLBR"]
    + rb21*rb22*Values::v["GH1BRBL"];
  Values::v["GH1B1B2"] = rb11*rb21*Values::v["GH1BLBL"]
    + rb12*rb22*Values::v["GH1BRBR"]
    + rb11*rb22*Values::v["GH1BLBR"]
    + rb12*rb21*Values::v["GH1BRBL"];
  Values::v["GH1B2B1"] = conj(Values::v["GH1B1B2"]);

  Values::v["GH2B1B1"] = rb11*rb11*Values::v["GH2BLBL"]
    + rb12*rb12*Values::v["GH2BRBR"]
    + rb11*rb12*Values::v["GH2BLBR"]
    + rb11*rb12*Values::v["GH2BRBL"];
  Values::v["GH2B2B2"] = rb21*rb21*Values::v["GH2BLBL"]
    + rb22*rb22*Values::v["GH2BRBR"]
    + rb21*rb22*Values::v["GH2BLBR"]
    + rb21*rb22*Values::v["GH2BRBL"];
  Values::v["GH2B1B2"] = rb11*rb21*Values::v["GH2BLBL"]
    + rb12*rb22*Values::v["GH2BRBR"]
    + rb11*rb22*Values::v["GH2BLBR"]
    + rb12*rb21*Values::v["GH2BRBL"];
  Values::v["GH2B2B1"] = conj(Values::v["GH2B1B2"]);

  Values::v["GH3B1B1"] = rb11*rb11*Values::v["GH3BLBL"]
    + rb12*rb12*Values::v["GH3BRBR"]
    + rb11*rb12*Values::v["GH3BLBR"]
    + rb11*rb12*Values::v["GH3BRBL"];
  Values::v["GH3B2B2"] = rb21*rb21*Values::v["GH3BLBL"]
    + rb22*rb22*Values::v["GH3BRBR"]
    + rb21*rb22*Values::v["GH3BLBR"]
    + rb21*rb22*Values::v["GH3BRBL"];
  Values::v["GH3B1B2"] = rb11*rb21*Values::v["GH3BLBL"]
    + rb12*rb22*Values::v["GH3BRBR"]
    + rb11*rb22*Values::v["GH3BLBR"]
    + rb12*rb21*Values::v["GH3BRBL"];
  Values::v["GH3B2B1"] = conj(Values::v["GH3B1B2"]);

  Values::v["GH1T1T1"] = rt11*rt11*Values::v["GH1TLTL"]
    + rt12*rt12*Values::v["GH1TRTR"]
    + rt11*rt12*Values::v["GH1TLTR"]
    + rt11*rt12*Values::v["GH1TRTL"];
  Values::v["GH1T2T2"] = rt21*rt21*Values::v["GH1TLTL"]
    + rt22*rt22*Values::v["GH1TRTR"]
    + rt21*rt22*Values::v["GH1TLTR"]
    + rt21*rt22*Values::v["GH1TRTL"];
  Values::v["GH1T1T2"] = rt11*rt21*Values::v["GH1TLTL"]
    + rt12*rt22*Values::v["GH1TRTR"]
    + rt11*rt22*Values::v["GH1TLTR"]
    + rt12*rt21*Values::v["GH1TRTL"];
  Values::v["GH1T2T1"] = conj(Values::v["GH1T1T2"]);

  Values::v["GH2T1T1"] = rt11*rt11*Values::v["GH2TLTL"]
    + rt12*rt12*Values::v["GH2TRTR"]
    + rt11*rt12*Values::v["GH2TLTR"]
    + rt11*rt12*Values::v["GH2TRTL"];
  Values::v["GH2T2T2"] = rt21*rt21*Values::v["GH2TLTL"]
    + rt22*rt22*Values::v["GH2TRTR"]
    + rt21*rt22*Values::v["GH2TLTR"]
    + rt21*rt22*Values::v["GH2TRTL"];
  Values::v["GH2T1T2"] = rt11*rt21*Values::v["GH2TLTL"]
    + rt12*rt22*Values::v["GH2TRTR"]
    + rt11*rt22*Values::v["GH2TLTR"]
    + rt12*rt21*Values::v["GH2TRTL"];
  Values::v["GH2T2T1"] = conj(Values::v["GH2T1T2"]);

  Values::v["GH3T1T1"] = rt11*rt11*Values::v["GH3TLTL"]
    + rt12*rt12*Values::v["GH3TRTR"]
    + rt11*rt12*Values::v["GH3TLTR"]
    + rt11*rt12*Values::v["GH3TRTL"];
  Values::v["GH3T2T2"] = rt21*rt21*Values::v["GH3TLTL"]
    + rt22*rt22*Values::v["GH3TRTR"]
    + rt21*rt22*Values::v["GH3TLTR"]
    + rt21*rt22*Values::v["GH3TRTL"];
  Values::v["GH3T1T2"] = rt11*rt21*Values::v["GH3TLTL"]
    + rt12*rt22*Values::v["GH3TRTR"]
    + rt11*rt22*Values::v["GH3TLTR"]
    + rt12*rt21*Values::v["GH3TRTL"];
  Values::v["GH3T2T1"] = conj(Values::v["GH3T1T2"]);

  Values::v["GHCULDL"] = -gx*mwx/rt2 * sbb;
  Values::v["GHCVEEL"] = -gx*mwx/rt2 * sbb;
  Values::v["GHCDLUL"] = Values::v["GHCULDL"];
  Values::v["GHCELVE"] = Values::v["GHCVEEL"];
  Values::v["GHCTLBL"] = Values::v["GHCULDL"]
    + gx/mwx/rt2 * (rmb*rmb*tgb + rmt*rmt/tgb);
  Values::v["GHCTRBR"] = gx/mwx/rt2 * 2.0 * rmb * rmt / sbb;
  Values::v["GHCTLBR"] = gx/mwx/rt2 * rmb * (a_bot * tgb + mu);
  Values::v["GHCTRBL"] = gx/mwx/rt2 * rmt * (a_top / tgb + mu);
  Values::v["GHCVTLL"] = Values::v["GHCVEEL"] + gx/mwx/rt2 * rml*rml*tgb;
  Values::v["GHCVTLR"] = gx/mwx/rt2 * rml * (a_tau * tgb + mu);

  Values::v["GHCT1B1"] = rt11*rb11*Values::v["GHCTLBL"]
    + rt11*rb12*Values::v["GHCTLBR"]
    + rt12*rb11*Values::v["GHCTRBL"]
    + rt12*rb12*Values::v["GHCTRBR"];
  Values::v["GHCT2B1"] = rt21*rb11*Values::v["GHCTLBL"]
    + rt21*rb12*Values::v["GHCTLBR"]
    + rt22*rb11*Values::v["GHCTRBL"]
    + rt22*rb12*Values::v["GHCTRBR"];
  Values::v["GHCT1B2"] = rt11*rb21*Values::v["GHCTLBL"]
    + rt11*rb22*Values::v["GHCTLBR"]
    + rt12*rb21*Values::v["GHCTRBL"]
    + rt12*rb22*Values::v["GHCTRBR"];
  Values::v["GHCT2B2"] = rt21*rb21*Values::v["GHCTLBL"]
    + rt21*rb22*Values::v["GHCTLBR"]
    + rt22*rb21*Values::v["GHCTRBL"]
    + rt22*rb22*Values::v["GHCTRBR"];
  Values::v["GHCB1T1"] = conj(Values::v["GHCT1B1"]);
  Values::v["GHCB1T2"] = conj(Values::v["GHCT2B1"]);
  Values::v["GHCB2T1"] = conj(Values::v["GHCT1B2"]);
  Values::v["GHCB2T2"] = conj(Values::v["GHCT2B2"]);
  Values::v["GHCVTL1"] = rl11*Values::v["GHCVTLL"] + rl12*Values::v["GHCVTLR"];
  Values::v["GHCVTL2"] = rl21*Values::v["GHCVTLL"] + rl22*Values::v["GHCVTLR"];
  Values::v["GHCL1VT"] = conj(Values::v["GHCVTL1"]);
  Values::v["GHCL2VT"] = conj(Values::v["GHCVTL2"]);

  // FFS
  // couplings to weak inos
  Values::v["GH1X11"] = -gx/rt2*(cdcc1*uu12*vv11+cucc1*uu11*vv12);
  Values::v["GH1X12"] = -gx/rt2*(cdcc1*uu12*vv21+cucc1*uu11*vv22);
  Values::v["GH1X21"] = -gx/rt2*(cdcc1*uu22*vv11+cucc1*uu21*vv12);
  Values::v["GH1X22"] = -gx/rt2*(cdcc1*uu22*vv21+cucc1*uu21*vv22);
  Values::v["GH2X11"] = -gx/rt2*(cdcc2*uu12*vv11+cucc2*uu11*vv12);
  Values::v["GH2X12"] = -gx/rt2*(cdcc2*uu12*vv21+cucc2*uu11*vv22);
  Values::v["GH2X21"] = -gx/rt2*(cdcc2*uu22*vv11+cucc2*uu21*vv12);
  Values::v["GH2X22"] = -gx/rt2*(cdcc2*uu22*vv21+cucc2*uu21*vv22);
  Values::v["GH3X11"] = -gx/rt2*(cdcc3*uu12*vv11+cucc3*uu11*vv12);
  Values::v["GH3X12"] = -gx/rt2*(cdcc3*uu12*vv21+cucc3*uu11*vv22);
  Values::v["GH3X21"] = -gx/rt2*(cdcc3*uu22*vv11+cucc3*uu21*vv12);
  Values::v["GH3X22"] = -gx/rt2*(cdcc3*uu22*vv21+cucc3*uu21*vv22);
  Values::v2["GH1X11"] = Values::v["GH1X11"];
  Values::v2["GH1X12"] = Values::v["GH1X21"];
  Values::v2["GH1X21"] = Values::v["GH1X12"];
  Values::v2["GH1X22"] = Values::v["GH1X22"];
  Values::v2["GH2X11"] = Values::v["GH2X11"];
  Values::v2["GH2X12"] = Values::v["GH2X21"];
  Values::v2["GH2X21"] = Values::v["GH2X12"];
  Values::v2["GH2X22"] = Values::v["GH2X22"];
  Values::v2["GH3X11"] = -Values::v["GH3X11"];
  Values::v2["GH3X12"] = -Values::v["GH3X21"];
  Values::v2["GH3X21"] = -Values::v["GH3X12"];
  Values::v2["GH3X22"] = -Values::v["GH3X22"];
  Values::v["GH1N11"] = -gx/2.0 * ((cdcc1*bw13-cucc1*bw14)*(bw12-tw*bw11)
                 + (cdcc1*bw13-cucc1*bw14)*(bw12-tw*bw11));
  Values::v["GH1N12"] = -gx/2.0 * ((cdcc1*bw13-cucc1*bw14)*(bw22-tw*bw21)
                 + (cdcc1*bw23-cucc1*bw24)*(bw12-tw*bw11));
  Values::v["GH1N13"] = -gx/2.0 * ((cdcc1*bw13-cucc1*bw14)*(bw32-tw*bw31)
                 + (cdcc1*bw33-cucc1*bw34)*(bw12-tw*bw11));
  Values::v["GH1N14"] = -gx/2.0 * ((cdcc1*bw13-cucc1*bw14)*(bw42-tw*bw41)
                 + (cdcc1*bw43-cucc1*bw44)*(bw12-tw*bw11));
  Values::v["GH1N21"] = -gx/2.0 * ((cdcc1*bw23-cucc1*bw24)*(bw12-tw*bw11)
                 + (cdcc1*bw13-cucc1*bw14)*(bw22-tw*bw21));
  Values::v["GH1N22"] = -gx/2.0 * ((cdcc1*bw23-cucc1*bw24)*(bw22-tw*bw21)
                 + (cdcc1*bw23-cucc1*bw24)*(bw22-tw*bw21));
  Values::v["GH1N23"] = -gx/2.0 * ((cdcc1*bw23-cucc1*bw24)*(bw32-tw*bw31)
                 + (cdcc1*bw33-cucc1*bw34)*(bw22-tw*bw21));
  Values::v["GH1N24"] = -gx/2.0 * ((cdcc1*bw23-cucc1*bw24)*(bw42-tw*bw41)
                 + (cdcc1*bw43-cucc1*bw44)*(bw22-tw*bw21));
  Values::v["GH1N31"] = -gx/2.0 * ((cdcc1*bw33-cucc1*bw34)*(bw12-tw*bw11)
                 + (cdcc1*bw13-cucc1*bw14)*(bw32-tw*bw31));
  Values::v["GH1N32"] = -gx/2.0 * ((cdcc1*bw33-cucc1*bw34)*(bw22-tw*bw21)
                 + (cdcc1*bw23-cucc1*bw24)*(bw32-tw*bw31));
  Values::v["GH1N33"] = -gx/2.0 * ((cdcc1*bw33-cucc1*bw34)*(bw32-tw*bw31)
                 + (cdcc1*bw33-cucc1*bw34)*(bw32-tw*bw31));
  Values::v["GH1N34"] = -gx/2.0 * ((cdcc1*bw33-cucc1*bw34)*(bw42-tw*bw41)
                 + (cdcc1*bw43-cucc1*bw44)*(bw32-tw*bw31));
  Values::v["GH1N41"] = -gx/2.0 * ((cdcc1*bw43-cucc1*bw44)*(bw12-tw*bw11)
                 + (cdcc1*bw13-cucc1*bw14)*(bw42-tw*bw41));
  Values::v["GH1N42"] = -gx/2.0 * ((cdcc1*bw43-cucc1*bw44)*(bw22-tw*bw21)
                 + (cdcc1*bw23-cucc1*bw24)*(bw42-tw*bw41));
  Values::v["GH1N43"] = -gx/2.0 * ((cdcc1*bw43-cucc1*bw44)*(bw32-tw*bw31)
                 + (cdcc1*bw33-cucc1*bw34)*(bw42-tw*bw41));
  Values::v["GH1N44"] = -gx/2.0 * ((cdcc1*bw43-cucc1*bw44)*(bw42-tw*bw41)
                 + (cdcc1*bw43-cucc1*bw44)*(bw42-tw*bw41));
  Values::v["GH2N11"] = -gx/2.0 * ((cdcc2*bw13-cucc2*bw14)*(bw12-tw*bw11)
                 + (cdcc2*bw13-cucc2*bw14)*(bw12-tw*bw11));
  Values::v["GH2N12"] = -gx/2.0 * ((cdcc2*bw13-cucc2*bw14)*(bw22-tw*bw21)
                 + (cdcc2*bw23-cucc2*bw24)*(bw12-tw*bw11));
  Values::v["GH2N13"] = -gx/2.0 * ((cdcc2*bw13-cucc2*bw14)*(bw32-tw*bw31)
                 + (cdcc2*bw33-cucc2*bw34)*(bw12-tw*bw11));
  Values::v["GH2N14"] = -gx/2.0 * ((cdcc2*bw13-cucc2*bw14)*(bw42-tw*bw41)
                 + (cdcc2*bw43-cucc2*bw44)*(bw12-tw*bw11));
  Values::v["GH2N21"] = -gx/2.0 * ((cdcc2*bw23-cucc2*bw24)*(bw12-tw*bw11)
                 + (cdcc2*bw13-cucc2*bw14)*(bw22-tw*bw21));
  Values::v["GH2N22"] = -gx/2.0 * ((cdcc2*bw23-cucc2*bw24)*(bw22-tw*bw21)
                 + (cdcc2*bw23-cucc2*bw24)*(bw22-tw*bw21));
  Values::v["GH2N23"] = -gx/2.0 * ((cdcc2*bw23-cucc2*bw24)*(bw32-tw*bw31)
                 + (cdcc2*bw33-cucc2*bw34)*(bw22-tw*bw21));
  Values::v["GH2N24"] = -gx/2.0 * ((cdcc2*bw23-cucc2*bw24)*(bw42-tw*bw41)
                 + (cdcc2*bw43-cucc2*bw44)*(bw22-tw*bw21));
  Values::v["GH2N31"] = -gx/2.0 * ((cdcc2*bw33-cucc2*bw34)*(bw12-tw*bw11)
                 + (cdcc2*bw13-cucc2*bw14)*(bw32-tw*bw31));
  Values::v["GH2N32"] = -gx/2.0 * ((cdcc2*bw33-cucc2*bw34)*(bw22-tw*bw21)
                 + (cdcc2*bw23-cucc2*bw24)*(bw32-tw*bw31));
  Values::v["GH2N33"] = -gx/2.0 * ((cdcc2*bw33-cucc2*bw34)*(bw32-tw*bw31)
                 + (cdcc2*bw33-cucc2*bw34)*(bw32-tw*bw31));
  Values::v["GH2N34"] = -gx/2.0 * ((cdcc2*bw33-cucc2*bw34)*(bw42-tw*bw41)
                 + (cdcc2*bw43-cucc2*bw44)*(bw32-tw*bw31));
  Values::v["GH2N41"] = -gx/2.0 * ((cdcc2*bw43-cucc2*bw44)*(bw12-tw*bw11)
                 + (cdcc2*bw13-cucc2*bw14)*(bw42-tw*bw41));
  Values::v["GH2N42"] = -gx/2.0 * ((cdcc2*bw43-cucc2*bw44)*(bw22-tw*bw21)
                 + (cdcc2*bw23-cucc2*bw24)*(bw42-tw*bw41));
  Values::v["GH2N43"] = -gx/2.0 * ((cdcc2*bw43-cucc2*bw44)*(bw32-tw*bw31)
                 + (cdcc2*bw33-cucc2*bw34)*(bw42-tw*bw41));
  Values::v["GH2N44"] = -gx/2.0 * ((cdcc2*bw43-cucc2*bw44)*(bw42-tw*bw41)
                 + (cdcc2*bw43-cucc2*bw44)*(bw42-tw*bw41));
  Values::v["GH3N11"] = -gx/2.0 * ((cdcc3*bw13-cucc3*bw14)*(bw12-tw*bw11)
                 + (cdcc3*bw13-cucc3*bw14)*(bw12-tw*bw11));
  Values::v["GH3N12"] = -gx/2.0 * ((cdcc3*bw13-cucc3*bw14)*(bw22-tw*bw21)
                 + (cdcc3*bw23-cucc3*bw24)*(bw12-tw*bw11));
  Values::v["GH3N13"] = -gx/2.0 * ((cdcc3*bw13-cucc3*bw14)*(bw32-tw*bw31)
                 + (cdcc3*bw33-cucc3*bw34)*(bw12-tw*bw11));
  Values::v["GH3N14"] = -gx/2.0 * ((cdcc3*bw13-cucc3*bw14)*(bw42-tw*bw41)
                 + (cdcc3*bw43-cucc3*bw44)*(bw12-tw*bw11));
  Values::v["GH3N21"] = -gx/2.0 * ((cdcc3*bw23-cucc3*bw24)*(bw12-tw*bw11)
                 + (cdcc3*bw13-cucc3*bw14)*(bw22-tw*bw21));
  Values::v["GH3N22"] = -gx/2.0 * ((cdcc3*bw23-cucc3*bw24)*(bw22-tw*bw21)
                 + (cdcc3*bw23-cucc3*bw24)*(bw22-tw*bw21));
  Values::v["GH3N23"] = -gx/2.0 * ((cdcc3*bw23-cucc3*bw24)*(bw32-tw*bw31)
                 + (cdcc3*bw33-cucc3*bw34)*(bw22-tw*bw21));
  Values::v["GH3N24"] = -gx/2.0 * ((cdcc3*bw23-cucc3*bw24)*(bw42-tw*bw41)
                 + (cdcc3*bw43-cucc3*bw44)*(bw22-tw*bw21));
  Values::v["GH3N31"] = -gx/2.0 * ((cdcc3*bw33-cucc3*bw34)*(bw12-tw*bw11)
                 + (cdcc3*bw13-cucc3*bw14)*(bw32-tw*bw31));
  Values::v["GH3N32"] = -gx/2.0 * ((cdcc3*bw33-cucc3*bw34)*(bw22-tw*bw21)
                 + (cdcc3*bw23-cucc3*bw24)*(bw32-tw*bw31));
  Values::v["GH3N33"] = -gx/2.0 * ((cdcc3*bw33-cucc3*bw34)*(bw32-tw*bw31)
                 + (cdcc3*bw33-cucc3*bw34)*(bw32-tw*bw31));
  Values::v["GH3N34"] = -gx/2.0 * ((cdcc3*bw33-cucc3*bw34)*(bw42-tw*bw41)
                 + (cdcc3*bw43-cucc3*bw44)*(bw32-tw*bw31));
  Values::v["GH3N41"] = -gx/2.0 * ((cdcc3*bw43-cucc3*bw44)*(bw12-tw*bw11)
                 + (cdcc3*bw13-cucc3*bw14)*(bw42-tw*bw41));
  Values::v["GH3N42"] = -gx/2.0 * ((cdcc3*bw43-cucc3*bw44)*(bw22-tw*bw21)
                 + (cdcc3*bw23-cucc3*bw24)*(bw42-tw*bw41));
  Values::v["GH3N43"] = -gx/2.0 * ((cdcc3*bw43-cucc3*bw44)*(bw32-tw*bw31)
                 + (cdcc3*bw33-cucc3*bw34)*(bw42-tw*bw41));
  Values::v["GH3N44"] = -gx/2.0 * ((cdcc3*bw43-cucc3*bw44)*(bw42-tw*bw41)
                 + (cdcc3*bw43-cucc3*bw44)*(bw42-tw*bw41));
  Values::v2["GH1N11"] = Values::v["GH1N11"];
  Values::v2["GH1N12"] = Values::v["GH1N21"];
  Values::v2["GH1N13"] = Values::v["GH1N31"];
  Values::v2["GH1N14"] = Values::v["GH1N41"];
  Values::v2["GH1N21"] = Values::v["GH1N12"];
  Values::v2["GH1N22"] = Values::v["GH1N22"];
  Values::v2["GH1N23"] = Values::v["GH1N32"];
  Values::v2["GH1N24"] = Values::v["GH1N42"];
  Values::v2["GH1N31"] = Values::v["GH1N13"];
  Values::v2["GH1N32"] = Values::v["GH1N23"];
  Values::v2["GH1N33"] = Values::v["GH1N33"];
  Values::v2["GH1N34"] = Values::v["GH1N43"];
  Values::v2["GH1N41"] = Values::v["GH1N14"];
  Values::v2["GH1N42"] = Values::v["GH1N24"];
  Values::v2["GH1N43"] = Values::v["GH1N34"];
  Values::v2["GH1N44"] = Values::v["GH1N44"];
  Values::v2["GH2N11"] = Values::v["GH2N11"];
  Values::v2["GH2N12"] = Values::v["GH2N21"];
  Values::v2["GH2N13"] = Values::v["GH2N31"];
  Values::v2["GH2N14"] = Values::v["GH2N41"];
  Values::v2["GH2N21"] = Values::v["GH2N12"];
  Values::v2["GH2N22"] = Values::v["GH2N22"];
  Values::v2["GH2N23"] = Values::v["GH2N32"];
  Values::v2["GH2N24"] = Values::v["GH2N42"];
  Values::v2["GH2N31"] = Values::v["GH2N13"];
  Values::v2["GH2N32"] = Values::v["GH2N23"];
  Values::v2["GH2N33"] = Values::v["GH2N33"];
  Values::v2["GH2N34"] = Values::v["GH2N43"];
  Values::v2["GH2N41"] = Values::v["GH2N14"];
  Values::v2["GH2N42"] = Values::v["GH2N24"];
  Values::v2["GH2N43"] = Values::v["GH2N34"];
  Values::v2["GH2N44"] = Values::v["GH2N44"];
  Values::v2["GH3N11"] = -Values::v["GH3N11"];
  Values::v2["GH3N12"] = -Values::v["GH3N21"];
  Values::v2["GH3N13"] = -Values::v["GH3N31"];
  Values::v2["GH3N14"] = -Values::v["GH3N41"];
  Values::v2["GH3N21"] = -Values::v["GH3N12"];
  Values::v2["GH3N22"] = -Values::v["GH3N22"];
  Values::v2["GH3N23"] = -Values::v["GH3N32"];
  Values::v2["GH3N24"] = -Values::v["GH3N42"];
  Values::v2["GH3N31"] = -Values::v["GH3N13"];
  Values::v2["GH3N32"] = -Values::v["GH3N23"];
  Values::v2["GH3N33"] = -Values::v["GH3N33"];
  Values::v2["GH3N34"] = -Values::v["GH3N43"];
  Values::v2["GH3N41"] = -Values::v["GH3N14"];
  Values::v2["GH3N42"] = -Values::v["GH3N24"];
  Values::v2["GH3N43"] = -Values::v["GH3N34"];
  Values::v2["GH3N44"] = -Values::v["GH3N44"];
  Values::v["GHN1X1"] = gx*cb*(-bw14*vv11-(bw12+tw*bw11)*vv12/rt2);
  Values::v2["GHN1X1"] = -gx*sb*(bw13*uu11-(bw12+tw*bw11)*uu12/rt2);
  Values::v["GHN2X1"] = gx*cb*(-bw24*vv11-(bw22+tw*bw21)*vv12/rt2);
  Values::v2["GHN2X1"] = -gx*sb*(bw23*uu11-(bw22+tw*bw21)*uu12/rt2);
  Values::v["GHN3X1"] = gx*cb*(-bw34*vv11-(bw32+tw*bw31)*vv12/rt2);
  Values::v2["GHN3X1"] = -gx*sb*(bw33*uu11-(bw32+tw*bw31)*uu12/rt2);
  Values::v["GHN4X1"] = gx*cb*(-bw44*vv11-(bw42+tw*bw41)*vv12/rt2);
  Values::v2["GHN4X1"] = -gx*sb*(bw43*uu11-(bw42+tw*bw41)*uu12/rt2);
  Values::v["GHN1X2"] = gx*cb*(-bw14*vv21-(bw12+tw*bw11)*vv22/rt2);
  Values::v2["GHN1X2"] = -gx*sb*(bw13*uu21-(bw12+tw*bw11)*uu22/rt2);
  Values::v["GHN2X2"] = gx*cb*(-bw24*vv21-(bw22+tw*bw21)*vv22/rt2);
  Values::v2["GHN2X2"] = -gx*sb*(bw23*uu21-(bw22+tw*bw21)*uu22/rt2);
  Values::v["GHN3X2"] = gx*cb*(-bw34*vv21-(bw32+tw*bw31)*vv22/rt2);
  Values::v2["GHN3X2"] = -gx*sb*(bw33*uu21-(bw32+tw*bw31)*uu22/rt2);
  Values::v["GHN4X2"] = gx*cb*(-bw44*vv21-(bw42+tw*bw41)*vv22/rt2);
  Values::v2["GHN4X2"] = -gx*sb*(bw43*uu21-(bw42+tw*bw41)*uu22/rt2);
  Values::v["GHX1N1"] = Values::v2["GHN1X1"];
  Values::v2["GHX1N1"] = Values::v["GHN1X1"];
  Values::v["GHX1N2"] = Values::v2["GHN2X1"];
  Values::v2["GHX1N2"] = Values::v["GHN2X1"];
  Values::v["GHX1N3"] = Values::v2["GHN3X1"];
  Values::v2["GHX1N3"] = Values::v["GHN3X1"];
  Values::v["GHX1N4"] = Values::v2["GHN4X1"];
  Values::v2["GHX1N4"] = Values::v["GHN4X1"];
  Values::v["GHX2N1"] = Values::v2["GHN1X2"];
  Values::v2["GHX2N1"] = Values::v["GHN1X2"];
  Values::v["GHX2N2"] = Values::v2["GHN2X2"];
  Values::v2["GHX2N2"] = Values::v["GHN2X2"];
  Values::v["GHX2N3"] = Values::v2["GHN3X2"];
  Values::v2["GHX2N3"] = Values::v["GHN3X2"];
  Values::v["GHX2N4"] = Values::v2["GHN4X2"];
  Values::v2["GHX2N4"] = Values::v["GHN4X2"];
}
