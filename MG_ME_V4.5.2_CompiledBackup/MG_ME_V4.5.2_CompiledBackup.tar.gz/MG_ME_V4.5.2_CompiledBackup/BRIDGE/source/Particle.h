#ifndef PARTICLE_H
#define PARTICLE_H

#include <list>
#include <string>
#include <map>
#include "Values.h"

class DecayMode;

class Particle {
 public:
  // Constructors
 Particle() : 
  twice_spin(-1), mass("NULL"), width("NULL"), name("NULL"), anti("NULL"), 
    ncolors(0), fermion_number(0), ID_code(-9999) {};
 Particle(int spinTimesTwo, std::string theMass, std::string theWidth,
	  std::string theName, std::string theAntiparticle, int numColors, 
	  int fermionNum, int theID) :
  twice_spin(spinTimesTwo), mass(theMass), width(theWidth), name(theName), 
    anti(theAntiparticle), ncolors(numColors), 
    fermion_number(fermionNum), ID_code(theID) {};

  // Access information
  int TwiceSpin();
  int NColors();
  int NHelicities();
  std::string MassParam();
  double Mass();
  std::string WidthParam();
  double Width();
  std::string Name();
  std::string Antiparticle();
  int FermionNumber(); // note: 2 for Majorana
  int IDCode();

  // Change information
  void SetTwiceSpin(int spinTimesTwo);
  void SetNColors(int numColors);
  void SetMass(std::string theMass);
  void SetWidth(std::string theWidth);
  void SetName(std::string theName);
  void SetAnti(std::string theAntiparticle);
  void SetFermionNumber(int fermionNum);
  void SetIDCode(int theID);

  // This is the global particle list.
  static std::map<std::string, Particle> pl;

  // This global list gives a particle name from an
  // ID code.
  static std::map<int, std::string> plFromID;

  // Read in particles.dat
  static void ParseMGFile(std::string filename);

 protected:
  int twice_spin;
  std::string mass;
  std::string width;
  std::string name;
  std::string anti;
  int ncolors;
  int fermion_number;
  int ID_code;
};

#endif
