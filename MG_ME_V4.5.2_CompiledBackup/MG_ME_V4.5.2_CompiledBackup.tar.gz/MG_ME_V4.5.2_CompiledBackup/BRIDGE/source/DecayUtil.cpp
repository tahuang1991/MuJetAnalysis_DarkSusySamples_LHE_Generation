#include "DecayUtil.h"
#include "Particle.h"

// based on routine in decay_mom.f
double LambdaMG(double s, double ma2, double mb2) {
  return s*s + ma2*ma2 + mb2*mb2 - 2.*s*ma2 - 2*s*mb2 - 2*ma2*mb2;
}
