#include "Values.h"
#include "Error.h"
#include <fstream>
#include <vector>
#include <cassert>
#include <sstream>
#include <iostream>
using namespace std;

std::map< std::string, std::complex<double> > Values::v;
std::map< std::string, std::complex<double> > Values::v2;

// general format in couplings_check.txt:
// Name Re(v) Im(v) Re(v2) Im(v2)

void Values::ParseMGFile(std::string filename) {
  ifstream in(filename.c_str());
  string line;
  int lineNum = 0;
  complex<double> cI(0.0,1.0);
  while(getline(in,line)) {
    lineNum++;
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
	words.push_back(line.substr(lastPos, pos-lastPos));
	lastPos = line.find_first_not_of(" ",pos);
	pos = line.find_first_of(" ",lastPos);
      }
      assert(words.size() >= 2);
      double re1=0.0,re2=0.0,im1=0.0,im2=0.0;
      istringstream getRe1(words[1]);
      if(!(getRe1 >> re1)) {
	BadInputError badinput(filename, lineNum, line,
			       "Value does not seem to be a real number.");
	badinput.report(cerr);
      }
      if(words.size() >= 3) {
	istringstream getIm1(words[2]);
	if(!(getIm1 >> im1)) {
	  BadInputError badinput(filename, lineNum, line,
				 "Value does not seem to be a real number.");
	  badinput.report(cerr);
	}
      }
      if(words.size() >= 4) {
	istringstream getRe2(words[3]);
	if(!(getRe2 >> re2)) {
	  BadInputError badinput(filename, lineNum, line,
				 "Value does not seem to be a real number.");
	  badinput.report(cerr);
	}
      }
      if(words.size() >= 5) {
	istringstream getIm2(words[4]);
	if(!(getIm2 >> im2)) {
	  BadInputError badinput(filename, lineNum, line,
				 "Value does not seem to be a real number.");
	  badinput.report(cerr);
	}
      }
      complex<double> val1(re1,im1);
      complex<double> val2(re2,im2);
      // force the coupling name to be all caps...
      for(int c = 0; c < words[0].length(); c++) {
	words[0][c] = toupper(words[0][c]);
      }
      Values::v[words[0]] = val1;
      Values::v2[words[0]] = val2;
    }
  }
}
