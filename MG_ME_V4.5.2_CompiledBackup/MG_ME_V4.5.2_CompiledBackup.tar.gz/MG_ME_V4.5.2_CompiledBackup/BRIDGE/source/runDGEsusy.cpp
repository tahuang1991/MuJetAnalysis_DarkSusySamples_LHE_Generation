#include "BRI.h"
#include "DGE.h"
#include <iostream>
#include <fstream>
#include "SLHArw.h"
#include "SUSYpara.h"
#include "batchhelper.h"
using namespace std;

int main(int argc, char *argv[]) {
  vector<string> pargs;
  if(argc>1)
  {
	 if(rundgebatchsusy(argc,argv,pargs)==0)
		return 0;
  }
  bool batch;
  if(pargs.size()!=0)
	  batch=true;
  else
	  batch=false;

  // read parameters
  SLHA temp;
  
  string particlefile;
  if(batch)
  {
	  particlefile=pargs[0];
  }
  else
  {
  cout << "Name of particle file (input/mssmparticles.dat): ";
  getline(cin,particlefile);
  }
  checkfile(particlefile);
  if(particlefile == "") particlefile = "input/mssmparticles.dat";
  Particle::ParseMGFile(particlefile);
  
  string parameterfile;
  if(batch)
  {
	  parameterfile=pargs[1];
  }
  else
  {
  cout << "Name of the SLHA formatted spectrum file (input/param_card.dat): ";
  getline(cin,parameterfile);
  }
  checkfile(parameterfile);
  if(parameterfile == "") parameterfile = "input/param_card.dat";
  
  ifstream susyparam(parameterfile.c_str());
  read_SLHA(temp,susyparam);
  SUSYpara(temp);
  
  string interactionsfile;
  if(batch)
  {
	  interactionsfile=pargs[2];
  }
  else
  {
  cout << "Name of interactions file (input/mssminteractions.dat): ";
  getline(cin,interactionsfile);
  }
  checkfile(interactionsfile);
  if(interactionsfile == "") interactionsfile = "input/mssminteractions.dat";
  Vertex::ParseMGFile(interactionsfile);

  string inputFile;
  string outputFile;
  if(batch)
  {
	  inputFile=pargs[3];
	  outputFile=pargs[4];
  }
  else
  {
  cout << "What is the name of the input event file? \n";
  getline(cin,inputFile);
  cout << "What is the name of the output event file? \n";
  getline(cin,outputFile);
  }
  
  string directory;
  if(batch)
  {
	  directory=pargs[5];
  }
  else
  {
  cout << "Please enter the (relative) directory in which the grids are saved.\n(Include the / at the end; the directory must already exist): ";
  getline(cin,directory);
  }
  if(directory == "") directory = "results/";

  VegasRandom vr;
  string randseed;
  if(batch)
  {
	  randseed=pargs[6];
  }
  else
  {
  cout << "Please enter a random number seed or write 'time' to use the time\n";
  cin >> randseed;
  }
  unsigned int theseedtouse;
  istringstream iss(randseed);
  if(!(iss >> theseedtouse).fail()) {
    cout << "We understood that as " << theseedtouse << ", using that seed\n";
    vr.Seed(theseedtouse);
  } else {
    cout << "Using the time.\n";
  }

  DGE dge(&vr);
  dge.setDirectory(directory);
  dge.setEventFile(inputFile);
  dge.setOutputFile(outputFile);
  int mode;
  int inmode;
  if(batch)
  {
  mode=atoi(pargs[7].c_str());
  inmode=1;
  }
  else
  {
  cout << "Decaying file " << inputFile << ".\n";
  cout << "Choose a mode: \n";
  cout << "  1. Decay a particular particle.\n";
  cout << "  2. Decay down to a set of final-state particles.\n";
  cout << "  3. Decay using a specified set of decay modes.\n";
  cout << "Which mode? ";
  cin >> mode;
  }


  if(mode == 1) {
    cout << "Which particle do you want to decay? ";
    string theParticle;
    cin >> theParticle;
    dge.decayParticle(theParticle);
  } else if(mode == 2) {
	if(!batch)
	{
    cout << "Choose an input method: \n";
    cout << "  1. Read a file listing final-state particles.\n";
    cout << "  2. Enter the list of final-state particles manually.\n";
    cout << "Which mode? ";
    cin >> inmode;
	}
    if(inmode == 1) {
	  string particleList;
	  if(batch)
	  {
		particleList=pargs[8];
	  }
	  else
	  {
      cout << "Please enter the file name: ";
      cin >> particleList;
	  }
      dge.readFinalParticles(particleList);
    } else if(inmode == 2) {
      string particleName = "";
      while(particleName != "END") {
    cout << "Enter a final-state particle name, or \"END\" to finish: ";
    cin >> particleName;
    if(particleName != "END") {
      dge.addFinalParticle(particleName);
    }
      }
      cout << "Would you like to save the list of final-state particles? (Y/N) ";
      string response;
      cin >> response;
      if(response == "Y" || response == "y") {
    cout << "What file name do you want to save to? ";
    string listFileName;
    cin >> listFileName;
    dge.writeFinalParticles(listFileName);
      }
    }
    dge.decayFileCompletely();
  } else if(mode == 3) {
	if(!batch)
	{
    cout << "Choose an input method: \n";
    cout << "  1. Read a file listing decay modes to use.\n";
    cout << "  2. Enter the list of decay modes manually.\n";
    cout << "Which mode? ";
    cin >> inmode;
	}
    if(inmode == 1) {
	  string modeList;
	  if(batch)
	  {
		  modeList=pargs[8];
	  }
	  else
	  {
      cout << "Please enter the file name: ";
      cin >> modeList;
	  }
      dge.readDecaysToUse(modeList);
    } else if(inmode == 2) {
      string theMode = "";
      getline(cin,theMode);
      while(theMode != "END") {
    cout << "Enter a decay mode in the format \"t w+ b\" (parent first), or \"END\" to finish: ";
    getline(cin, theMode);
    if(theMode != "END") {
      vector<string> theModeAsList;
      string::size_type lastPos = theMode.find_first_not_of(" ",0);
      string::size_type pos = theMode.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
        theModeAsList.push_back(theMode.substr(lastPos, pos-lastPos));
        lastPos = theMode.find_first_not_of(" ",pos);
        pos = theMode.find_first_of(" ",lastPos);
      }
      dge.addDecayToUse(theModeAsList);
    }
      }
      cout << "Would you like to save the list of decay modes? (Y/N) ";
      string response;
      cin >> response;
      if(response == "Y" || response == "y") {
    cout << "What file name do you want to save to? ";
    string listFileName;
    cin >> listFileName;
    dge.writeDecaysToUse(listFileName);
      }
    }
    dge.decayFileSelected();
  }
  cout << "Results written to " << outputFile << ".\n";

  return 0;
}
