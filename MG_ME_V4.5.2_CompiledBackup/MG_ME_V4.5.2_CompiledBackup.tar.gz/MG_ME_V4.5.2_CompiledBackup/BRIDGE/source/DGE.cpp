#include "DGE.h"
#include "BRI.h"
#include "DecayDriver.h"
#include "DecayBuilder.h"
#include "DecayEvents.h"
#include "Event.h"
#include "EventParticle.h"
#include "rw_events.h"
#include "Vegas.h"
#include <iostream>
#include <fstream>
using namespace std;

void DGE::setEventFile(string eventFile) {
  origFile = eventFile;
  workingInputFile = eventFile;
}

void DGE::setOutputFile(string outputFile) {
  endFile = outputFile;
  workingOutputFile = outputFile;
}

// TODO: replace "cout" with better error output
//       replace "return false" with something more intelligent

bool DGE::decayParticle(string toDecay) {
  cout << "Now decaying particle " << toDecay << "\n";
  BRI bri(toDecay, getRandom, directory);
  bri.buildModeList();
  if(!bri.readBRTable()) {
    cout << "Unable to read branching ratio table for particle " 
	 << toDecay << "\n";
    return false;
  }
  if(!bri.checkForGrids()) {
    cout << "Unable to read decay grids for particle "
	 << toDecay << "\n";
    return false;
  }
  int nmodes = bri.allModes.size();
  if(nmodes == 0) {
    cout << "Particle has no decay modes in table.\n";
    cout << "Nothing to do, exiting\n";
    return false;
  }
  if(!bri.buildDecayDrivers()) {
    cout << "Failed to build decay drivers, probably a decay table is missing.\n";
    return false;
  }

  // open the file we are reading.
  ifstream eventi(workingInputFile.c_str());
  vector<string> banner,newbanner;
  vector<vector<string> > word_banner;
  ios::pos_type banner_end;
  Events_Info banner_info;
  banner=read_banner(eventi,banner_end,banner_info);
  word_banner=split_banner(banner);
  if(extract_banner_info(word_banner,banner_info)==false)
  {
    cout << "Error reading banner";
    return false;
  }
  ofstream evento(workingOutputFile.c_str(),ofstream::trunc);
  write_banner(evento,banner,newbanner);
  //  evento << "# Random number seed: " << getRandom->GetUsedSeed() << "\n";

  // dummy boost vector -- in this case, do nothing interesting
  FourVector boost;
  boost.P[0] = 1.;
  for(int i = 1; i < 4; i++) {
    boost.P[i] = 0.;
  }

  // Now, go through each event and decay the particle
  Event workingEvent;
  cout << "Number of events: " << banner_info.n_events << endl;
  for(int l = 1; l < banner_info.n_events; l++) {
    if(l % 1000 == 0) { 
      cout << "Decaying event " << l << "\n";
    }
    workingEvent.read_event(eventi, banner_info.event_format);
    vector<EventParticle> theParticles = workingEvent.get_particles();
    for(int j = 0; j < theParticles.size(); j++) {
      string particleName = Particle::plFromID[theParticles[j].idup()];
      if(particleName == toDecay) {
	int mode = bri.getRandomMode();

	// if we decay a Majorana fermion, need to be careful in order to get
	// the angular distributions right. this is a clumsy hack to do that.
	if(Particle::pl[particleName].FermionNumber() == 2) {
          // look for mother particle
	  if(theParticles[j].mothup1() > 2 && theParticles[j].mothup2() == 0) {
	    int p = theParticles[j].mothup1()-1;
	    string motherName = Particle::plFromID[theParticles[p].idup()];
	    int motherFN = Particle::pl[motherName].FermionNumber();
	    for(int k = 0; k < bri.allModes[mode].dm->NumberDaughters(); k++) {
	      string daughterName = bri.allModes[mode].dm->ListDaughters()[k];
	      int daughterFN = Particle::pl[daughterName].FermionNumber();
	      if(daughterFN != 0) {
		if((motherFN == 1 && daughterFN == -1) || (motherFN == -1 && daughterFN == 1)) {
                  // helicity flip
		  theParticles[j].Helicity = -theParticles[j].Helicity;
		} 
		break;
	      } 
	    }
	  }
	}

	// pass 1.0 as the branching ratio, because we are using all
	// decay modes according to BR
	DecayEvent(workingEvent, j, bri.allModes[mode].dm, 
                   bri.vegases[mode], 1.0, boost);
      }
    }
    workingEvent.write_event(evento, banner_info.event_format);
  }
  eventi.close();
  evento.close();

  return true;
}

bool DGE::decayFileCompletely() {
  // open the file we are reading.
  ifstream eventi(origFile.c_str());
  vector<string> banner,newbanner;
  vector<vector<string> > word_banner;
  ios::pos_type banner_end;
  Events_Info banner_info;
  banner=read_banner(eventi,banner_end,banner_info);
  word_banner=split_banner(banner);
  if(extract_banner_info(word_banner,banner_info)==false)
  {
    cout << "Error reading banner";
    return false;
  }
  ofstream evento(endFile.c_str(),ofstream::trunc);
  write_banner(evento,banner,newbanner);

  vector<BRI> decayManager;

  cout << "Number of events to decay: " << banner_info.n_events << "\n";
  Event workingEvent;
  for(int i = 1; i < banner_info.n_events; i++) {
    if(i % 1000 == 0) { 
      cout << "Decaying event " << i << "\n";
    }
    workingEvent.read_event(eventi, banner_info.event_format);
    bool thisEventDecayed = false;
    while(!thisEventDecayed) {
      thisEventDecayed = true;
      vector<EventParticle> theParticles = workingEvent.get_particles();
      for(int j = 0; j < theParticles.size(); j++) {
	// if this is an initial state particle, do not decay it:
	// TODO: how do we use status code? make interface intuitive?
	// check if this particle has already been decayed:
	bool hasDaughters = false;
//	if(theParticles[j].idup() < -500) {
//	  cout << "Particle "<< j+1 << " ID: "<< theParticles[j].idup()<< "\n";
//	  cout << " ? That's nonsense, exiting\n";
//	  return false;
//	}
// Decaying particles only with final states for sherpa PM 12/2/08
        if(theParticles[j].istup()==2) continue;
	for(int k = 0; k < theParticles.size(); k++) {
	  if(theParticles[k].mothup1() == (j+1) || 
	     theParticles[k].mothup2() == (j+1)) {
	    hasDaughters = true;
	  }
	} 
	if(hasDaughters) continue;
	string particleName = Particle::plFromID[theParticles[j].idup()];
	list<string>::iterator li;
	li = find(finalParticles.begin(), finalParticles.end(), particleName);
	if(li != finalParticles.end()) {
	  // do nothing; thisEventDecayed remains true only if
	  // we do nothing for every particle, in which case the
	  // event contains only final-state particles
	} else {
	  thisEventDecayed = false;

	  int index=-1;
	  for(int part=0; part<decayManager.size(); part++) {
	    if(decayManager[part].particleToDecay == particleName) {
	      index=part;
	      break;
	    }
	  }

	  if(index == -1) {
	    // no BRI for this particle yet, make one
	    cout << "Encountered a particle of type " << particleName
		 << " to decay.\n";
	    BRI bri(particleName, getRandom, directory);
	    bri.buildModeList();
	    if(!bri.readBRTable()) {
              cout << "No decay table found, so treating " << particleName 
                   << " as stable final-state particle\n";
              finalParticles.push_back(particleName);
              continue;
            } else if(bri.allModes.size() == 0) {
	      cout << "Decay table is empty, so treating " << particleName 
		   << " as stable final-state particle\n";
              finalParticles.push_back(particleName);
              continue;
	    } else {
	      bri.buildDecayDrivers();
	      decayManager.push_back(bri);
	      index = decayManager.size()-1;
            }
	  }

	  FourVector boost;
	  // look for mother highest up the chain
	  int p = j;
	  while(theParticles[p].mothup1() > 2 && theParticles[p].mothup2() == 0)
	  {
	    p = theParticles[p].mothup1()-1;
	  }
	  boost.P[0] = theParticles[p].P[0];
	  for(int l = 1; l < 4; l++) {
	    boost.P[l] = -theParticles[p].P[l];
	  }

	  int mode = decayManager[index].getRandomMode();

          // if we decay a Majorana fermion, need to be careful in order to get
          // the angular distributions right. this is a clumsy hack to do that.
          if(Particle::pl[particleName].FermionNumber() == 2) {
            // look for mother particle
	    if(theParticles[j].mothup1() > 2 && theParticles[j].mothup2() == 0) {
	      int p = theParticles[j].mothup1()-1;
	      string motherName = Particle::plFromID[theParticles[p].idup()];
              int motherFN = Particle::pl[motherName].FermionNumber();
	      for(int k = 0; k < decayManager[index].allModes[mode].dm->NumberDaughters(); k++) {
		string daughterName = decayManager[index].allModes[mode].dm->ListDaughters()[k];
                int daughterFN = Particle::pl[daughterName].FermionNumber();
                if(daughterFN != 0) {
		  if((motherFN == 1 && daughterFN == -1) || (motherFN == -1 && daughterFN == 1)) {
                    // helicity flip
		    theParticles[j].Helicity = -theParticles[j].Helicity;
		  } 
		  break;
		} 
	      }
            }
	  }

	  // pass 1.0 as the branching ratio, because we are using all
	  // decay modes according to BR
	  DecayEvent(workingEvent, j, 
                     decayManager[index].allModes[mode].dm,
		     decayManager[index].vegases[mode], 
                     1.0, boost);

	  break; // repeat the loop
	}
      }
    }
    workingEvent.write_event(evento, banner_info.event_format);
  }

  eventi.close();
  evento.close();
  return true;
}

bool DGE::decayFileSelected() {
  // open the file we are reading.
  ifstream eventi(origFile.c_str());
  vector<string> banner,newbanner;
  vector<vector<string> > word_banner;
  ios::pos_type banner_end;
  Events_Info banner_info;
  banner=read_banner(eventi,banner_end,banner_info);
  word_banner=split_banner(banner);
  if(extract_banner_info(word_banner,banner_info)==false)
  {
    cout << "Error reading banner";
    return false;
  }
  ofstream evento(endFile.c_str(),ofstream::trunc);
  write_banner(evento,banner,newbanner);

  vector<BRI> decayManager;

  cout << "Number of events to decay: " << banner_info.n_events << "\n";
  Event workingEvent;
  for(int i = 1; i < banner_info.n_events; i++) {
    if(i % 1000 == 0) { 
      cout << "Decaying event " << i << "\n";
    }
    workingEvent.read_event(eventi, banner_info.event_format);
    bool thisEventDecayed = false;
    while(!thisEventDecayed) {
      thisEventDecayed = true;
      vector<EventParticle> theParticles = workingEvent.get_particles();
      for(int j = 0; j < theParticles.size(); j++) {
	// if this is an initial state particle, do not decay it:
	// TODO: how do we use status code? make interface intuitive?
	// check if this particle has already been decayed:
	bool hasDaughters = false;
//	if(theParticles[j].idup() < -500) {
//	  cout << "Particle "<< j+1 << " ID: "<< theParticles[j].idup()<< "\n";
//	  cout << " ? That's nonsense, exiting\n";
//	  return false;
//	}
	for(int k = 0; k < theParticles.size(); k++) {
	  if(theParticles[k].mothup1() == (j+1) || 
	     theParticles[k].mothup2() == (j+1)) {
	    hasDaughters = true;
	  }
	} 
	if(hasDaughters) continue;
	string particleName = Particle::plFromID[theParticles[j].idup()];
	bool doDecay=false;
	for(int dec2use=0; dec2use<decaysToUse.size(); dec2use++) {
	  if(decaysToUse[dec2use][0] == particleName) {
	    doDecay = true;
	    break;
	  }
	}
	if(!doDecay) {
	  // do nothing; thisEventDecayed remains true only if
	  // we do nothing for every particle, in which case the
	  // event contains only final-state particles
	} else {
	  thisEventDecayed = false;

	  int index=-1;
	  for(int part=0; part<decayManager.size(); part++) {
	    if(decayManager[part].particleToDecay == particleName) {
	      index=part;
	      break;
	    }
	  }

	  if(index == -1) {
	    // no BRI for this particle yet, make one
	    cout << "Encountered a particle of type " << particleName
		 << " to decay.\n";
	    BRI bri(particleName, getRandom, directory);
            vector<DecayMode *> getDecays = DecayBuilder::GetDecayModes(particleName);
            for(vector<DecayMode *>::iterator i = getDecays.begin();
                i != getDecays.end(); i++) {
              DecayMode* dm = *i;
              int ndau = dm->NumberDaughters();
              for(int dtu = 0; dtu < decaysToUse.size(); dtu++) {
                if(decaysToUse[dtu][0] == particleName && 
                   (decaysToUse[dtu].size() == 1+ndau)) {
                  if(ndau == 2 &&
                     ((decaysToUse[dtu][1] == dm->ListDaughters()[0] &&
                       decaysToUse[dtu][2] == dm->ListDaughters()[1]) ||
                      (decaysToUse[dtu][2] == dm->ListDaughters()[0] &&
                       decaysToUse[dtu][1] == dm->ListDaughters()[1]))) {
                    bri.addMode(*i);
                    break;
                  } else if(ndau == 3 &&
                   ( (decaysToUse[dtu][1] == dm->ListDaughters()[0] &&
                      ((decaysToUse[dtu][2] == dm->ListDaughters()[1] &&
                        decaysToUse[dtu][3] == dm->ListDaughters()[2]) ||
                       (decaysToUse[dtu][2] == dm->ListDaughters()[2] &&
                        decaysToUse[dtu][3] == dm->ListDaughters()[1]) ) ) ||
                     (decaysToUse[dtu][1] == dm->ListDaughters()[1] &&
                      ((decaysToUse[dtu][2] == dm->ListDaughters()[0] &&
                        decaysToUse[dtu][3] == dm->ListDaughters()[2]) ||
                       (decaysToUse[dtu][2] == dm->ListDaughters()[2] &&
                        decaysToUse[dtu][3] == dm->ListDaughters()[0]) ) ) ||
                     (decaysToUse[dtu][1] == dm->ListDaughters()[2] && 
                      ((decaysToUse[dtu][2] == dm->ListDaughters()[1] && 
                        decaysToUse[dtu][3] == dm->ListDaughters()[0]) ||
                       (decaysToUse[dtu][2] == dm->ListDaughters()[0] &&
                        decaysToUse[dtu][3] == dm->ListDaughters()[1]) ) ) ) ) {
                    bri.addMode(*i);
                    break;
                  }
                }
              }
            }
	    if(!bri.readBRTable()) {
              cout << "No decay table found, so treating " << particleName 
                   << " as stable final-state particle\n";
              finalParticles.push_back(particleName);
              continue;
            } else if(bri.allModes.size() == 0) {
	      cout << "Decay table is empty, so treating " << particleName 
		   << " as stable final-state particle\n";
              finalParticles.push_back(particleName);
              continue;
	    } else {
	      bri.buildDecayDrivers();
	      decayManager.push_back(bri);
	      index = decayManager.size()-1;
            }
	  }

	  FourVector boost;
	  // look for mother highest up the chain
	  int p = j;
	  while(theParticles[p].mothup1() > 2 && theParticles[p].mothup2() == 0)
	  {
	    p = theParticles[p].mothup1()-1;
	  }
	  boost.P[0] = theParticles[p].P[0];
	  for(int l = 1; l < 4; l++) {
	    boost.P[l] = -theParticles[p].P[l];
	  }

	  // for the branching ratio we pass to DecayEvent, use
	  // the fraction of the total width that is included in
	  // the modes we are choosing among
	  double branchingRatio = decayManager[index].totalBR();

          // now pick a mode
	  int mode = decayManager[index].getRandomMode();
	  // if we decay a Majorana fermion, need to be careful in order to get
	  // the angular distributions right. this is a clumsy hack to do that.
	  if(Particle::pl[particleName].FermionNumber() == 2) {
	    // look for mother particle
	    if(theParticles[j].mothup1() > 2 && theParticles[j].mothup2() == 0) {
	       int p = theParticles[j].mothup1()-1;
	       string motherName = Particle::plFromID[theParticles[p].idup()];
               int motherFN = Particle::pl[motherName].FermionNumber();
	       for(int k = 0; k < decayManager[index].allModes[mode].dm->NumberDaughters(); k++) {
                 string daughterName = decayManager[index].allModes[mode].dm->ListDaughters()[k];
                 int daughterFN = Particle::pl[daughterName].FermionNumber();
                 if(daughterFN != 0) {
                   if((motherFN == 1 && daughterFN == -1) || 
                      (motherFN == -1 && daughterFN == 1)) {
                        // helicity flip
                        theParticles[j].Helicity = -theParticles[j].Helicity;
                   } 
	           break;
                 } 
	       }
	    }
	  }
          
	  DecayEvent(workingEvent, j, 
	             decayManager[index].allModes[mode].dm, 
                     decayManager[index].vegases[mode], 
	             branchingRatio, boost);
	  break; // repeat the loop
        }
      }
    }
    workingEvent.write_event(evento, banner_info.event_format);
  }

  eventi.close();
  evento.close();
  return true;
}

void DGE::addFinalParticle(string particle) {
  finalParticles.push_back(particle);
}

void DGE::addDecayToUse(vector<string> decayToUse) {
  decaysToUse.push_back(decayToUse);
}

// file input/output for lists of particles or decay modes
void DGE::readFinalParticles(string filename) {
  ifstream in(filename.c_str());
  string line;
  int lineNum = 0;
  while(getline(in,line)) {
    lineNum++;
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
	words.push_back(line.substr(lastPos, pos-lastPos));
	lastPos = line.find_first_not_of(" ",pos);
	pos = line.find_first_of(" ",lastPos);
      }
      for(int j = 0; j < words.size(); j++) {
	addFinalParticle(words[j]);
      }
    }
  }
  in.close();
}

void DGE::writeFinalParticles(string filename) {
  ofstream out(filename.c_str(), ofstream::trunc);
  out << "# list of final-state particles\n";
  for(list<string>::iterator j = finalParticles.begin();
      j != finalParticles.end(); j++) {
    out << *j << "\n";
  }
  out.close();
}

void DGE::readDecaysToUse(string filename) {
  ifstream in(filename.c_str());
  string line;
  int lineNum = 0;
  while(getline(in,line)) {
    lineNum++;
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
	words.push_back(line.substr(lastPos, pos-lastPos));
	lastPos = line.find_first_not_of(" ",pos);
	pos = line.find_first_of(" ",lastPos);
      }
      addDecayToUse(words);
    }
  }
  in.close();
}

void DGE::writeDecaysToUse(string filename) {
  ofstream out(filename.c_str(), ofstream::trunc);
  out << "# list of decays to use\n";
  for(int j = 0; j < decaysToUse.size(); j++) {
    for(int k = 0; k < decaysToUse[j].size(); k++) {
      out << decaysToUse[j][k] << " ";
    }
    out << "\n";
  }
  out.close();
}

void DGE::setDirectory(std::string theDir) {
  directory = theDir;
}

std::string DGE::getDirectory() {
  return directory;
}
