#ifndef WAVEFUNCTIONS_H
#define WAVEFUNCTIONS_H
 
#include "FComplex.h"
#include "FourVector.h"

// Wave functions as lists of complex numbers, for easy interfacing
// with the HELAS library

class ScalarWaveFunction {
 public:
  Complex SWF[3];
};

class FermionWaveFunction {
 public:
  Complex FWF[6];
};

class VectorWaveFunction {
 public:
  Complex VWF[6];
};

enum ScalarDirection {S_IN, S_OUT};
enum VectorDirection {V_IN, V_OUT};
enum FermionDirection {F_INPART,F_INANTI,F_OUTPART,F_OUTANTI};

// compute a scalar wavefunction
// note that helicity is passed with the four vector
ScalarWaveFunction GetScalarWave(FourVector p, ScalarDirection sd); 
VectorWaveFunction GetVectorWave(FourVector p, VectorDirection vd);
FermionWaveFunction GetFermionWave(FourVector p, FermionDirection fd,
				   bool negMass=false);

#endif
