#ifndef EVENT_H
#define EVENT_H
#include<vector>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<stdlib.h>
#include<string>
#include "Particle.h"
#include "EventParticle.h"

//style of an MG3 event
//nup dummy(event number) xwgtup scalup aqedup aqcdup 
//idup(I)
//mothup(1,I)
//mothup(2,I)
//icolup(1,I)
//icolup(2,I)
//istup(I)
//spinup(I)
//1 PUP(4,1) PUP(1,1) PUP(2,1) PUP(3,1)
//2 ..

//style of an LHA event
//<event>
//nup idrup xwgtup scalup aqedup aqcdup
//idup(I) istup(I) mothup(1,I) mothup(2,I) icolup(1,I) icolup(2,I) PUP(1,I) PUP(2,I) PUP(3,I) PUP(4,I) PUP(5,I) VTIMUP(I) SPINUP(I)
//repeat for I particles
//ignore #?
//</event>


class Event {
 public:
  Event();
  Event(int theNP,int theIDR,double theWeight, double theScale, double theAQED,
	double theAQCD,std::vector<EventParticle> theParticles);
  Event(std::ifstream& in,std::string evt_flag);

  std::ifstream& read_event(std::ifstream& in,std::string evt_flag);
  std::ofstream& write_event(std::ofstream& out,std::string evt_flag);

  int nup();
  int idprup();
  double xwgtup();
  double scalup();
  double aqedup();
  double aqcdup();
  void setnup(int theNpart);
  void setidprup(int theIDR);
  void setxwgtup(double theXwgt);
  void setscalup(double theScal);
  void setaqedup(double theAqed);
  void setaqcdup(double theAqcd);
  void add_particle(EventParticle theParticle);
  void add_particles(std::vector<EventParticle> theParticles);
  std::vector<EventParticle> get_particles();
  EventParticle get_particle(int i);  
  std::vector<int> Find_Particle(std::string theName);
  int max_color();
  
 private:
  //dummy is actually the event number as written out by madgraph
  //but perhaps we wouldn't have that
  int npart,idp;
  double xwgt,scal,aqed,aqcd;
  std::vector<EventParticle> particles;
};


#endif
