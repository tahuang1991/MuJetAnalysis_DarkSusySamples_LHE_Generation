#ifndef DECAY_EVENTS_H
#define DECAY_EVENTS_H
#include "Event.h"
#include "DecayDriver.h"
#include "Vegas.h"

void DecayEvent(Event& orig_event, int location, DecayMode* dm,
		Vegas& Vegas, double bratio, FourVector boost);
void DecayEvent(Event& orig_event, int location, TwoBodyDecayDriver& driver,
		Vegas& Vegas, double bratio, FourVector boost);
void DecayEvent(Event& orig_event, int location, ThreeBodyDecayDriver* driver,
		Vegas& Vegas, double bratio, FourVector boost);

#endif
