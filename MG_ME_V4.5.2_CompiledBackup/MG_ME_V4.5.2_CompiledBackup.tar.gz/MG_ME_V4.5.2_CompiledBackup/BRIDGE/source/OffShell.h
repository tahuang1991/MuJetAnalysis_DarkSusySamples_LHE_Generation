#ifndef OFFSHELL_H
#define OFFSHELL_H

#include "WaveFunctions.h"
#include <complex>
#include <vector>

VectorWaveFunction OffShellVectorFromFF(FermionWaveFunction fIn, 
					FermionWaveFunction fOut, 
					std::vector<std::complex<double> > couplings, 
					double vMass, double vWidth);

VectorWaveFunction OffShellVectorFromVV(VectorWaveFunction v1,
					VectorWaveFunction v2,
					std::vector<std::complex<double> > couplings,
					double vMass, double vWidth);

VectorWaveFunction OffShellVectorFromSS(ScalarWaveFunction s1,
					ScalarWaveFunction s2,
					std::vector<std::complex<double> > couplings,
					double vMass, double vWidth);

VectorWaveFunction OffShellVectorFromVS(VectorWaveFunction v,
					ScalarWaveFunction s,
					std::vector<std::complex<double> > couplings,
					double vMass, double vWidth);

FermionWaveFunction OffShellFermionFromFInS(FermionWaveFunction f,
					    ScalarWaveFunction s,
					    std::vector<std::complex<double> > couplings,
					    double fMass, double fWidth);

FermionWaveFunction OffShellFermionFromFOutS(FermionWaveFunction f,
					     ScalarWaveFunction s,
					     std::vector<std::complex<double> > couplings,
					     double fMass, double fWidth);

FermionWaveFunction OffShellFermionFromFInV(FermionWaveFunction f,
					    VectorWaveFunction v,
					    std::vector<std::complex<double> > couplings,
					    double fMass, double fWidth);

FermionWaveFunction OffShellFermionFromFOutV(FermionWaveFunction f,
					     VectorWaveFunction v,
					     std::vector<std::complex<double> > couplings,
					     double fMass, double fWidth);

ScalarWaveFunction OffShellScalarFromFF(FermionWaveFunction fIn,
					FermionWaveFunction fOut,
					std::vector<std::complex<double> > couplings,
					double sMass, double sWidth);

ScalarWaveFunction OffShellScalarFromSS(ScalarWaveFunction s1,
					ScalarWaveFunction s2,
					std::vector<std::complex<double> > couplings,
					double sMass, double sWidth);

ScalarWaveFunction OffShellScalarFromVV(VectorWaveFunction v1,
					VectorWaveFunction v2,
					std::vector<std::complex<double> > couplings,
					double sMass, double sWidth);

ScalarWaveFunction OffShellScalarFromVS(VectorWaveFunction v,
					ScalarWaveFunction s,
					std::vector<std::complex<double> > couplings,
					double sMass, double sWidth);

#endif
