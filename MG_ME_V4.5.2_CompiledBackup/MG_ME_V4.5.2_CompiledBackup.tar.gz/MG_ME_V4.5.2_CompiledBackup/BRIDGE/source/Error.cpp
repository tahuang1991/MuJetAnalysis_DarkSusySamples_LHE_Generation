#include "Error.h"
using namespace std;

void BadInputError::report(std::ostream & os) {
  os << "ERROR! -----------------------------\n";
  os << "   Bad input in file: " << FileName << "\n";
  os << "    Line number: " << LineNumber << "\n";
  os << "    Line content: " << BadInputLine << "\n";
  os << "    Description: " << description << "\n";
  os << "------------------------------------\n";
}

void UnimplementedError::report(std::ostream& os) {
  /* Don't report this yet
  os << "ERROR! -----------------------------\n";
  os << "  You're trying to do something we haven't implemented.\n";
  os << "  This is our fault, not yours.\n";
  os << "  Specifically, the problem is: \n";
  os << "  " << description << "\n";
  os << "  Send us an email complaint, or implement it yourself.\n";
  os << "------------------------------------\n"; 
  */
}
