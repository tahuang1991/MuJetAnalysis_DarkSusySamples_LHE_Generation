#ifndef FCOMPLEX_H
#define FCOMPLEX_H

#include <complex>

// struct for passing complex arguments to Fortran code
struct Complex {
  double re;
  double im;
};

// make a C++ complex number from a Fortran complex:
std::complex<double> FCxToCCx(Complex c);

// make a Fortran complex from a C++ complex:
Complex CCxToFCx(std::complex<double> c);

#endif
