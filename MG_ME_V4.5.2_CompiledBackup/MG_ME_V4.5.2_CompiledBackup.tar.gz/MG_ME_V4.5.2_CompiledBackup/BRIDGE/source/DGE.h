#ifndef DGE_H
#define DGE_H

#include <string>
#include <list>
#include "Event.h"
#include "VegasRandom.h"

// DGE.h: the "Decay Generated Events" portion of BRIDGE.

class DGE {
 public:
 DGE(VegasRandom* getRand) : getRandom(getRand), directory("") {}

  void setEventFile(std::string eventFile);
  void setOutputFile(std::string outputFile);
  bool decayParticle(std::string toDecay);
  // decays everything according to all branching ratios until reaching 
  // only particles in the list "finalParticles". If called with "true", 
  bool decayFileCompletely();
  // decays only particles appearing in the list "decaysToUse", with 
  // only the listed decays.
  bool decayFileSelected();

  void addFinalParticle(std::string particle);
  void addDecayToUse(std::vector<std::string> decayToUse);

  void setDirectory(std::string theDir);
  std::string getDirectory();

  // file input/output for lists of particles or decay modes
  void readFinalParticles(std::string filename);
  void writeFinalParticles(std::string filename);
  void readDecaysToUse(std::string filename);
  void writeDecaysToUse(std::string filename);

 protected:
  std::string origFile;
  std::string workingInputFile;
  std::string workingOutputFile;
  std::string endFile;
  std::string directory;
  std::list<std::string> finalParticles;
  // each entry here is a list, the first item in the list is parent
  // particle and the following entries are daughter particles
  std::vector<std::vector<std::string> > decaysToUse;
  VegasRandom *getRandom;
};

#endif
