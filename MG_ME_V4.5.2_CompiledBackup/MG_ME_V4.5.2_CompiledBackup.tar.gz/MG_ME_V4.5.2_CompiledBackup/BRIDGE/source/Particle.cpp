#include "Particle.h"
#include "Error.h"
#include <fstream>
#include <vector>
#include <sstream>
#include <iostream>
using namespace std;

int Particle::TwiceSpin() {
  return twice_spin;
}

int Particle::NColors() {
  return ncolors;
}

int Particle::NHelicities() {
  if(twice_spin == 0) {
    return 1;
  } else if(twice_spin == 1) {
    return 2;
  } else if(twice_spin == 2) {
    if(this->Mass() == 0.) {
      return 2;
    }
    return 3;
  } else {
    // ...
  }
  return 1;
}

std::string Particle::MassParam() {
  return mass;
}

double Particle::Mass() {
  return Values::v[mass].real();
}

std::string Particle::WidthParam() {
  return width;
}

double Particle::Width() {
  return Values::v[width].real();
}

std::string Particle::Name() {
  return name;
}

std::string Particle::Antiparticle() {
  return anti;
}

int Particle::FermionNumber() {
  return fermion_number;
}

int Particle::IDCode() {
  return ID_code;
}

void Particle::SetTwiceSpin(int spinTimesTwo) {
  twice_spin = spinTimesTwo;
}

void Particle::SetNColors(int numColors) {
  ncolors = numColors;
}

void Particle::SetMass(std::string theMass) {
  mass = theMass;
}

void Particle::SetWidth(std::string theWidth) {
  width = theWidth;
}

void Particle::SetName(std::string theName) {
  name = theName;
}

void Particle::SetAnti(std::string theAntiparticle) {
  anti = theAntiparticle;
}

void Particle::SetFermionNumber(int fermionNum) {
  fermion_number = fermionNum;
}

void Particle::SetIDCode(int theID) {
  ID_code = theID;
}

std::map<std::string, Particle> Particle::pl;
std::map<int, std::string> Particle::plFromID;

void Particle::ParseMGFile(std::string filename) {
  ifstream in(filename.c_str());
  string line;
  int lineNum = 0;
  while(getline(in,line)) {
    lineNum++;
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
	words.push_back(line.substr(lastPos, pos-lastPos));
	lastPos = line.find_first_not_of(" ",pos);
	pos = line.find_first_of(" ",lastPos);
      }
      if(words.size() == 9) {
	int twoSpin = -1;
	int fermionNumber = 0;
	if(words[2] == "S" || words[2] == "s") {
	  twoSpin = 0;
	} else if(words[2] == "F" || words[2] == "f") {
	  twoSpin = 1;
          // Set fermion number: 1, unless Majorana, designated 2
          if(words[0] != words[1])   
            fermionNumber = 1;
          else
	    fermionNumber = 2;
	} else if(words[2] == "V" || words[2] == "v") {
	  twoSpin = 2;
	} else if(words[2] == "T" || words[2] == "t") {
	  twoSpin = 4;
	}
	int numColors = 1;
	if(words[6] == "T" || words[6] == "t") numColors = 3;
	if(words[6] == "O" || words[6] == "o") numColors = 8;
	int ID_code;
	istringstream inputInt(words[8]);
	if(!(inputInt >> ID_code)) {
	  ID_code = -99999;
	  // report the error (no sense throwing an exception,
	  // just output this here.)
	  BadInputError badinput(filename,lineNum,line,
				 "ID code seems not to be integer, storing -99999");
	  badinput.report(cerr);
	}
	Particle P(twoSpin, words[4], words[5], words[0], words[1], numColors, 
		   fermionNumber, ID_code);
	Particle::pl[words[0]] = P;
	if(ID_code != -99999) {
	  Particle::plFromID[ID_code] = words[0];
	}
	if(words[0] != words[1]) {
	  Particle P2(twoSpin, words[4], words[5], words[1], words[0], 
		      numColors, -fermionNumber, -ID_code);
	  if(ID_code == -99999) {
	    P2.SetIDCode(-99999); // not +99999
	  }
	  Particle::pl[words[1]] = P2;
	  if(ID_code != -99999) {
	    Particle::plFromID[-ID_code] = words[1];
	  }
	}
      }
    }
  }
}
