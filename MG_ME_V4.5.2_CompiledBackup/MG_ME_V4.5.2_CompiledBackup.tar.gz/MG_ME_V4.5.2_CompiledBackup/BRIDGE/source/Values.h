#ifndef VALUES_H
#define VALUES_H

#include <map>
#include <string>
#include <vector>
#include <complex>

class Values {
 public:
  // A given name can have associated up to 2 complex numbers...
  static std::map<std::string, std::complex<double> > v;
  static std::map<std::string, std::complex<double> > v2;

  // Read parameters from file
  static void ParseMGFile(std::string filename);
};

#endif
