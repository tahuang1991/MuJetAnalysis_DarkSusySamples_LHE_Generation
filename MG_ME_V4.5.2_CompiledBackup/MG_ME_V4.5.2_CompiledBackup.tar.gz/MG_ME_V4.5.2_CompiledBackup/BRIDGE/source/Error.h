#ifndef ERROR_H
#define ERROR_H

#include <string>
#include <iostream>

class BadInputError {
 public:
 BadInputError(std::string theFile, int theLine, std::string BadLine,
	       std::string theDescription) :
  FileName(theFile), LineNumber(theLine), BadInputLine(BadLine),
    description(theDescription) {}

  void report(std::ostream & os);

 private:
  int LineNumber;
  std::string FileName;
  std::string BadInputLine;
  std::string description;
};

class UnimplementedError {
 public:
 UnimplementedError(std::string theDescription) :
  description(theDescription) {}

  void report(std::ostream & os);

 private:
  std::string description;
};

#endif
