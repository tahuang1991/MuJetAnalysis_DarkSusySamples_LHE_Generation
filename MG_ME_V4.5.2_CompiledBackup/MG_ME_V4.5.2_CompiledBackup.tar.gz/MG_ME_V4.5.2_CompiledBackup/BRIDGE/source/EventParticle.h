#ifndef EVENT_PARTICLE_H
#define EVENT_PARTICLE_H
#include "FourVector.h"

class EventParticle: public FourVector {
public:
    EventParticle();
    EventParticle(int a1, int a2, int a3, int a4, int a5,int a6, double fv[4], int hel);
    int idup();
    int mothup1();
    int mothup2();
    int icolup1();
    int icolup2();
    int istup();
    double p5();
    double vtimup();
    void setid(int theID);
    void setmoth1(int theM1);
    void setmoth2(int theM2);
    void setcolor1(int theCol1);
    void setcolor2(int theCol2);
    void setstatus(int theStatus);
    void setP5(double thep5);
    void setvtimup(double thevti);
private:
    int IDcode,mother1,mother2,color1,color2,status;
    // as of now P5 and vtimup are unused but added because of new file format which includes by default
    double P5,vti;
};

#endif
