#include "BRI.h"
#include "DecayBuilder.h"
#include "DecayDriver.h"
#include "Error.h"
#include "Vegas.h"
#include "Values.h"
#include "rw_events.h"
#include <cassert>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

void BRI::buildModeList() {
  vector<DecayMode *> getDecays = DecayBuilder::GetDecayModes(particleToDecay);
  for(vector<DecayMode *>::iterator i = getDecays.begin();
      i != getDecays.end(); i++) {
    DecayMode *dm = *i;
    ModeInfo minfo;
    minfo.dm = dm;
    minfo.branchingRatio = 0.; // set branching ratio to zero for now
    minfo.width = 0.;
    minfo.tableLine = "";
    allModes.push_back(minfo);
  }
  totBR = 1.0;
}

void BRI::addMode(DecayMode* theMode) {
  ModeInfo minfo;
  minfo.dm = theMode;
  minfo.branchingRatio = 0.; 
  minfo.width = 0.;
  minfo.tableLine = "";
  allModes.push_back(minfo);
}

double BRI::computeAllWidths() {
  total_width= 0.0;
  for(int i = 0; i < allModes.size(); i++) {
    int nDaughters = allModes[i].dm->NumberDaughters();
    cout << "Computing width for mode " << particleToDecay << " ->"; 
    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
      cout << " " << allModes[i].dm->ListDaughters()[k];
    }
//    ofstream debug("debug.txt", ios::app);
//    debug << "Computing width for mode " << particleToDecay << " ->"; 
//    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
//      debug << " " << allModes[i].dm->ListDaughters()[k];
//    }
//    debug << "\n";
//    debug.close();
    cout << "\n";
    if(nDaughters == 2) {
      TwoBodyDecayDriver driver(getRandom);
      driver.SetDecayMode(dynamic_cast<TwoBodyDecayMode*>(allModes[i].dm));
      Interval x1, x2;
      x1.xLow = x2.xLow = 0.;
      x1.xHigh = x2.xHigh = 1.;
      Region r;
      r.push_back(x1);
      r.push_back(x2);
      double alpha = 1.5;
      Vegas vegas(r,&driver,getRandom,&cout,alpha);
      vegas.resetAnswers();
      VegasOutput vout;
      cout << "Calling vegas\n";
      vout = vegas.integrate(nCall,maxIter,true);
      double mxwgt=vegas.MaxWeight();
      cout << "Width: " << vout.integral << "+/-" << vout.sigma << endl;
      string gridFile = directory + allModes[i].dm->Parent();
      for(int k = 0; k < nDaughters; k++)
	  gridFile += "_" + allModes[i].dm->ListDaughters()[k];
      gridFile += ".grid";
      vegas.writeToFile(gridFile);
      cout << gridFile << endl;
      allModes[i].branchingRatio = vout.integral;
      allModes[i].width = vout.integral;
      total_width += vout.integral;
    } else if(nDaughters == 3) {
      ThreeBodyDecayDriver driver(getRandom);
      driver.SetDecayMode(dynamic_cast<ThreeBodyDecayMode*>(allModes[i].dm));
      Interval x1, x2;
      x1.xLow = x2.xLow = 0.;
      x1.xHigh = x2.xHigh = 1.;
      Region r;
      r.push_back(x1);
      r.push_back(x2); 
      Interval x3, x4, x5;
      x3.xLow = x4.xLow = x5.xLow = 0.;
      x3.xHigh = x4.xHigh = x5.xHigh = 1.;
      r.push_back(x3);
      r.push_back(x4);
      r.push_back(x5);
      double alpha = 1.5;
      Vegas vegas(r,&driver,getRandom,&cout,alpha);
      vegas.resetAnswers();
      VegasOutput vout;
      cout << "Calling vegas\n";
      vout = vegas.integrate(nCall,maxIter,true);
      double mxwgt=vegas.MaxWeight();
      cout << "Width: " << vout.integral << "+/-" << vout.sigma << endl;
      string gridFile = directory + allModes[i].dm->Parent();
      for(int k = 0; k < nDaughters; k++)
	  gridFile += "_" + allModes[i].dm->ListDaughters()[k];
      gridFile += ".grid";
      vegas.writeToFile(gridFile);
      cout << gridFile << endl;
      allModes[i].branchingRatio = vout.integral;
      allModes[i].width = vout.integral;
      total_width += vout.integral;
    }
  }
  for(int j = 0; j < allModes.size(); j++) {
    allModes[j].branchingRatio /= total_width;
  }
  totBR = 1.0;
  cout << "Total Width: " << total_width << endl;
  return total_width;
}

double BRI::computeTwoBodyWidths(double otherWidths) {
  total_width= 0.0;
  for(int i = 0; i < allModes.size(); i++) {
    int nDaughters = allModes[i].dm->NumberDaughters();
    if(nDaughters != 2) continue; // only 2-body widths in this function
    cout << "Computing width for mode " << particleToDecay << " ->"; 
    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
      cout << " " << allModes[i].dm->ListDaughters()[k];
    }
//    ofstream debug("debug.txt", ios::app);
//    debug << "Computing width for mode " << particleToDecay << " ->"; 
//    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
//      debug << " " << allModes[i].dm->ListDaughters()[k];
//    }
//    debug << "\n";
//    debug.close();
    cout << "\n";
    TwoBodyDecayDriver driver(getRandom);
    driver.SetDecayMode(dynamic_cast<TwoBodyDecayMode*>(allModes[i].dm));
    Interval x1, x2;
    x1.xLow = x2.xLow = 0.;
    x1.xHigh = x2.xHigh = 1.;
    Region r;
    r.push_back(x1);
    r.push_back(x2);
    double alpha = 1.5;
    Vegas vegas(r,&driver,getRandom,&cout,alpha);
    vegas.resetAnswers();
    VegasOutput vout;
    cout << "Calling vegas\n";
    vout = vegas.integrate(nCall,maxIter,true);
    double mxwgt=vegas.MaxWeight();
    cout << "Width: " << vout.integral << "+/-" << vout.sigma << endl;
    string gridFile = directory + allModes[i].dm->Parent();
    for(int k = 0; k < nDaughters; k++)
	gridFile += "_" + allModes[i].dm->ListDaughters()[k];
    gridFile += ".grid";
    vegas.writeToFile(gridFile);
    cout << gridFile << endl;
    allModes[i].width = vout.integral;
    total_width += vout.integral;
  }
  if(total_width != 0.0) {
    for(int j = 0; j < allModes.size(); j++) {
      allModes[j].branchingRatio = allModes[j].width / total_width;
    }
    totBR = 1.0;
    cout << "Total Width In Two-Body Decays: " << total_width << endl;
  } else {
    cout << "No two-body decays" << endl;
  }
  return total_width;
}

double BRI::computeThreeBodyWidths(double otherWidths) {
  total_width= otherWidths;
  for(int i = 0; i < allModes.size(); i++) {
    int nDaughters = allModes[i].dm->NumberDaughters();
    if(nDaughters != 3) continue; // only 2-body widths in this function
    cout << "Computing width for mode " << particleToDecay << " ->"; 
    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
      cout << " " << allModes[i].dm->ListDaughters()[k];
    }
//    ofstream debug("debug.txt", ios::app);
//    debug << "Computing width for mode " << particleToDecay << " ->"; 
//    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++) {
//      debug << " " << allModes[i].dm->ListDaughters()[k];
//    }
//    debug << "\n";
//    debug.close();
    cout << "\n";
    ThreeBodyDecayDriver driver(getRandom);
    driver.SetDecayMode(dynamic_cast<ThreeBodyDecayMode*>(allModes[i].dm));
    Interval x1, x2;
    x1.xLow = x2.xLow = 0.;
    x1.xHigh = x2.xHigh = 1.;
    Region r;
    r.push_back(x1);
    r.push_back(x2); 
    Interval x3, x4, x5;
    x3.xLow = x4.xLow = x5.xLow = 0.;
    x3.xHigh = x4.xHigh = x5.xHigh = 1.;
    r.push_back(x3);
    r.push_back(x4);
    r.push_back(x5);
    double alpha = 1.5;
    Vegas vegas(r,&driver,getRandom,&cout,alpha);
    vegas.resetAnswers();
    VegasOutput vout;
    cout << "Calling vegas\n";
    vout = vegas.integrate(nCall,maxIter,true);
    double mxwgt=vegas.MaxWeight();
    cout << "Width: " << vout.integral << "+/-" << vout.sigma << endl;
    string gridFile = directory + allModes[i].dm->Parent();
    for(int k = 0; k < nDaughters; k++)
	gridFile += "_" + allModes[i].dm->ListDaughters()[k];
    gridFile += ".grid";
    vegas.writeToFile(gridFile);
    cout << gridFile << endl;
    allModes[i].width = vout.integral;
    total_width += vout.integral;
  }
  if(total_width != 0.0) {
    for(int j = 0; j < allModes.size(); j++) {
      allModes[j].branchingRatio = allModes[j].width / total_width;
    }
    totBR = 1.0;
    cout << "Total Width: " << total_width << endl;
  } else {
    cout << "No three-body decays" << endl;
  }
  return total_width;
}

bool BRI::checkForGrids() {
  // TODO : implement
  return true;
}

double BRI::totalBR() {
  return totBR;
}

bool BRI::buildDecayDrivers() {
  for(int m = 0; m < allModes.size(); m++) {
    int nDaughters = allModes[m].dm->NumberDaughters();
    if(nDaughters == 2) {
      TwoBodyDecayDriver driver(getRandom);
      driver.SetDecayMode(dynamic_cast<TwoBodyDecayMode*>(allModes[m].dm));
      drivers.push_back(&driver);
    } else if(nDaughters == 3) {
      ThreeBodyDecayDriver driver(getRandom);
      driver.SetDecayMode(dynamic_cast<ThreeBodyDecayMode*>(allModes[m].dm));
      drivers.push_back(&driver);
    }
    Interval x1, x2;
    x1.xLow = x2.xLow = 0.;
    x1.xHigh = x2.xHigh = 1.;
    Region r;
    r.push_back(x1);
    r.push_back(x2);
    if(nDaughters == 3) {
      Interval x3, x4, x5;
      x3.xLow = x4.xLow = x5.xLow = 0.;
      x3.xHigh = x4.xHigh = x5.xHigh = 1.;
      r.push_back(x3);
      r.push_back(x4);
      r.push_back(x5);
    }
    double alpha = 1.5;
    if(nDaughters == 3) alpha=0.5;
    Vegas vegas(r,drivers[m],getRandom,&cout,alpha);
    if(allModes[m].branchingRatio != 0.0) {
      // read a grid
      string gridFile = directory + allModes[m].dm->Parent();
      // construct file name using string from decay table
      vector<string> words;
      string::size_type lastPos = allModes[m].tableLine.find_first_not_of(" ",0);
      string::size_type pos = allModes[m].tableLine.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
        words.push_back(allModes[m].tableLine.substr(lastPos, pos-lastPos));
        lastPos = allModes[m].tableLine.find_first_not_of(" ",pos);
        pos = allModes[m].tableLine.find_first_of(" ",lastPos);
      }
      for(int k = 0; k < nDaughters; k++)
        gridFile += "_" + words[k];
      gridFile += ".grid";
      fstream inGrid;
      inGrid.open(gridFile.c_str(),ios::in);
      if(inGrid.is_open()) {
        //     cout << "Found existing Vegas grid, will use this grid for decaying events" << endl;
        vegas.readFromFile(gridFile);
      } else {
        // complain that grid doesn't already exist
        cout << "Failed to find expected grid " << gridFile << "\n";
        cout << "Generating a rough grid in its place. Will use branching ratio from table.\n";

        vegas.resetAnswers();
        int calls = 5000;
        vegas.integrate(calls,3,true);
      }
    }
    vegases.push_back(vegas);
  }
  return true;
}

bool BRI::readBRTable() {
  string inFile = directory + particleToDecay + "_decays.table";
  ifstream input(inFile.c_str(), ios::in);
  if(input.fail()) {
    return false;
  }
  string line;
  int lineNum;
  while(getline(input, line)) {
    lineNum++;
    if(line[0] != '#') {
      vector<string> words;
      string::size_type lastPos = line.find_first_not_of(" ",0);
      string::size_type pos = line.find_first_of(" ",lastPos);
      while(string::npos != pos || string::npos != lastPos) {
        words.push_back(line.substr(lastPos, pos-lastPos));
        lastPos = line.find_first_not_of(" ",pos);
        pos = line.find_first_of(" ",lastPos);
      }
      assert(words.size() >= 3);
      // the third word in the line should be the branching ratio
      istringstream getBR(words[words.size()-1]);
      double theBR;
      if(!(getBR >> theBR)) {
         BadInputError badinput(inFile, lineNum, line, 
                   "BR does not seem to be a real number.");
         badinput.report(cerr);
         return false;
      }
      // check if daughters correspond to a mode in our list
      int nda = words.size() - 1;
      for(int j = 0; j < allModes.size(); j++) {
        if(nda != allModes[j].dm->NumberDaughters()) continue;
        string daughter1 = allModes[j].dm->ListDaughters()[0];
        string daughter2 = allModes[j].dm->ListDaughters()[1];
        if(nda == 2) {
          if((daughter1 == words[0] && daughter2 == words[1]) ||
             (daughter1 == words[1] && daughter2 == words[0])) {
            allModes[j].branchingRatio = theBR; 
            allModes[j].tableLine = line;
          }
        } else if(nda == 3) {
          string daughter3 = allModes[j].dm->ListDaughters()[2];
          if((daughter1 == words[0] && 
              ((daughter2 == words[1] && daughter3 == words[2]) ||
               (daughter3 == words[1] && daughter2 == words[2]))) ||
             (daughter2 == words[0] &&  
              ((daughter1 == words[1] && daughter3 == words[2]) ||
               (daughter3 == words[1] && daughter1 == words[2]))) ||
             (daughter3 == words[0] &&  
              ((daughter2 == words[1] && daughter1 == words[2]) ||
               (daughter1 == words[1] && daughter2 == words[2])))) {
            allModes[j].branchingRatio = theBR;
            allModes[j].tableLine = line;
          }
        } 
        // don't throw an error if no match, could be in DGE using
        // only selected decays -- check for this?
      }
    } else {
      // read total width
      string linestart = line.substr(0,15); 
      string lineend = line.substr(15);
      //cout << "linestart = " << linestart << "\n";
      //cout << "lineend = " << lineend << "\n";
      double theWidth = 1.0e8;
      istringstream getWidth(lineend);
      if(!(getWidth >> theWidth)) {
        cout << "Unable to read total width of particle, setting it large\n";
        theWidth = 1.0e8;
      }
      string widthPar = particleToDecay + "__widthParam";
      Particle::pl[particleToDecay].SetWidth(widthPar);
      Values::v[widthPar] = theWidth;
    }
  }

  // Now, re-weight so the BRs add up to 1, in case we're only
  // using a subset of the modes
  totBR = 0.;
  for(int j = 0; j < allModes.size(); j++) {
    totBR += allModes[j].branchingRatio;
  }
  for(int j = 0; j < allModes.size(); j++) {
    allModes[j].branchingRatio /= totBR;
  }

  return true;
}

void BRI::writeBRTable() {
  string outFile = directory + particleToDecay + "_decays.table";
  ofstream output(outFile.c_str(), ofstream::trunc);
  double totWidth = 0.;
  for(int i = 0; i < allModes.size(); i++) {
    for(int k = 0; k < allModes[i].dm->NumberDaughters(); k++)
      output << allModes[i].dm->ListDaughters()[k] << " ";
    output << allModes[i].branchingRatio << "\n";
    totWidth += allModes[i].width;
  }
  output << "# Total width: " << totWidth << "\n";
  output.close();
}

void BRI::writeSLHAtable(std::ofstream& output) {
  //  output << "#         PDG            Width" << endl;
  output << "DECAY " << setw(9) << Particle::pl[particleToDecay].IDCode() << "   " << scientific << setprecision(8) 
  << total_width << "   " << '#' << " " << particleToDecay << " decays" << endl;
  output << "#          BR         NDA      ID1       ID2" << endl;
  for(int i = 0; i < allModes.size(); i++) {
  // don't write 3-body modes with 0 width
    if(allModes[i].dm->NumberDaughters() == 3 && allModes[i].branchingRatio == 0.) continue;
    output << "     "  << scientific << setprecision(8) << allModes[i].branchingRatio <<
    "   " << setw(2) << allModes[i].dm->NumberDaughters() << "   ";
    for(int j=0; j < allModes[i].dm->NumberDaughters(); j++)
        {
        output << setw(9) << Particle::pl[allModes[i].dm->ListDaughters()[j]].IDCode()  << " ";
        }
    output << "  # " << "BR(" << particleToDecay << " -> ";
    for(int j=0; j < allModes[i].dm->NumberDaughters(); j++)
        {
        output << allModes[i].dm->ListDaughters()[j] << " ";
        }
    output << ")" << endl;
  }
  output << '#' << endl; 
}

int BRI::getRandomMode() {
  // Get a random number between 0 and 1
  double rand = (*getRandom)();
  // Choose the corresponding decay mode
  double brTot = 0;
  for(int i = 0; i < allModes.size(); i++) {
    brTot += allModes[i].branchingRatio;
    if(rand < brTot) { 
      // this is the mode
      return i;
    }
  }
  return allModes.size() - 1;
}

void BRI::setDirectory(std::string theDir) {
  directory = theDir;
}

std::string BRI::getDirectory() {
  return directory;
}

void BRI::setNumberVegasCalls(int ncalls) {
  nCall = ncalls;
}

int BRI::getNumberVegasCalls() {
  return nCall;
}

void BRI::setMaxVegasIter(int miter) {
  maxIter = miter;
}

int BRI::getMaxVegasIter() {
  return maxIter;
}

bool testsm(int idc)
{
//check to see if particles is in the sm and not t,w,z,h
if(idc==1||idc==2||idc==3||idc==4||idc==5||idc==11||idc==12||idc==13||idc==14||idc==15||idc==16||idc==22||idc==21)
return true;
else
return false;
}

int particlechoice(std::vector<std::string>& inlist)
{
 string testparticle;
 std::vector<std::string> plist,plist2;
 int choice2=0; 
  
 while(choice2!=1&&choice2!=2)
        {
        cout << "Available particles for decay(by default the only SM particles listed here are h,W,Z, and t as well as particles not anti-particles): " << endl;
        map<std::string,Particle>::iterator iter; 
        for( iter = Particle::pl.begin(); iter != Particle::pl.end(); iter++ ) {
          if(!testsm(iter->second.IDCode()))
          {
          plist2.push_back(iter->second.Name());
            if(iter->second.IDCode()>0)
            {
                plist.push_back(iter->second.Name());
                cout << iter->second.Name() << " ";
            }
          }
          
        }
        cout << endl;
        cout << "Do you wish to generate decay tables for all particles listed above or a subset?(type 1 for all, 2 for subset)" << endl;
        cin >> choice2;
        if(choice2!=1&&choice2!=2)
        cout << "Choice not recognized, try again!" << endl;
        }
    if(choice2==1)
        {
        cout << "You have selected to generate all decay tables, the default option is to generate only particle decays and not antiparticles."
        << "  If there is no reason to treat antiparticle decays differently than particle decays you may run the script antigrids.pl to create these grids separately,"
        << " if not you must generate antiparticle grids through BRI.  Do you wish to generate antiparticle grids in BRI? (Y/N): ";
        string yesno;
        cin >> yesno;
        if(yesno == "Y" || yesno == "y") 
            {
            cout << endl << "Generating all particle AND antiparticle decay tables(this may take awhile)" << endl;
            inlist=plist2;
            return 1;
            }
        else
            {
            cout << "Generating all decay tables for particles NOT antiparticles(this may take awhile!)" << endl;
            inlist=plist;
            return 1;
            }
        return 1;
        }
    if(choice2==2)
        {
        cout << "Please enter particles you wish to create decay tables for, you must explicitly enter antiparticles if "
        << "you want BRI to generate their decay tables, otherwise use antigrids.pl: (type 'done' when finished) " << endl;
        while(cin >> testparticle)
            {
            if(testparticle=="done")
                return 1;
            inlist.push_back(testparticle);
            }   
        return 2;
        }
 
}

int checkfile(std::string& testfile)
{
ifstream infile;
int check=0;
if(testfile=="") return 0;
while(check==0)
    {
    infile.open(testfile.c_str());
    if(infile.is_open())
        {
        infile.close();
        return 0;
        }
    else
        {
        cout << "The file " << testfile << " does not appear to exist, please try again: ";
        infile.close();
        getline(cin,testfile);
        if(testfile=="") return 0;  
        }
    }
}

std::vector<int> finddecaylist(std::string filename)
{
ifstream in(filename.c_str());
string temp;
vector<string> tempsplit;
vector<int> decaylist;
while(!in.eof())
    {
    getline(in,temp);
    tempsplit=split(temp);
    if(tempsplit[0]=="DECAY")
        decaylist.push_back(atoi(tempsplit[1].c_str()));
    }
in.close();
return decaylist;
}

void updateparamcard(std::string slhadecfile,std::string paramcard,std::string path,bool batch)
{
vector<int> bdecays,pdecays;
string temp;
vector<string> tempsplit;
bdecays=finddecaylist(slhadecfile);
pdecays=finddecaylist(paramcard);
vector<int>::iterator tempiter;
//reduce pdecays to only the ones we want to keep(i.e. that bri hasn't calculated yet)
for(vector<int>::iterator i=bdecays.begin();i!=bdecays.end();i++)
    {
    tempiter=find(pdecays.begin(),pdecays.end(),*i);
    if(tempiter!=pdecays.end())
        {
        pdecays.erase(tempiter);
        }
    }
ifstream in(paramcard.c_str());
string temp1=path+"temp1.file";
string temp2=path+"temp2.file";
ofstream out1(temp1.c_str());
ofstream out2;
int check1=0;
while(!in.eof())
    {
    getline(in,temp);
    if(in.peek()==in.eof())
    break;
    tempsplit=split(temp);
    if(tempsplit[0]=="DECAY")
        {
        tempiter=find(pdecays.begin(),pdecays.end(),atoi(tempsplit[1].c_str()));
        if(tempiter!=pdecays.end())
        {
        out1 << temp << endl;
        }
        }
    if((tempsplit[0]=="BLOCK")&&(tempsplit[1]=="MGUSER"))
        check1=1;
    if(check1==1)
        out1 << temp << endl;
    }
in.close();
out1.close();
string yesno;
if(batch)
{
	yesno="n";
}
else
{
	cout << "Do you wish to keep a copy of the old param_card.dat?(Y/N) ";
	cin >> yesno;
}
if(yesno == "Y" || yesno == "y") 
    {
    string paramcardold=path+"param_card_old_bridge.dat";
    out2.open(paramcardold.c_str(), ofstream::trunc);
    check1=99;
    }

//write paramcard out to temp2 and possibly copy old paramcard
ifstream in4(paramcard.c_str());
int check2=0;
out1.open(temp2.c_str());
while(!in4.eof())
    {
    getline(in4,temp);
    tempsplit=split(temp);
    if(tempsplit[0]=="DECAY")
        check2=1;
    if(check2!=1)
        out1 << temp << endl;
    if(check1==99)
        {
        out2 << temp << endl;
        }
    }
in4.close();
out1.close();
if(check1==99)
    {
    out2.close();
    }
ofstream finalout(paramcard.c_str(), ofstream::trunc);
ifstream in5(temp2.c_str());
ifstream in2(slhadecfile.c_str());
ifstream in3(temp1.c_str());
while(!in5.eof())
    {
    getline(in5,temp);
    if(in5.peek()==in5.eof()||temp=="")
    break;
    finalout << temp << endl;
    }
while(!in2.eof())
    {
    getline(in2,temp);
    if(in2.peek()==in2.eof()||temp=="")
    break;
    finalout << temp << endl;
    }
while(!in3.eof())
    {
    getline(in3,temp);
    if(in3.peek()==in3.eof()||temp=="")
    {
    finalout << temp;
    break;
    }
    else
    finalout << temp << endl;
    }
in5.close();
in2.close();
in3.close();
finalout.close();
out1.open(temp1.c_str(),ofstream::trunc);
out1 << " ";
out1.close();
out1.open(temp2.c_str(),ofstream::trunc);
out1 << " ";
out1.close();
}
