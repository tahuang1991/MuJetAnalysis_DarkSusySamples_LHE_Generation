#include "batchhelper.h"
using namespace std;

int usagehelprb()
{
	cout << "Incorrect number of parameters passed to BRI" << endl;
	cout << "Correct usage is for running for a madgraph model:" << endl;
	cout << "runBRI y [modelname] [blist particles elist] [vegas seed] [calls] [iterations] [3if2?] ";
	cout << "[replace param_card.dat:y/n]" << endl;
	cout << "Correct usage for a generic run:" << endl;
	cout << "runBRI n [particlefile] [parameterfile] [interactionsfile] [directoryforgrids] [slhafile] [blist particles elist] [vegas seed] [calls] [iterations] [3if2?]" << endl;
	return 0;
}


int usagehelprbsusy()
{
	cout << "Incorrect number of parameters passed to BRI" << endl;
	cout << "Correct usage: " << endl;
	cout << "runBRIsusy [particlefile] [parameterfile] [interactionsfile] [directoryforgrids] [slhafile] [blist particles elist] [vegas seed] [calls] [iterations] [3if2?] " << endl;
	return 0;
}
int usagehelprd()
{
	cout << "Incorrect number of parameters passed to DGE" << endl;
	cout << "Correct usage is for running for a madgraph model:" << endl;
	cout << "runDGE y [modelname] [input lhe file] [output lhe file] [vegas seed] [specify final state particles or decay modes:2/3] ";
	cout <<	"[file with decay list]" << endl;
	cout << "Correct usage for a generic run:" << endl;
	cout << "runDGE n [particlefile] [parameterfile] [interactionsfile] [input lhe file] [output lhe file] [directoryforgrids] "; 
	cout << "[vegas seed] [specify final state particles or decay modes:2/3] [file with decay list]" << endl;
	return 0;
}

int usagehelprdsusy()
{
	cout << "Incorrect number of parameters passed to DGE" << endl;
	cout << "Correct usage:" << endl;
	cout << "runDGEsusy [particlefile] [parameterfile] [interactionsfile] [input lhe file] [output lhe file] [directoryforgrids] "; 
	cout << "[vegas seed] [specify final state particles or decay modes:2/3] [file with decay list]" << endl;
	return 0;
}
int runbribatch(int argc, char *argv[],std::vector<std::string>& pargs)
{
if(argc>1)
  {
	  if(argc<10)
	  {
		  usagehelprb();
		  return 0;
	  }
	  if(string(argv[1])=="y"||string(argv[1])=="Y"||string(argv[1])=="n"||string(argv[1])=="N")
	  {
		  pargs.push_back(argv[1]);
	  }
	  else
	  {
		  usagehelprb();
		  return 0;
	  }
	  if(string(argv[1])=="y"||string(argv[1])=="Y")
	  {
		  pargs.push_back(argv[2]);
		  if(string(argv[3])!="blist")
		  {
			  usagehelprb();
			  return 0;
		  }
		  int nparticles=0;
		  int endit=0;
		  for(int i=4;i<argc;i++)
		  {
			  if(string(argv[i])!="elist" && endit==0)
			  {
				  pargs.push_back(argv[i]);
				  nparticles++;
			  }
			  else
			  {
				  endit++;
			  }
		  }
		  if(endit!=0)
		  {
			  for(int i=5+nparticles;i<argc;i++)
			  {	
				  if(string(argv[i])!="")
				  {
					  pargs.push_back(argv[i]);
				  }
				  else
				  {
					  usagehelprb();
					  return 0;
				  }
			  }
			  stringstream ss;
			  ss << nparticles;
			  pargs.push_back(ss.str());
		  }
		  else
		  {
			  usagehelprb();
			  return 0;
		  }
	  }
	  else
	  {
	  // Not a madgraph directory parse this input
		if(argc<14)
		{
			usagehelprb();
			return 0;
		}
		if(string(argv[7])!="blist")
		{
			usagehelprb();
			return 0;
		}
		for(int i=2;i<=6;i++)
		{
			pargs.push_back(argv[i]);
		}
		int nparticles=0;
		int endit=0;
		  for(int i=8;i<argc;i++)
		  {
			  if(string(argv[i])!="elist" && endit==0)
			  {
				  pargs.push_back(argv[i]);
				  nparticles++;
			  }
			  else
			  {
				  endit++;
			  }
		  }
		  if(endit!=0)
		  {
			  for(int i=9+nparticles;i<argc;i++)
			  {	
				  if(string(argv[i])!="")
				  {
					  pargs.push_back(argv[i]);
				  }
				  else
				  {
					  usagehelprb();
					  return 0;
				  }
			  }
			  stringstream ss;
			  ss << nparticles;
			  pargs.push_back(ss.str());
		  }
		  else
		  {
			  usagehelprb();
			  return 0;
		  }
	  }
  }
return 1;
}

int runbribatchsusy(int argc, char *argv[],std::vector<std::string>& pargs)
{
if(argc>1)
  {
	  
	if(argc<13)
	{
		usagehelprbsusy();
		return 0;
	}
	if(string(argv[6])!="blist")
	{
		usagehelprbsusy();
		return 0;
	}
	for(int i=1;i<=5;i++)
	{
		pargs.push_back(argv[i]);
	}
	int nparticles=0;
	int endit=0;
	for(int i=7;i<argc;i++)
	{
	  if(string(argv[i])!="elist" && endit==0)
	  {
		  pargs.push_back(argv[i]);
		  nparticles++;
	  }
	  else
	  {
		  endit++;
	  }
	}
	if(endit!=0)
	{
	  for(int i=8+nparticles;i<argc;i++)
	  {	
		  if(string(argv[i])!="")
		  {
			  pargs.push_back(argv[i]);
		  }
		  else
		  {
			  usagehelprbsusy();
			  return 0;
		  }
	  }
	  stringstream ss;
	  ss << nparticles;
	  pargs.push_back(ss.str());
	}
	else
	{
	  usagehelprbsusy();
	  return 0;
	}
	
  }
return 1;
}

int rundgebatch(int argc, char *argv[],std::vector<std::string>& pargs)
{
if(argc>1)
  {
	  if(argc<7)
	  {
		  usagehelprd();
		  return 0;
	  }
	  if(string(argv[1])=="y"||string(argv[1])=="Y"||string(argv[1])=="n"||string(argv[1])=="N")
	  {
		  pargs.push_back(argv[1]);
	  }
	  else
	  {
		  usagehelprd();
		  return 0;
	  }
	  if(string(argv[1])=="y"||string(argv[1])=="Y")
	  {
		  if(argc!=8)
		  {
			  usagehelprd();
			  return 0;
		  }
		  //directory name
		  pargs.push_back(argv[2]);
		  //input file lhe
		  pargs.push_back(argv[3]);
		  //output file lhe
		  pargs.push_back(argv[4]);
		  //vegas seed
		  pargs.push_back(argv[5]);
		  //how to use dge
		  if(atoi(argv[6])==2 || atoi(argv[6])==3)
		  {
			  pargs.push_back(argv[6]);
		  }
		  else
		  {
			  usagehelprd();
			  cout << argv[6];
			  return 0;
		  }
		  //file with final state or decay modes
		  pargs.push_back(argv[7]);
	  }
	  else
	  {
	  // Not a madgraph directory parse this input
		if(argc!=11)
		{
			usagehelprd();
			return 0;
		}
		  //particle file
		  pargs.push_back(argv[2]);
		  //parameter file
		  pargs.push_back(argv[3]);
		  //interactions file
		  pargs.push_back(argv[4]);
		  //input file lhe
		  pargs.push_back(argv[5]);
		  //output file lhe
		  pargs.push_back(argv[6]);
		  //directory for grids
		  pargs.push_back(argv[7]);
		  //vegas seed
		  pargs.push_back(argv[8]);
		  //how to use dge
		  if(atoi(argv[9])==2 || atoi(argv[9])==3)
		  {
			  pargs.push_back(argv[9]);
		  }
		  else
		  {
			  usagehelprd();
			  cout << argv[9];
			  return 0;
		  }
		  //file with final state or decay modes
		  pargs.push_back(argv[10]);
	  }
  }
return 1;
}

int rundgebatchsusy(int argc, char *argv[],std::vector<std::string>& pargs)
{
if(argc>1)
  {
		if(argc!=10)
		{
			usagehelprdsusy();
			return 0;
		}
		  //particle file
		  pargs.push_back(argv[1]);
		  //parameter file
		  pargs.push_back(argv[2]);
		  //interactions file
		  pargs.push_back(argv[3]);
		  //input file lhe
		  pargs.push_back(argv[4]);
		  //output file lhe
		  pargs.push_back(argv[5]);
		  //directory for grids
		  pargs.push_back(argv[6]);
		  //vegas seed
		  pargs.push_back(argv[7]);
		  //how to use dge
		  if(atoi(argv[8])==2 || atoi(argv[8])==3)
		  {
			  pargs.push_back(argv[8]);
		  }
		  else
		  {
			  usagehelprdsusy();
			  cout << argv[8];
			  return 0;
		  }
		  //file with final state or decay modes
		  pargs.push_back(argv[9]);
  }
return 1;
}
