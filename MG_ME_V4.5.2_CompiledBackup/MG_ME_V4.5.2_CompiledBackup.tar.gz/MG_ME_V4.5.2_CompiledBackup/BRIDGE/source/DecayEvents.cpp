#include "DecayEvents.h"
#include "DecayUtil.h"
#include "HelasUtil.h"
#include <iostream>
#include <math.h>
using namespace std;

void DecayEvent(Event& orig_event, int location, DecayMode* dm,
		Vegas& Vegas, double bratio,
		FourVector boost)
{
  int nDaughters = dm->NumberDaughters();
  if(nDaughters == 2) {
    TwoBodyDecayDriver drv2(Vegas.RandomGenerator());
    drv2.SetDecayMode(dynamic_cast<TwoBodyDecayMode*>(dm));
    DecayEvent(orig_event,location,drv2,Vegas,bratio,boost);
  } else if(nDaughters == 3) {
    ThreeBodyDecayDriver drv3(Vegas.RandomGenerator());
    drv3.SetDecayMode(dynamic_cast<ThreeBodyDecayMode*>(dm));
    DecayEvent(orig_event,location,&drv3,Vegas,bratio,boost);
  } else {
    cout << "Oops. nDaughters should be 2 or 3 in DecayEvent....\n";
  }
}

void DecayEvent(Event& orig_event, int location, TwoBodyDecayDriver& driver, 
        Vegas& vegas, double bratio, FourVector boost)
{
  vector<EventParticle> orig_particles,dec_particles;
  EventParticle emptyparticle;
  //double cms[4];
  double weight=orig_event.xwgtup();
  double wgt=0.0;
  double mxwgt = vegas.MaxWeight();
  orig_particles=orig_event.get_particles();
  
  dec_particles.push_back(orig_particles[location]);
  dec_particles[0].setstatus(2);
  
  // don't pass twobodydecay eventually and get numdaughters
  // from general decaymode
  int numdaughters=2;

  for(int i=1;i<=numdaughters;i++)
  {
    dec_particles.push_back(emptyparticle);
  }

  // setting up all the id information for the new particles
  // cheating here for two body only again
  int maxcol=orig_event.max_color();
  for(int i=1;i<=numdaughters;i++)
  {
    dec_particles[i].setid(Particle::pl[driver.GetDecayMode()->ListDaughters()[i-1]].IDCode());
    dec_particles[i].setmoth1(location+1);
    //have to think about cases for 2 mothers?
    dec_particles[i].setmoth2(0);
  }
  for(int i=1;i<=numdaughters;i++) {
    //Color labels: put this in another function!!
    //Specific to two body decays, some caveats
    if(Particle::pl[Particle::plFromID[dec_particles[i].idup()]].NColors()==1)
        {
        dec_particles[i].setcolor1(0);
        dec_particles[i].setcolor2(0);
        }
    else
        {
        if(dec_particles[0].icolup1()==0&&dec_particles[0].icolup2()==0)
            {
            // not sufficient for h->gg can add this but just getting basic 2 body color first
            // will need to distinguish gluon from "anti" gluon, can do this on simple case checker
            // but will have to specify to two body, I think this is ok since we will have more 
            // complication on 3-body color not even touched here
                //h->gg specific for 2 body
                if(Particle::pl[Particle::plFromID[dec_particles[i].idup()]].NColors()==8)
                {
                dec_particles[i].setcolor1(maxcol+i);
                dec_particles[i].setcolor2(maxcol+3-i);
                }
                else
                {
                    // asuming triplet here
                    if(dec_particles[i].idup()>0)
                    {
                    dec_particles[i].setcolor1(maxcol+1);
                    dec_particles[i].setcolor2(0);
                    }
                    else
                    {
                    dec_particles[i].setcolor2(maxcol+1);
                    dec_particles[i].setcolor1(0);
                    }
                }
            }
        else
            {
            //parent is colored: two cases 8 or 3, squirks? no...
            if(Particle::pl[Particle::plFromID[dec_particles[0].idup()]].NColors()==8)
                {
		    string thisp = driver.GetDecayMode()->ListDaughters()[i-1];
		    string otherp = driver.GetDecayMode()->ListDaughters()[(3-i)-1];
		    int ncolthis = Particle::pl[thisp].NColors();
		    int ncolother = Particle::pl[otherp].NColors();
		    if(ncolthis == 3 && ncolother == 3) {
		      if(dec_particles[i].idup()>0)
			{
			  dec_particles[i].setcolor1(dec_particles[0].icolup1());
			  dec_particles[i].setcolor2(0);
			}
		      else
			{
			  dec_particles[i].setcolor2(dec_particles[0].icolup2());
			  dec_particles[i].setcolor1(0);
			}
		    } else if(ncolthis == 8 && ncolother == 8) {
		      dec_particles[i].setcolor1(dec_particles[0].icolup1());
		      dec_particles[i].setcolor2(maxcol+1);
		      dec_particles[3-i].setcolor1(maxcol+1);
		      dec_particles[3-i].setcolor2(dec_particles[0].icolup2());
		    } else if(ncolthis == 8 && ncolother == 1) {
		      dec_particles[i].setcolor1(dec_particles[0].icolup1());
		      dec_particles[i].setcolor2(dec_particles[0].icolup2());
		    }
                 }
            else
                {
		    string thisp = driver.GetDecayMode()->ListDaughters()[i-1];
		    string otherp = driver.GetDecayMode()->ListDaughters()[(3-i)-1];
		    int ncolthis = Particle::pl[thisp].NColors();
		    int ncolother = Particle::pl[otherp].NColors();
		    if(ncolthis == 3 && ncolother == 1) {
			dec_particles[i].setcolor1(dec_particles[0].icolup1());
			dec_particles[i].setcolor2(dec_particles[0].icolup2());
		    }
		    else if(ncolthis == 3 && ncolother == 8) {
			if(dec_particles[i].idup()>0) {
                            // 3 -> 3 + 8
			    dec_particles[i].setcolor1(maxcol+1);
			    dec_particles[i].setcolor2(0);
			} else {
                            // 3bar -> 3bar + 8
			    dec_particles[i].setcolor1(0);
			    dec_particles[i].setcolor2(maxcol+1);
			}
		    } else if(ncolthis == 8 && ncolother == 3) {
			if(dec_particles[3-i].idup()>0) {
                            // 3 -> 3 + 8
			    dec_particles[i].setcolor1(dec_particles[0].icolup1());
			    dec_particles[i].setcolor2(maxcol+1);
			} else {
                            // 3bar -> 3bar + 8
			    dec_particles[i].setcolor1(maxcol+1);
			    dec_particles[i].setcolor2(dec_particles[0].icolup2());
			}
		    }
                }   
            }
        }  
    dec_particles[i].setstatus(1);
    //P5 needs to be calculated so not set here
    //vtimup always this unless we add it to particle class... can let matt do studies of the ranch in principle...
    dec_particles[i].setvtimup(0.0);
    dec_particles[i].Helicity=driver.GetRandomHelicity(driver.GetDecayMode()->ListDaughters()[i-1]);
  }

  // need momentum, wgt
  /*
  for(int i=0;i<=3;i++)
  {
    cms[i]=double(-orig_particles[0].P[i]-orig_particles[1].P[i]);
  }
  cms[0]=-cms[0];
  for(int i=0;i<=3;i++)
  {
    cout << "orig_particles[location].P[" << i << "] = " << orig_particles[location].P[i] << "\n";
    cout << "cms[" << i << "] = " << cms[i] << "\n";
  }
  boostx_(orig_particles[location].P,cms,dec_particles[0].P);
  for(int i=0; i<=3; i++)
  {
    cout << "dec_particles[0].P[" << i << "] = " << dec_particles[0].P[i] << "\n";
  }
  */
  // boost to the reference frame we are given
  boostx_(orig_particles[location].P,boost.P,dec_particles[0].P);
  vector<double> X;

  bool done=false;
  while(!done)
  {
    double vegas_wgt=vegas.getRandomFromGrid(X);
    driver.SetMotherMomentum((FourVector) dec_particles[0]);
    wgt = driver.RunEvent(X, vegas_wgt);
    if(wgt != wgt) {
	cout << "Oops! Event weight is NaN, exiting to avoid infinite loop.\n";
	exit(0);
    }
    FourVector d1P = driver.Daughter1Momentum();
    FourVector d2P = driver.Daughter2Momentum();
    for(int i = 0; i < 4; i++) {
      dec_particles[1].P[i] = d1P.P[i];
      dec_particles[2].P[i] = d2P.P[i];
    }
    dec_particles[1].Helicity = d1P.Helicity;
    dec_particles[2].Helicity = d2P.Helicity;
    wgt *= vegas_wgt;
    //cout << "vegas weight is: "<< vegas_wgt  << endl;
    //cout << "evt. weight * vegas weight is: " << wgt << endl;
  //  cout << "Max weight is: " << mxwgt << endl;
    double random = (*(vegas.RandomGenerator()))();
//    cout << "Random is: " << random << endl;
    if(wgt/random > mxwgt)
    {
      done=true;
    }
  }
    
  // boost back to the lab frame
  for(int i = 1; i <= 3; i++) {
    boost.P[i] = -boost.P[i];
  }
  for(int i = 0; i <= numdaughters; i++) {
    boostx_(dec_particles[i].P,boost.P,dec_particles[i].P);
  }

  // add lifetime information for the decayed particle
  double rand_for_ct = (*(vegas.RandomGenerator()))();
  // get the width
  double Gamma = Particle::pl[Particle::plFromID[dec_particles[0].idup()]].Width();
  //cout << "Gamma = " << Gamma << "\n";
  // CDF: 1 - exp(-t/tau), where tau = 1/Gamma
  double t_in_GeVinv = -log(1.0-rand_for_ct)/Gamma;
  // want c tau in mm:
  double GeVinv_to_mm = 0.197e-12;
  dec_particles[0].setvtimup(t_in_GeVinv * GeVinv_to_mm);
  // debugging
  // ofstream somefile("ctau.txt",ios::app);
  // somefile << t_in_GeVinv * GeVinv_to_mm << "\n";
  // somefile.close();

  // modifying the original event to contain all the new information 
  // from the decay
  orig_particles[location]=dec_particles[0];
  for(int i=1;i<=numdaughters;i++)
  {
    //need to fix M() if its <0 return M <0 as per hep-ph/0109068
    //will a negative mass mess up anything else in the code?
    //this needs to be adressed at some point
    //muon decay screwed up if P5!=0 in pythia so we will set = particle mass
    //dec_particles[i].setP5(dec_particles[i].M()); originally
    dec_particles[i].setP5(Particle::pl[Particle::plFromID[dec_particles[i].idup()]].Mass());
    orig_particles.push_back(dec_particles[i]);
  }
  orig_event.add_particles(orig_particles);
  orig_event.setnup(orig_particles.size());

  orig_event.setxwgtup(weight*bratio);
  //cout << decaymode->Parent() <<  " -> " << decaymode->ListDaughters()[0] << ", " 
  //       << decaymode->ListDaughters()[1] << "\n";
  //parent location
  //cout << "location of particle is line number: " << location+1 << endl;       
  //
}


void DecayEvent(Event& orig_event, int location, ThreeBodyDecayDriver* driver, 
        Vegas& vegas, double bratio, FourVector boost)
{
  vector<EventParticle> orig_particles,dec_particles;
  EventParticle emptyparticle;
  //double cms[4];
  double weight=orig_event.xwgtup();
  double wgt=0.0;
  double mxwgt = vegas.MaxWeight();
  static bool first=true;
  if(first) {
      cout << "Max weight = " << mxwgt << "\n";
      first = false;
  }
  orig_particles=orig_event.get_particles();
  
  dec_particles.push_back(orig_particles[location]);
  dec_particles[0].setstatus(2);
  
  // don't pass twobodydecay eventually and get numdaughters
  // from general decaymode
  int numdaughters=3;

  // Fill in basics
  for(int i=1;i<=numdaughters;i++)
  {
    dec_particles.push_back(emptyparticle);
    dec_particles[i].setid(Particle::pl[driver->GetDecayMode()->ListDaughters()[i-1]].IDCode());
    dec_particles[i].setmoth1(location+1);
    //have to think about cases for 2 mothers?
    dec_particles[i].setmoth2(0);
    dec_particles[i].setcolor1(0);
    dec_particles[i].setcolor2(0);
    dec_particles[i].setstatus(1);
    //P5 needs to be calculated so not set here
    //vtimup always this unless we add it to particle class... can let matt do studies of the ranch in principle...
    dec_particles[i].setvtimup(0.0);
    dec_particles[i].Helicity=driver->GetRandomHelicity(driver->GetDecayMode()->ListDaughters()[i-1]);
  }
  
  // 3-body color flow
  // blame Matt Reece, August 2009 -- what was here before was worse than useless.
  // this is imperfect but hopefully close enough.
  int maxcol = orig_event.max_color();
  int IDmo = dec_particles[0].idup();
  int NCmo = Particle::pl[Particle::plFromID[IDmo]].NColors();
  int NCmoC1 = dec_particles[0].icolup1();
  int NCmoC2 = dec_particles[0].icolup2();
  int IDd1 = dec_particles[1].idup();
  int NCd1 = Particle::pl[Particle::plFromID[IDd1]].NColors();
  int IDd2 = dec_particles[2].idup(); 
  int NCd2 = Particle::pl[Particle::plFromID[IDd2]].NColors();
  int IDd3 = dec_particles[3].idup();
  int NCd3 = Particle::pl[Particle::plFromID[IDd3]].NColors();
  // First, handle all the cases with two final-state singlets, carrying through
  // color indices of parent to the other daughter.
  if(NCd1 == 1 && NCd2 == 1) {
    dec_particles[3].setcolor1(NCmoC1);
    dec_particles[3].setcolor2(NCmoC2);
  } else if(NCd1 == 1 && NCd3 == 1) {
    dec_particles[2].setcolor1(NCmoC1);
    dec_particles[2].setcolor2(NCmoC2);
  } else if(NCd2 == 1 && NCd3 == 1) {
    dec_particles[1].setcolor1(NCmoC1);
    dec_particles[1].setcolor2(NCmoC2);
  // next, cases where the parent and one daughter are singlets:
  } else if(NCmo == 1 && NCd1 == 1) {    
    // others are octets?
    if(NCd2 == 8 && NCd3 == 8) {
      dec_particles[2].setcolor1(maxcol+1);
      dec_particles[2].setcolor2(maxcol+2);
      dec_particles[3].setcolor1(maxcol+2);
      dec_particles[3].setcolor2(maxcol+1);
    // triplets?
    } else if(NCd2 == 3 && NCd3 == 3) {
      if(IDd2 > 0) {
        dec_particles[2].setcolor1(maxcol+1);
        dec_particles[3].setcolor2(maxcol+1);
      } else {
        dec_particles[2].setcolor2(maxcol+1);
        dec_particles[3].setcolor1(maxcol+1);
      }
    // others?
    } else {
      cout << "Problematic color combination in DecayEvents.cpp\n";
    }
  } else if(NCmo == 1 && NCd2 == 1) {
    // others are octets?
    if(NCd1 == 8 && NCd3 == 8) {
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[1].setcolor2(maxcol+2);
      dec_particles[3].setcolor1(maxcol+2);
      dec_particles[3].setcolor2(maxcol+1);
    // triplets?
    } else if(NCd1 == 3 && NCd3 == 3) {
      if(IDd1 > 0) {
        dec_particles[1].setcolor1(maxcol+1);
        dec_particles[3].setcolor2(maxcol+1);
      } else {
        dec_particles[1].setcolor2(maxcol+1);
        dec_particles[3].setcolor1(maxcol+1);
      }
    // others?
    } else {
      cout << "Problematic color combination in DecayEvents.cpp\n";
    }
  } else if(NCmo == 1 && NCd3 == 1) {
    // others are octets?
    if(NCd1 == 8 && NCd2 == 8) {
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[1].setcolor2(maxcol+2);
      dec_particles[2].setcolor1(maxcol+2);
      dec_particles[2].setcolor2(maxcol+1);
    // triplets?
    } else if(NCd1 == 3 && NCd2 == 3) {
      if(IDd1 > 0) {
        dec_particles[1].setcolor1(maxcol+1);
        dec_particles[2].setcolor2(maxcol+1);
      } else {
        dec_particles[1].setcolor2(maxcol+1);
        dec_particles[2].setcolor1(maxcol+1);
      }
    // others?
    } else {
      cout << "Problematic color combination in DecayEvents.cpp\n";
    }
  // next, the 1 -> 3 3 8 case (two new color labels, unambiguous):
  } else if(NCmo ==1 && NCd1 == 3 && NCd2 == 3 && NCd3 == 8) {
    if(IDd1 > 0) {
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[2].setcolor2(maxcol+2);
      dec_particles[3].setcolor1(maxcol+2);
      dec_particles[3].setcolor2(maxcol+1);
    } else {
      dec_particles[1].setcolor2(maxcol+1);
      dec_particles[2].setcolor1(maxcol+2);
      dec_particles[3].setcolor2(maxcol+2);
      dec_particles[3].setcolor1(maxcol+1);
    }
  } else if(NCmo ==1 && NCd1 == 3 && NCd2 == 8 && NCd3 == 3) {
    if(IDd1 > 0) {
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[3].setcolor2(maxcol+2);
      dec_particles[2].setcolor1(maxcol+2);
      dec_particles[2].setcolor2(maxcol+1);
    } else {
      dec_particles[1].setcolor2(maxcol+1);
      dec_particles[3].setcolor1(maxcol+2);
      dec_particles[2].setcolor2(maxcol+2);
      dec_particles[2].setcolor1(maxcol+1);
    }
  } else if(NCmo ==1 && NCd1 == 8 && NCd2 == 3 && NCd3 == 3) {
    if(IDd3 > 0) {
      dec_particles[3].setcolor1(maxcol+1);
      dec_particles[2].setcolor2(maxcol+2);
      dec_particles[1].setcolor1(maxcol+2);
      dec_particles[1].setcolor2(maxcol+1);
    } else {
      dec_particles[3].setcolor2(maxcol+1);
      dec_particles[2].setcolor1(maxcol+2);
      dec_particles[1].setcolor2(maxcol+2);
      dec_particles[1].setcolor1(maxcol+1);
    }
  // next, the case 3 -> 3 8 1; one new label, unambiguous
  } else if(NCmo == 3 && NCd1 == 3 && NCd2 == 8 && NCd3 == 1) {
    if(IDmo > 0) { 
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[2].setcolor1(NCmoC1);
      dec_particles[2].setcolor2(maxcol+1);
    } else {
      dec_particles[1].setcolor2(maxcol+1);
      dec_particles[2].setcolor1(maxcol+1);
      dec_particles[2].setcolor2(NCmoC2);
    }
  } else if(NCmo == 3 && NCd1 == 3 && NCd2 == 1 && NCd3 == 8) {
    if(IDmo > 0) { 
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[3].setcolor1(NCmoC1);
      dec_particles[3].setcolor2(maxcol+1);
    } else {
      dec_particles[1].setcolor2(maxcol+1);
      dec_particles[3].setcolor1(maxcol+1);
      dec_particles[3].setcolor2(NCmoC2);
    }
  } else if(NCmo == 3 && NCd1 == 1 && NCd2 == 8 && NCd3 == 3) {
    if(IDmo > 0) { 
      dec_particles[3].setcolor1(maxcol+1);
      dec_particles[2].setcolor1(NCmoC1);
      dec_particles[2].setcolor2(maxcol+1);
    } else {
      dec_particles[3].setcolor2(maxcol+1);
      dec_particles[2].setcolor1(maxcol+1);
      dec_particles[2].setcolor2(NCmoC2);
    }
  } else if(NCmo == 3 && NCd1 == 1 && NCd2 == 3 && NCd3 == 8) {
    if(IDmo > 0) { 
      dec_particles[2].setcolor1(maxcol+1);
      dec_particles[3].setcolor1(NCmoC1);
      dec_particles[3].setcolor2(maxcol+1);
    } else {
      dec_particles[2].setcolor2(maxcol+1);
      dec_particles[3].setcolor1(maxcol+1);
      dec_particles[3].setcolor2(NCmoC2);
    }
  } else if(NCmo == 3 && NCd1 == 8 && NCd2 == 1 && NCd3 == 3) {
    if(IDmo > 0) { 
      dec_particles[3].setcolor1(maxcol+1);
      dec_particles[1].setcolor1(NCmoC1);
      dec_particles[1].setcolor2(maxcol+1);
    } else {
      dec_particles[3].setcolor2(maxcol+1);
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[1].setcolor2(NCmoC2);
    }
  } else if(NCmo == 3 && NCd1 == 8 && NCd2 == 3 && NCd3 == 1) {
    if(IDmo > 0) { 
      dec_particles[2].setcolor1(maxcol+1);
      dec_particles[1].setcolor1(NCmoC1);
      dec_particles[1].setcolor2(maxcol+1);
    } else {
      dec_particles[2].setcolor2(maxcol+1);
      dec_particles[1].setcolor1(maxcol+1);
      dec_particles[1].setcolor2(NCmoC2);
    }
  // next, 8 -> 3 3 1: just split a double line
  } else if(NCmo == 8 && NCd1 == 3 && NCd2 == 3 && NCd3 == 1) {
    if(IDd1 > 0) {
      dec_particles[1].setcolor1(NCmoC1);
      dec_particles[2].setcolor2(NCmoC2);
    } else {
      dec_particles[2].setcolor1(NCmoC1);
      dec_particles[1].setcolor2(NCmoC2);
    }
  } else if(NCmo == 8 && NCd1 == 3 && NCd2 == 1 && NCd3 == 3) {
    if(IDd1 > 0) {
      dec_particles[1].setcolor1(NCmoC1);
      dec_particles[3].setcolor2(NCmoC2);
    } else {
      dec_particles[3].setcolor1(NCmoC1);
      dec_particles[1].setcolor2(NCmoC2);
    }
  } else if(NCmo == 8 && NCd1 == 1 && NCd2 == 3 && NCd3 == 3) {
    if(IDd1 > 0) {
      dec_particles[2].setcolor1(NCmoC1);
      dec_particles[3].setcolor2(NCmoC2);
    } else {
      dec_particles[2].setcolor1(NCmoC1);
      dec_particles[1].setcolor2(NCmoC2);
    }
  // next, 8 -> 8 8 1: introduce a new line and split the old one
  // make an arbitrary choice
  } else if(NCmo == 8 && NCd1 == 8 && NCd2 == 8 && NCd3 == 1) {
    dec_particles[1].setcolor1(NCmoC1);
    dec_particles[1].setcolor2(maxcol+1);
    dec_particles[2].setcolor1(maxcol+1);
    dec_particles[2].setcolor2(NCmoC2);
  } else if(NCmo == 8 && NCd1 == 1 && NCd2 == 8 && NCd3 == 8) {
    dec_particles[2].setcolor1(NCmoC1);
    dec_particles[2].setcolor2(maxcol+1);
    dec_particles[3].setcolor1(maxcol+1);
    dec_particles[3].setcolor2(NCmoC2);
  } else if(NCmo == 8 && NCd1 == 8 && NCd2 == 1 && NCd3 == 8) {
    dec_particles[1].setcolor1(NCmoC1);
    dec_particles[1].setcolor2(maxcol+1);
    dec_particles[3].setcolor1(maxcol+1);
    dec_particles[3].setcolor2(NCmoC2);
  } else {
  // now, the trickier cases; we'll pull the color structure from the first amplitude 
    vector< list< TwoBodyDecayPair > > vlist = driver->GetDecayMode()->VList();
    TwoBodyDecayPair apair = *(vlist[0].begin());
    // P -> 0 + 1, I -> 2 + 3, "I" is either 0 or 1
    // color labels of particles 0, 1, 2, 3, I:
    int p0c1 = 0, p0c2 = 0, p1c1 = 0, p1c2 = 0, p2c1 = 0, p2c2 = 0, p3c1 = 0, p3c2 = 0, Ic1 = 0, Ic2 = 0;
    // the two vertices:
    TwoBodyDecayMode* m1 = apair.pr.first;
    TwoBodyDecayMode* m2 = apair.pr.second;
    // IDs of each particle:
    int ID0 =  Particle::pl[m1->ListDaughters()[0]].IDCode();
    int ID1 =  Particle::pl[m1->ListDaughters()[1]].IDCode();
    int ID2 =  Particle::pl[m2->ListDaughters()[0]].IDCode();
    int ID3 =  Particle::pl[m2->ListDaughters()[1]].IDCode();
    int IDI = (apair.I == 0 ? ID0 : ID1);
    // number of colors for each:
    int NC0 = Particle::pl[Particle::plFromID[ID0]].NColors();
    int NC1 = Particle::pl[Particle::plFromID[ID1]].NColors();
    int NC2 = Particle::pl[Particle::plFromID[ID2]].NColors();
    int NC3 = Particle::pl[Particle::plFromID[ID3]].NColors();
    int NCI = Particle::pl[Particle::plFromID[IDI]].NColors();
    // i0, i1, i2, I are positions of original daughters 0,1,2 and of "I" in {0,1,2,3}
    int maxc1 = maxcol; // max color label used after first step; may be incremented
    // first decay step: run over all the color combinations
    if(NC0 == 3 && NC1 == 1) {
      if(ID0 > 0) {
        p0c1 = NCmoC1;
      } else { 
        p0c2 = NCmoC2;
      }
    } else if(NC0 == 1 && NC1 == 3) {
      if(ID1 > 0) {
        p1c1 = NCmoC1;
      } else { 
        p1c2 = NCmoC2;
      }
    } else if(NC0 == 3 && NC1 == 3) {
      if(NCmo == 1) {
        // add a new color line
        if(ID0 > 0) {
          p0c1 = maxcol+1; p1c2 = maxcol+1; maxc1 = maxcol+1;
        } else {
          p0c2 = maxcol+1; p1c1 = maxcol+1; maxc1 = maxcol+1;
        }
      } else if(NCmo == 8) {
        if(ID0 > 0) {
          p0c1 = NCmoC1; p1c2 = NCmoC2;
        } else {
          p0c2 = NCmoC2; p1c1 = NCmoC1;
        }
      } else {
        cout << "Nonsensical color combination: " << NCmo << " -> " << NC0 << " + " << NC1 << "\n";
      }
    } else if(NC0 == 3 && NC1 == 8) {
      if(ID0 > 0) {
        p0c1 = maxcol+1; p1c1 = NCmoC1; p1c2 = maxcol+1; maxc1 = maxcol+1;
      } else {
        p0c2 = maxcol+1; p1c1 = maxcol+1; p1c2 = NCmoC2; maxc1 = maxcol+1;
      }
    } else if(NC0 == 8 && NC1 == 3) {
      if(ID1 > 0) {
        p1c1 = maxcol+1; p0c1 = NCmoC1; p0c2 = maxcol+1; maxc1 = maxcol+1;
      } else {
        p1c2 = maxcol+1; p0c1 = maxcol+1; p0c2 = NCmoC2; maxc1 = maxcol+1;
      }
    } else if(NC0 == 8 && NC1 == 8) {
      if(NCmo == 1) {
        // add two new color labels
        p0c1 = maxcol+1; p0c2 = maxcol+2; p1c1 = maxcol+2; p1c2 = maxcol+1; maxc1 = maxcol+2;
      } else if(NCmo == 8) {
        // add one new color label
        p0c1 = NCmoC1; p0c2 = maxcol+1; p1c1 = maxcol+1; p1c2 = NCmoC2; maxc1 = maxcol+1;
      }
    } else if(NC0 == 8 && NC1 == 1) {
      p0c1 = NCmoC1; p0c2 = NCmoC2;
    } else if(NC0 == 1 && NC1 == 8) {
      p1c1 = NCmoC1; p1c2 = NCmoC2;
    }
    // set intermediate particle colors
    if(apair.I == 0) {
      Ic1 = p0c1; Ic2 = p0c2;
    } else {
      Ic1 = p1c1; Ic2 = p1c2;
    }
    // second decay step
    if(NC2 == 3 && NC3 == 1) {
      if(ID2 > 0) {
        p2c1 = Ic1;
      } else { 
        p2c2 = Ic2;
      }
    } else if(NC2 == 1 && NC3 == 3) {
      if(ID3 > 0) {
        p3c1 = Ic1;
      } else { 
        p3c2 = Ic2;
      }
    } else if(NC2 == 3 && NC3 == 3) {
      if(NCI == 1) {
        // add a new color line
        if(ID2 > 0) {
          p2c1 = maxc1+1; p3c2 = maxc1+1;
        } else {
          p2c2 = maxc1+1; p3c1 = maxc1+1;
        }
      } else if(NCI == 8) {
        if(ID2 > 0) {
          p2c1 = Ic1; p3c2 = Ic2;
        } else {
          p2c2 = Ic2; p3c1 = Ic1;
        }
      } else {
        cout << "Nonsensical color combination: " << NCI << " -> " << NC2 << " + " << NC3 << "\n";
      }
    } else if(NC2 == 3 && NC3 == 8) {
      if(ID2 > 0) {
        p2c1 = maxc1+1; p3c1 = Ic1; p3c2 = maxc1+1;
      } else {
        p2c2 = maxc1+1; p3c1 = maxc1+1; p3c2 = Ic2;
      }
    } else if(NC2 == 8 && NC3 == 3) {
      if(ID3 > 0) {
        p3c1 = maxc1+1; p2c1 = Ic1; p2c2 = maxc1+1;
      } else {
        p3c2 = maxc1+1; p2c1 = maxc1+1; p2c2 = Ic2;
      }
    } else if(NC2 == 8 && NC3 == 8) {
      if(NCI == 1) {
        // add two new color labels
        p2c1 = maxc1+1; p2c2 = maxc1+2; p3c1 = maxc1+2; p3c2 = maxc1+1;
      } else if(NCI == 8) {
        // add one new color label
        p2c1 = Ic1; p2c2 = maxc1+1; p3c1 = maxc1+1; p3c2 = Ic2;
      }
    } else if(NC2 == 8 && NC3 == 1) {
      p2c1 = Ic1; p2c2 = Ic2;
    } else if(NC2 == 1 && NC3 == 8) {
      p3c1 = Ic1; p3c2 = Ic2;
    }
    // now fill in the particle table, assigning to the appropriate places
    // recall:
    // i0, i1, i2, I are positions of original daughters 0,1,2 and of "I" in {0,1,2,3}
    // Set daughter 0 (-> 1 in dec_particles)
    if(apair.i0 == 0) {
      dec_particles[1].setcolor1(p0c1); dec_particles[1].setcolor2(p0c2);
    } else if(apair.i0 == 1) {
      dec_particles[1].setcolor1(p1c1); dec_particles[1].setcolor2(p1c2);
    } else if(apair.i0 == 2) {
      dec_particles[1].setcolor1(p2c1); dec_particles[1].setcolor2(p2c2);
    } else if(apair.i0 == 3) {
      dec_particles[1].setcolor1(p3c1); dec_particles[1].setcolor2(p3c2);
    }
    // Set daughter 1 (-> 2 in dec_particles)
    if(apair.i1 == 0) {
      dec_particles[2].setcolor1(p0c1); dec_particles[2].setcolor2(p0c2);
    } else if(apair.i1 == 1) {
      dec_particles[2].setcolor1(p1c1); dec_particles[2].setcolor2(p1c2);
    } else if(apair.i1 == 2) {
      dec_particles[2].setcolor1(p2c1); dec_particles[2].setcolor2(p2c2);
    } else if(apair.i1 == 3) {
      dec_particles[2].setcolor1(p3c1); dec_particles[2].setcolor2(p3c2);
    }
    // Set daughter 2 (-> 3 in dec_particles)
    if(apair.i2 == 0) {
      dec_particles[3].setcolor1(p0c1); dec_particles[3].setcolor2(p0c2);
    } else if(apair.i2 == 1) {
      dec_particles[3].setcolor1(p1c1); dec_particles[3].setcolor2(p1c2);
    } else if(apair.i2 == 2) {
      dec_particles[3].setcolor1(p2c1); dec_particles[3].setcolor2(p2c2);
    } else if(apair.i2 == 3) {
      dec_particles[3].setcolor1(p3c1); dec_particles[3].setcolor2(p3c2);
    }
  }
  // well, that wasn't much fun. but it's over now.

  // need momentum, wgt
  /*
  for(int i=0;i<=3;i++)
  {
    cms[i]=double(-orig_particles[0].P[i]-orig_particles[1].P[i]);
  }
  cms[0]=-cms[0];
  for(int i=0;i<=3;i++)
  {
    cout << "orig_particles[location].P[" << i << "] = " << orig_particles[location].P[i] << "\n";
    cout << "cms[" << i << "] = " << cms[i] << "\n";
  }
  boostx_(orig_particles[location].P,cms,dec_particles[0].P);
  for(int i=0; i<=3; i++)
  {
    cout << "dec_particles[0].P[" << i << "] = " << dec_particles[0].P[i] << "\n";
  }
  */
  // boost to the reference frame we are given
  boostx_(orig_particles[location].P,boost.P,dec_particles[0].P);
  vector<double> X;

  bool done=false;
  while(!done)
  {
    double vegas_wgt=vegas.getRandomFromGrid(X);
    driver->SetMotherMomentum((FourVector) dec_particles[0]);
    wgt = driver->RunEvent(X, vegas_wgt);
    if(wgt != wgt) {
	cout << "Oops! Event weight is NaN, exiting to avoid infinite loop.\n";
	exit(0);
    }
    FourVector d1P = driver->Daughter1Momentum();
    FourVector d2P = driver->Daughter2Momentum();
    FourVector d3P = driver->Daughter3Momentum();
    for(int i = 0; i < 4; i++) {
      dec_particles[1].P[i] = d1P.P[i];
      dec_particles[2].P[i] = d2P.P[i];
      dec_particles[3].P[i] = d3P.P[i];
    }
    dec_particles[1].Helicity = d1P.Helicity;
    dec_particles[2].Helicity = d2P.Helicity;
    dec_particles[3].Helicity = d3P.Helicity;
    wgt *= vegas_wgt;
//    cout << "vegas weight is: "<< vegas_wgt  << endl;
//    cout << "evt. weight * vegas weight is: " << wgt << endl;
//    cout << "Max weight is: " << mxwgt << endl;
    double random = (*(vegas.RandomGenerator()))();
//    cout << "Random is: " << random << endl;
//    cout << "wgt/random = " << wgt/random << "\n";
    if(wgt/random > mxwgt)
    {
      done=true;
    }
  }
    
  // boost back to the lab frame
  for(int i = 1; i <= 3; i++) {
    boost.P[i] = -boost.P[i];
  }
  for(int i = 0; i <= numdaughters; i++) {
    boostx_(dec_particles[i].P,boost.P,dec_particles[i].P);
  }

  // add lifetime information for the decayed particle
  double rand_for_ct = (*(vegas.RandomGenerator()))();
  // get the width
  double Gamma = Particle::pl[Particle::plFromID[dec_particles[0].idup()]].Width();
  // CDF: 1 - exp(-t/tau), where tau = 1/Gamma
  double t_in_GeVinv = -log(1.0-rand_for_ct)/Gamma;
  // want c tau in mm:
  double GeVinv_to_mm = 0.197e-12;
  dec_particles[0].setvtimup(t_in_GeVinv * GeVinv_to_mm);

  // modifying the original event to contain all the new information 
  // from the decay
  orig_particles[location]=dec_particles[0];
  for(int i=1;i<=numdaughters;i++)
  {
    //need to fix M() if its <0 return M <0 as per hep-ph/0109068
    //will a negative mass mess up anything else in the code?
    //this needs to be adressed at some point
    dec_particles[i].setP5(dec_particles[i].M());
    orig_particles.push_back(dec_particles[i]);
  }
  orig_event.add_particles(orig_particles);
  orig_event.setnup(orig_particles.size());

  orig_event.setxwgtup(weight*bratio);
  //cout << decaymode->Parent() <<  " -> " << decaymode->ListDaughters()[0] << ", " 
  //       << decaymode->ListDaughters()[1] << "\n";
  //parent location
  //cout << "location of particle is line number: " << location+1 << endl;       
  //
}
