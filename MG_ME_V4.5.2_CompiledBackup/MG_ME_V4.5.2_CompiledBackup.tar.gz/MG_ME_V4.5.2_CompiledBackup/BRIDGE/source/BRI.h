#ifndef BRI_H
#define BRI_H

#include <vector>
#include <string>
#include "DecayMode.h"
#include "VegasRandom.h"
#include "Vegas.h"
#include "DecayDriver.h"

// BRI.h: the "Branching Ratio Inquiry" portion of BRIDGE.

class ModeInfo {
 public:
  DecayMode* dm;
  double branchingRatio;
  double width;
  std::string tableLine;
};

class BRI {
 public:
 BRI(std::string parentParticle, VegasRandom* getRand)
   : particleToDecay(parentParticle), getRandom(getRand),
    directory(""), nCall(50000), totBR(1.) {}
 BRI(std::string parentParticle, VegasRandom* getRand, std::string theDir)
   : particleToDecay(parentParticle), getRandom(getRand),
    directory(theDir), nCall(50000), totBR(1.), maxIter(5) {}
  void buildModeList();
  void addMode(DecayMode* theMode);
  // these functions now return total width
  double computeAllWidths();
  double computeTwoBodyWidths(double otherWidths = 0.);
  double computeThreeBodyWidths(double otherWidths = 0.);
  bool checkForGrids(); // TODO: add better output?
  bool buildDecayDrivers();
  bool readBRTable();
  void writeBRTable();
  void writeSLHAtable(std::ofstream& output);
  void setDirectory(std::string theDir);
  std::string getDirectory();
  int getRandomMode();
  void setNumberVegasCalls(int ncalls);
  int getNumberVegasCalls();
  void setMaxVegasIter(int miter); 
  int getMaxVegasIter();
  double totalBR(); // in case we aren't using all modes
  std::vector<ModeInfo> allModes;
  std::vector<VCWithRandom*> drivers;
  std::vector<Vegas> vegases;
  std::string particleToDecay;
  double total_width;

 protected:
  std::string directory;
  VegasRandom* getRandom;
  int nCall;
  int maxIter;
  double totBR;
};

bool testsm(int idc);
int particlechoice(std::vector<std::string>& inlist);
int checkfile(std::string& testfile);
std::vector<int> finddecaylist(std::string filename);
void updateparamcard(std::string slhadecfile,std::string paramcard,std::string path,bool batch);

#endif
