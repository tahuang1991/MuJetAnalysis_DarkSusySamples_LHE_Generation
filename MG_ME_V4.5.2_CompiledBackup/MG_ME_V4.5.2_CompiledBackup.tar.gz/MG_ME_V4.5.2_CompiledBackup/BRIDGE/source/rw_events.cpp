#include "rw_events.h"
using namespace std;

std::vector<std::string> read_banner(std::ifstream& in,std::ios::pos_type& bend,Events_Info& evt_inf)
{
    cout << "Entering read_banner\n";
    vector<string> ret;
    string s1;

    if(!in.eof())
        {
        getline(in,s1);
        if(s1=="<LesHouchesEvents version=\"1.0\">")
            {
		cout << "Setting event_format=LHE\n";
            evt_inf.event_format="LHE";
            }
        else
            {
            evt_inf.event_format="MG";
            }
        ret.push_back(s1);
        }

    while(!in.eof())
        {
        getline(in,s1);
        //This is based on MG event format having all # before the events start(no blank lines either)
        if((evt_inf.event_format=="MG"&&s1[0]=='#')||(evt_inf.event_format=="LHE"&&s1!="<event>"))
            {
            ret.push_back(s1);
            bend=in.tellg();
            }
        else
            {
            in.seekg(bend);
            break;
            }
        }
    cout << "Exiting read_banner\n";
    return ret;
}

bool issepchar(char c)
{
    static const string sepchar=":=";
    return (find(sepchar.begin(),sepchar.end(),c)!=sepchar.end());
}

bool space(char c)
{
    return isspace(c) || issepchar(c);
}

bool not_space(char c)
{
    return !(isspace(c) || issepchar(c));
}

bool isnum(char c)
{
    return isdigit(c) || (c=='.');
}

vector<string> split(const string& str)
{
    typedef string::const_iterator iter;
    vector<string> ret;

    iter i=str.begin();
    while(i != str.end())
        {
        i = find_if(i, str.end(),not_space);
        iter j=find_if(i, str.end(), space);
        if(i!=str.end())
            ret.push_back(string(i,j));
        i=j;
        }
    return ret;
}

vector<vector<string> > split_banner(vector<string>& banner)
{
    vector<vector<string> > ret;
    for(vector<string>::const_iterator it=banner.begin(); it !=banner.end(); ++it)
        ret.push_back(split(*it));
    return ret;
}

void write_banner(ofstream& outfile,vector<string>& old_banner,vector<string>& new_banner)
{
  for(vector<string>::iterator i=new_banner.begin();i!=new_banner.end();++i)
    old_banner.push_back(*i);
  for(vector<string>::iterator i=old_banner.begin();i!=old_banner.end();++i)
    outfile << *i << endl;
}



bool extract_banner_info(std::vector<std::vector<std::string> >& banner,Events_Info& evt_inf)
{
// MG format banner info:
// done under the assumption we have a universal banner written out at the end
// can obviously be changed accordingly
// example:
//##  Number of Events       :        2667
//##  Integrated weight (pb) :  .88062E-01
//##  Max wgt                :  .27098E-02
//##  Average wgt            :  .33019E-04
//##****************************
//Les Houches Format(At this point I am not storing info from les houches <init> blocks
// we will need to change this if we want to read events from another program):
//#  Number of Events        :        7915
//#  Integrated weight (pb)  :  .70854E+02
//#  Max wgt                 :  .19518E-01
//#  Average wgt             :  .89518E-02
//#*********************************************************************
//-->
//<init>
//  2212  2212  0.70000000000E+04  0.70000000000E+04 0 0 10042 10042 2 1
//  0.70853807743E+02  0.26227000000E+00  0.19517570000E-01 661
//</init>
//
//
cout << "In extract_banner_info\n";
vector<string> vals;
if(evt_inf.event_format=="MG")
    {
    for(vector<vector<string> >::reverse_iterator it1=banner.rbegin()+1; it1 !=banner.rbegin()+5; ++it1)
        {
        for(vector<string>::iterator it2=it1->begin(); it2!=it1->end(); ++it2)
            {
            if(isnum((*it2)[0]))
            vals.push_back(*it2);
            }
        }
    evt_inf.av_wgt=atof(vals[0].c_str());
    evt_inf.mx_wgt=atof(vals[1].c_str());
    evt_inf.int_wgt=atof(vals[2].c_str());
    evt_inf.n_events=atoi(vals[3].c_str());
    return true;
    }
if(evt_inf.event_format=="LHE")
    {
    int countPars = 0;
    vector<vector<string> >::reverse_iterator it1=banner.rbegin();
    vals.push_back("0.0"); vals.push_back("0.0"); vals.push_back("0.0"); vals.push_back("0");
    while(countPars < 4 && it1 != banner.rend()) {
      vector<string> words = *it1;
      int nwords = words.size();
      if(nwords >= 3 && words[1] == "Unit" && words[2] == "wgt") {
        vals[0] = words[nwords-1];
        countPars++;
      } else if(nwords >= 3 && words[1] == "Truncated" && words[2] == "wgt") {
        vals[1] = words[nwords-1];
        countPars++;
      } else if(nwords >= 3 && words[1] == "Integrated" && words[2] == "weight") {
        vals[2] = words[nwords-1];
        countPars++;
      } else if(nwords >= 4 && words[1] == "Number" && words[3] == "Events") {
        vals[3] = words[nwords-1];
        countPars++;
      }
      ++it1;
    }
    if(countPars != 4) {
      cout << "Trouble reading header information!\n";
      cout << "Setting av_wgt, mx_wgt, int_wgt, n_events to 0.\n";
      cout << "Expecting a section in your LHE file before the first <event> formatted as:\n";
      cout << "<MGGenerationInfo>\n";
      cout << "#  Number of Events        :       10000\n";
      cout << "#  Integrated weight (pb)  :  .12034E+00\n";
      cout << "#  Truncated wgt (pb)      :  .47826E-04\n";
      cout << "#  Unit wgt                :  .12034E-04\n";
      cout << "</MGGenerationInfo>\n";
    }
    evt_inf.av_wgt=atof(vals[0].c_str());
    evt_inf.mx_wgt=atof(vals[1].c_str());
    evt_inf.int_wgt=atof(vals[2].c_str());
    evt_inf.n_events=atoi(vals[3].c_str());
//    cout << "evt_inf.av_wgt = " << evt_inf.av_wgt << "\n";
//    cout << "evt_inf.mx_wgt = " << evt_inf.mx_wgt << "\n";
//    cout << "evt_inf.int_wgt = " << evt_inf.int_wgt << "\n";
//    cout << "evt_inf.n_events = " << evt_inf.n_events << "\n";
    return true;
    }
return false;
}
