#!/usr/bin/env perl

if ($#ARGV != 1) {
  print "usage: antigrids.pl input/particles.dat results/\n";
  exit;
}

$particles = $ARGV[0];
$resultsdir = $ARGV[1];

# First, build a map from particles to antiparticles
open(FP, $particles);
while ($line = <FP>) {
# pick lines that start with alphabetic character
  if(substr($line,0,1) =~ /([a-z]|[A-Z])/) {
    @content = split(' ',$line);
# pick the ones that are a particle (not multiparticle)
# do this based on number of entries
    if($#content == 8) {
      $parttoanti{$content[0]} = $content[1];
      $parttoanti{$content[1]} = $content[0];
      $spin{$content[0]} = $content[2];
      $spin{$content[1]} = $content[2];
    }
  }
}
close FP;

# Next, look for tables in the grid directory
chdir $resultsdir;
foreach $particle (keys %parttoanti) {
# check for decay table
  $tablename = $particle . "_decays.table";
  if (-e $tablename) {
    $antitablename = $parttoanti{$particle} . "_decays.table";
    if (! -e $antitablename) {
      print "Found " . $tablename . " but not " . $antitablename . "\n";
      # Now write the antiparticle table and symlink the grids
      open(DT, $tablename);
      open(AT, ">$antitablename");
      while ($line = <DT>) {
	if(substr($line,0,1) =~ /([a-z]|[A-Z])/) {
	  @content = split(' ',$line);
	  if($#content == 2) {
            # We have a two-body decay mode
            # write out the anti-mode
            $theantimode = $parttoanti{$content[0]} . " " .
 	      $parttoanti{$content[1]} . " " . $content[2] . "\n";
            print AT $theantimode;
            # symlink the relevant grid
            $thegrid = $particle . "_" . $content[0] . "_" . $content[1]
	      . ".grid";
	    $theantigrid = $parttoanti{$particle} . "_" .
 	       $parttoanti{$content[0]} . "_" . $parttoanti{$content[1]}
		  . ".grid";
	    symlink $thegrid, $theantigrid;
	  } elsif($#content == 3) {
            # We have a three-body decay mode
            # write out the anti-mode
	    $theantimode = $parttoanti{$content[0]} . " " .
		$parttoanti{$content[1]} . " " . $parttoanti{$content[2]} .
                " " . $content[3] . "\n";
            print AT $theantimode;
            # symlink the relevant grid
            $thegrid = $particle . "_" . $content[0] . "_" . $content[1]
	      . "_" . $content[2] . ".grid";
	    $theantigrid = $parttoanti{$particle} . "_" .
              $parttoanti{$content[0]} . "_" . $parttoanti{$content[1]}
              . "_" . $parttoanti{$content[2]} . ".grid";
            symlink $thegrid, $theantigrid;
          }
	} else {
 	  # the total width line
          # just copy the line to the antiparticle grid
	  print AT $line;
	}
      }
      close DT;
      close AT;
      print "Antiparticle table has been written and grids have been symlinked for " . $parttoanti{$particle} . "\n"
    }
  }
}
